"""US Alpha Mobile — ενημερώσεις AI πρωί / πριν το άνοιγμα / μετά το κλείσιμο (ώρα Ελλάδας).

Τρέχει στο GitHub Actions (notes.yml). Παίρνει την τελευταία βραδινή ανάλυση (snapshot.json), παγκόσμιες αγορές,
τιμές εκτός ωραρίου και φρέσκες ειδήσεις, γράφει την ενημέρωση με AI (κρυφό GEMINI_API_KEY) και ενημερώνει το
<site>/data/ai.json χωρίς να σβήσει τις βραδινές σημειώσεις ανά μετοχή.

Χρήση:  python tools/notes_mobile.py <φάκελος_site> [--slot auto|morning|premarket|evening] [--force]
Γράφει "deploy=true|false" στο $GITHUB_OUTPUT.
"""
from __future__ import annotations

import json
import logging
import os
import sys
import warnings
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
warnings.filterwarnings("ignore")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("notes_mobile")


def out(deploy: bool, msg: str) -> None:
    print(msg)
    f = os.getenv("GITHUB_OUTPUT")
    if f:
        with open(f, "a", encoding="utf-8") as fh:
            fh.write(f"deploy={'true' if deploy else 'false'}\n")


def _arg(name: str, default: str | None = None) -> str | None:
    if name in sys.argv:
        i = sys.argv.index(name)
        if i + 1 < len(sys.argv):
            return sys.argv[i + 1]
    return default


def main() -> None:
    site = Path(sys.argv[1])
    force = "--force" in sys.argv
    slot = (_arg("--slot", "auto") or "auto").strip().lower()
    data = site / "data"
    snap_p, ai_p = data / "snapshot.json", data / "ai.json"
    if not snap_p.exists():
        return out(False, "Δεν υπάρχει ακόμα βραδινή ανάλυση (snapshot.json)")
    from app import db
    db.init_db()
    from app.ai import brief as B
    if slot == "auto":
        slot = B.auto_slot()
        if not slot:
            return out(False, f"Καμία ενημέρωση αυτή την ώρα ({B.now_ny():%a %H:%M} Ν. Υόρκη)")
    if slot not in B.SLOTS:
        return out(False, f"Άγνωστη ενημέρωση: {slot}")
    snap = json.loads(snap_p.read_text(encoding="utf-8"))
    prev = None
    if ai_p.exists():
        try:
            prev = json.loads(ai_p.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            prev = None
    ny_date = B.now_ny().strftime("%Y-%m-%d")
    if not force and B.already_done(prev, slot, ny_date):
        return out(False, f"Η ενημέρωση «{B.SLOTS[slot]['label']}» για {ny_date} υπάρχει ήδη")
    quotes = None
    qp = data / "quotes.json"
    if qp.exists():
        try:
            qj = json.loads(qp.read_text(encoding="utf-8"))
            if qj.get("day") == ny_date:
                quotes = qj.get("q")
        except Exception:  # noqa: BLE001
            pass
    br = B.build(slot, snap, quotes)
    if not br.get("ai") and not br.get("moves") and not br.get("news"):
        return out(False, "Δεν βρέθηκαν δεδομένα (πρόβλημα πηγών)")
    ai = B.merge(prev, br)
    ai_p.write_text(json.dumps(ai, ensure_ascii=False, separators=(",", ":"), default=str), encoding="utf-8")
    out(True, f"{br['label']} ({ny_date}): AI={'ναι' if br.get('ai') else 'όχι (χωρίς κλειδί/απάντηση)'}, "
              f"αγορές={len(br.get('moves') or [])}, ειδήσεις={len(br.get('news') or [])}, "
              f"εκτός ωραρίου={len(br.get('gaps') or [])}, σημειώσεις μετοχών={len(br.get('stocks') or {})}")


if __name__ == "__main__":
    main()
