"""US Alpha Mobile — ζωντανές τιμές όλη τη συνεδρίαση, χωρίς κωδικούς.

Τρέχει στο GitHub Actions από το άνοιγμα ως το κλείσιμο της αγοράς ΗΠΑ. Κάθε ~2,5 λεπτά παίρνει την τρέχουσα
τιμή και τη μεταβολή από το χθεσινό κλείσιμο (Yahoo, 20 μετοχές ανά αίτημα) για όλες τις μετοχές της ανάλυσης και
τη γράφει στο αρχείο quotes.json του κλάδου "live" του repository. Η εφαρμογή το διαβάζει από το
raw.githubusercontent.com, οπότε οι τιμές ανανεώνονται χωρίς νέα δημοσίευση της σελίδας.

Μόνο πραγματικές τιμές: ό,τι δεν ήρθε από το Yahoo απλώς λείπει.

Χρήση:  python tools/live_quotes.py [--minutes 340] [--every 150] [--once] [--out DIR] [--no-push]
Περιβάλλον: GH_TOKEN (το GITHUB_TOKEN του workflow), REPO (owner/name), LIVE_BRANCH (προεπιλογή live)
"""
from __future__ import annotations

import argparse
import json
import logging
import os
import shutil
import subprocess
import sys
import tempfile
import time
from datetime import datetime, time as dtime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.environ.setdefault("USALPHA_NO_SCHEDULER", "1")

from app.data import yahoo  # noqa: E402
from app.data.session import EARLY_CLOSE, NY, is_trading_day, session  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("usalpha.live")
logging.getLogger("httpx").setLevel(logging.WARNING)
INDEX = ["SPY", "QQQ", "DIA", "IWM", "^VIX", "^GSPC", "^IXIC", "^DJI", "EURUSD=X"]


def tickers_from_snapshot(repo: str, local: Path | None) -> list[str]:
    """Η λίστα μετοχών της τελευταίας βραδινής ανάλυσης (από τη σελίδα ή από τοπικό αρχείο)."""
    snap = None
    if local and local.exists():
        try:
            snap = json.loads(local.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            snap = None
    if snap is None and repo:
        import httpx
        owner, name = repo.split("/", 1)
        url = f"https://{owner.lower()}.github.io/{name}/data/snapshot.json"
        for k in range(3):
            try:
                r = httpx.get(url, params={"t": int(time.time())}, timeout=60, follow_redirects=True)
                if r.status_code == 200:
                    snap = r.json()
                    break
            except Exception as e:  # noqa: BLE001
                log.warning("snapshot: %s", e)
            time.sleep(5 * (k + 1))
    rows = (snap or {}).get("rows") or []
    out = [r.get("t") for r in rows if r.get("t")]
    return list(dict.fromkeys(INDEX + out))


def close_time(d) -> dtime:
    return dtime(13, 0) if d.isoformat() in EARLY_CLOSE else dtime(16, 0)


def push(path: Path, repo: str, branch: str, token: str) -> bool:
    """Ένα commit μόνο (ορφανό, force push): ο κλάδος δεν μεγαλώνει με τον χρόνο."""
    d = Path(tempfile.mkdtemp(prefix="live-"))
    try:
        def git(*a):
            return subprocess.run(["git", "-C", str(d), *a], capture_output=True, text=True, timeout=120)
        subprocess.run(["git", "init", "-q", str(d)], check=True, capture_output=True, timeout=60)
        git("checkout", "-q", "--orphan", branch)
        shutil.copy(path, d / "quotes.json")
        (d / "README.md").write_text("Ζωντανές τιμές για την εφαρμογή US Alpha (ενημερώνονται αυτόματα όσο είναι "
                                     "ανοιχτή η αγορά ΗΠΑ). Δεν περιέχει κώδικα ή κλειδιά.\n", encoding="utf-8")
        git("add", "quotes.json", "README.md")
        c = git("-c", "user.name=github-actions[bot]", "-c", "user.email=41898282+github-actions[bot]@users.noreply.github.com",
                "commit", "-q", "-m", "Ζωντανές τιμές [skip ci]")
        if c.returncode:
            log.warning("commit: %s", c.stderr[-300:])
            return False
        url = os.getenv("LIVE_REMOTE") or f"https://x-access-token:{token}@github.com/{repo}.git"
        for k in range(3):
            p = git("push", "-q", "-f", url, f"{branch}:{branch}")
            if p.returncode == 0:
                return True
            log.warning("push %d: %s", k + 1, p.stderr.replace(token, "***")[-300:])
            time.sleep(5 * (k + 1))
        return False
    finally:
        shutil.rmtree(d, ignore_errors=True)


def cycle(tickers: list[str], day: str) -> dict:
    t0 = time.time()
    q = yahoo.spark_quotes(tickers, workers=4)
    out = {}
    for t, v in q.items():
        if v.get("price") is None:
            continue
        if v.get("day") != day and not t.endswith("=X"):
            continue  # δεν διαπραγματεύτηκε σήμερα (π.χ. σε αναστολή): μένει η τιμή της ανάλυσης
        out[t] = [round(v["price"], 4), round(v["chg"], 2) if v.get("chg") is not None else None]
    if len(out) < 0.5 * len(tickers):  # το Yahoo δεν απάντησε στο γρήγορο αίτημα: η παλιά (πιο αργή) διαδρομή
        miss = [t for t in tickers if t not in out]
        log.info("γρήγορη διαδρομή: μόνο %d — δεύτερη διαδρομή για %d", len(out), len(miss))
        for i in range(0, len(miss), 250):
            for t, df in yahoo.history(miss[i:i + 250], period="5d", chunk=250).items():
                df = df.dropna(subset=["Close"])
                if len(df) < 2 or df.index[-1].strftime("%Y-%m-%d") != day:
                    continue
                p, prev = float(df["Close"].iloc[-1]), float(df["Close"].iloc[-2])
                if prev > 0:
                    out[t] = [round(p, 4), round((p / prev - 1) * 100, 2)]
    log.info("κύκλος: %d/%d τιμές σε %.0fs", len(out), len(tickers), time.time() - t0)
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--minutes", type=float, default=340)
    ap.add_argument("--every", type=float, default=150, help="δευτερόλεπτα ανάμεσα στις ενημερώσεις")
    ap.add_argument("--once", action="store_true")
    ap.add_argument("--out", default=str(ROOT / "_live"))
    ap.add_argument("--snapshot", default="", help="τοπικό snapshot.json (αλλιώς από τη σελίδα)")
    ap.add_argument("--no-push", action="store_true")
    a = ap.parse_args()
    repo, token = os.getenv("REPO", ""), os.getenv("GH_TOKEN", "")
    branch = os.getenv("LIVE_BRANCH", "live")
    t_end = time.time() + a.minutes * 60
    out_dir = Path(a.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    now = datetime.now(NY)
    if not is_trading_day(now.date()):
        log.info("Η αγορά ΗΠΑ είναι κλειστή σήμερα (%s)", now.date())
        return
    day = now.date().isoformat()
    open_at = datetime.combine(now.date(), dtime(9, 29), NY)
    stop_at = datetime.combine(now.date(), close_time(now.date()), NY) + timedelta(minutes=20)
    if now >= stop_at and not a.once:
        log.info("Η συνεδρίαση έκλεισε (%s Ν. Υόρκη)", now.strftime("%H:%M"))
        return
    if now < open_at and not a.once:
        wait = (open_at - now).total_seconds()
        if time.time() + wait > t_end - 600:
            log.info("Πολύ νωρίς: η αγορά ανοίγει σε %.0f′", wait / 60)
            return
        log.info("Αναμονή %.0f′ ως το άνοιγμα", wait / 60)
        time.sleep(wait)
    tickers = tickers_from_snapshot(repo, Path(a.snapshot) if a.snapshot else None)
    log.info("Μετοχές: %d", len(tickers))
    loaded, pushed, last_q = time.time(), 0, None
    while True:
        c0 = time.time()
        if c0 - loaded > 3600:  # νέα βραδινή ανάλυση → νέα λίστα
            tickers = tickers_from_snapshot(repo, Path(a.snapshot) if a.snapshot else None) or tickers
            loaded = c0
        q = cycle(tickers, day)
        if len(q) >= 20 and q != last_q:
            now = datetime.now(NY)
            payload = {"at": datetime.now(timezone.utc).isoformat(timespec="seconds"), "day": day,
                       "session": session(now), "src": "Yahoo", "n": len(q), "q": q}
            p = out_dir / "quotes.json"
            p.write_text(json.dumps(payload, separators=(",", ":"), ensure_ascii=False), encoding="utf-8")
            if not a.no_push and repo and token:
                if push(p, repo, branch, token):
                    pushed += 1
            last_q = q
        elif len(q) < 20:
            log.warning("Λίγες τιμές (%d): πιθανή αργία ή πρόβλημα πηγής", len(q))
        now = datetime.now(NY)
        if a.once or now >= stop_at or time.time() + a.every > t_end:
            break
        time.sleep(max(15.0, a.every - (time.time() - c0)))
    log.info("Τέλος: %d ενημερώσεις ανέβηκαν (%s Ν. Υόρκη)", pushed, datetime.now(NY).strftime("%H:%M"))


if __name__ == "__main__":
    main()
