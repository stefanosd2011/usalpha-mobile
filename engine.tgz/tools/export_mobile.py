"""US Alpha — καθημερινή ανάλυση στο cloud (GitHub Actions) για την εφαρμογή κινητού.

Τρέχει ΤΟΝ ΙΔΙΟ αλγόριθμο με το πρόγραμμα του υπολογιστή (scanner, LightGBM, SEC, setups, signals)
και γράφει έτοιμα αρχεία JSON που διαβάζει η εφαρμογή:
  <out>/snapshot.json      αγορά, ευκαιρίες, όλη η λίστα μετοχών, μοντέλο, ειδήσεις, ιστορικό signals
  <out>/s/<TICKER>.json    πλήρης ανάλυση + ημερήσιες τιμές για κάθε μετοχή

Δεν χρειάζεται κανένα API key (Yahoo, Nasdaq, SEC). Τα δεδομένα μένουν στο cache του GitHub
ώστε κάθε μέρα να κατεβαίνει μόνο η νέα μέρα.

Χρήση:  python tools/export_mobile.py --out ../_site/data [--budget-min 300] [--export-only]
"""
from __future__ import annotations

import argparse
import json
import logging
import math
import os
import shutil
import sys
import time
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.environ.setdefault("USALPHA_NO_SCHEDULER", "1")

from app import db  # noqa: E402
from app.config import settings  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("usalpha.export")
T0 = time.time()
BUDGET = 300 * 60


def left() -> float:
    return BUDGET - (time.time() - T0)


def step(msg: str) -> None:
    log.info("[%5.1f′] %s", (time.time() - T0) / 60, msg)


# ------------------------------------------------------------------ βοηθητικά
def clean(o):
    if isinstance(o, float):
        return None if (math.isnan(o) or math.isinf(o)) else o
    if isinstance(o, dict):
        return {str(k): clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [clean(v) for v in o]
    if hasattr(o, "item") and callable(o.item):  # numpy scalar
        try:
            return clean(o.item())
        except Exception:  # noqa: BLE001
            return None
    if isinstance(o, (datetime, date)):
        return o.isoformat()
    return o


def r(v, n=4):
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None
    if math.isnan(f) or math.isinf(f):
        return None
    if abs(f) >= 1000:
        return round(f, 2 if abs(f) < 1e6 else 0)
    return round(f, n)


def dump(path: Path, data) -> int:
    path.parent.mkdir(parents=True, exist_ok=True)
    txt = json.dumps(clean(data), ensure_ascii=False, separators=(",", ":"), default=str)
    path.write_text(txt, encoding="utf-8")
    return len(txt)


# ------------------------------------------------------------------ pipeline (ίδια σειρά με το πρόγραμμα του υπολογιστή)
CAPTURED: dict[str, dict] = {}


def install_capture():
    """Κρατά κάθε πλήρη ανάλυση του scanner ώστε να εξαχθεί χωρίς να ξαναϋπολογιστεί."""
    from app.engine import pipeline
    orig = pipeline.analyze_ticker

    def wrapped(t, ctx, *a, **kw):
        b = orig(t, ctx, *a, **kw)
        if isinstance(b, dict) and b.get("ok"):
            CAPTURED[t] = b
        return b
    pipeline.analyze_ticker = wrapped


def scan(update_data: bool, fetch_companies: bool) -> dict:
    from app.engine import scanner
    CAPTURED.clear()
    r_ = scanner.run_scan(update_data=update_data, fetch_companies=fetch_companies,
                          max_company_fetch=min(settings.deep_n, 150))
    step(f"scan: {r_.get('status')} · {r_.get('analyzed')} μετοχές · notes: {'; '.join(r_.get('notes', []))[:600]}")
    return r_


def eod_lifecycle() -> int:
    """Οι ευκαιρίες ελέγχονται με τις ημερήσιες τιμές (υψηλό/χαμηλό). Αν την ίδια μέρα πιάστηκαν
    και stop και στόχος, μετράει το stop (συντηρητικά)."""
    from app.engine import signals as S
    done = db.kv_get("eod_lifecycle", {}) or {}
    n = 0
    for s in db.q(f"SELECT * FROM signals WHERE status IN {S.ACTIVE}"):
        t, long = s["ticker"], s["bias"] == "bullish"
        since = done.get(str(s["id"])) or s["created_at"][:10]
        df = db.load_prices(t, start=since)
        df = df[df.index.strftime("%Y-%m-%d") > since]
        if df.empty:
            continue
        status, stop = s["status"], s["stop"]
        hist = json.loads(s["history_json"] or "[]")
        closed = None
        days = 0
        for d, row in df.iterrows():
            days += 1
            ds = d.strftime("%Y-%m-%d")
            hi, lo, cl = float(row["high"]), float(row["low"]), float(row["close"])
            if status == "new" and lo <= s["entry_high"] and hi >= s["entry_low"]:
                status = "active"
                hist.append({"at": ds, "event": "Μπήκε στη ζώνη εισόδου", "price": r(min(max(s["entry"] if "entry" in s.keys() else cl, lo), hi))})
            lost = lo <= stop if long else hi >= stop
            if lost:
                ret = (stop / s["price"] - 1) * (1 if long else -1) * 100
                closed = ("closed", "stop" if status in ("new", "active") else f"stop μετά από {status.upper()}", ret, ds)
                break
            order = ["new", "active", "tp1", "tp2", "tp3"]
            for lvl in ("tp1", "tp2", "tp3"):
                hit = hi >= s[lvl] if long else lo <= s[lvl]
                if order.index(status) < order.index(lvl) and hit:
                    status = lvl
                    if lvl == "tp1":
                        stop = s["price"]
                    elif lvl == "tp2":
                        stop = s["tp1"]
                    hist.append({"at": ds, "event": f"Χτυπήθηκε {lvl.upper()} {s[lvl]:.2f}", "price": r(s[lvl]), "stop": r(stop)})
            if status == "tp3":
                closed = ("closed", "tp3", (s["tp3"] / s["price"] - 1) * (1 if long else -1) * 100, ds)
                break
            if S._trading_days_since(s["created_at"]) > S.HORIZONS[s["horizon"]]["max_days"] and d == df.index[-1]:
                closed = ("expired", "expired", (cl / s["price"] - 1) * (1 if long else -1) * 100, ds)
                break
        if closed:
            db.execute("UPDATE signals SET status=?, closed_at=?, outcome=?, outcome_return=?, history_json=? WHERE id=?",
                       (closed[0], closed[3], closed[1], closed[2], json.dumps(hist), s["id"]))
        else:
            db.execute("UPDATE signals SET status=?, stop=?, history_json=? WHERE id=?",
                       (status, stop, json.dumps(hist), s["id"]))
        done[str(s["id"])] = df.index[-1].strftime("%Y-%m-%d")
        n += 1
    db.kv_set("eod_lifecycle", done)
    return n


def run_pipeline() -> None:
    from app.data import secdata
    from app.jobs import scheduler
    from app.ml import features as MLF
    from app.ml import model as mlmodel

    step(f"Ιστορικό {settings.history_years} ετών, ML έως {settings.ml_max_tickers} μετοχές")
    try:
        n = eod_lifecycle()
        step(f"Έλεγχος ενεργών ευκαιριών με τις νέες τιμές: {n}")
    except Exception:  # noqa: BLE001
        log.exception("lifecycle")
    try:
        if db.kv_get("last_run_id"):
            scheduler.job_news()
            step("Ειδήσεις")
    except Exception:  # noqa: BLE001
        log.exception("news")

    r1 = scan(update_data=True, fetch_companies=True)
    if r1.get("status") != "ok":
        raise SystemExit("Το scan απέτυχε: " + str(r1.get("error")))

    age = mlmodel.model_age_days()
    stale = any(mlmodel.load(h) is None for h in MLF.HORIZONS)
    if (age is None or age >= settings.ml_retrain_days or stale) and left() > 75 * 60:
        try:
            from app.data.listings import universe_tickers
            step("SEC: επίσημα οικονομικά στοιχεία και ημερομηνίες αποτελεσμάτων")
            secdata.sync_all(universe_tickers(settings.ml_max_tickers))
        except Exception:  # noqa: BLE001
            log.exception("SEC sync failed")
        step("Εκπαίδευση μοντέλου πρόβλεψης (LightGBM, walk-forward)")
        tr = mlmodel.train_all()
        step(f"Εκπαίδευση: {tr.get('status')} · επικυρωμένα: "
             f"{[h for h, v in (tr.get('results') or {}).items() if v.get('validated')]}")
        if tr.get("status") == "ok":
            scan(update_data=False, fetch_companies=False)
    try:
        if db.kv_get("last_run_id"):
            from app.report import daily
            daily.build()
    except Exception:  # noqa: BLE001
        log.exception("report")


# ------------------------------------------------------------------ εξαγωγή
SETUP_KEYS = ("horizon", "bias", "setup", "entry_low", "entry_high", "entry", "stop", "tp1", "tp2", "tp3", "rr",
              "stop_pct", "holding", "max_days", "reasons", "confidence", "ml_p", "ml_exp_r", "rank_pct", "rank_ex",
              "catalysts", "risks")


def setup_out(s: dict, rejected: bool = False) -> dict:
    o = {k: s.get(k) for k in SETUP_KEYS}
    c = s.get("confirmation") or {}
    o["conf"] = {"sup": c.get("supporting", []), "opp": c.get("opposing", []), "conflicts": c.get("conflicts", [])}
    if s.get("position"):
        p = s["position"]
        o["pos"] = {"shares": p.get("shares"), "value": p.get("position_value"), "risk": p.get("risk_amount"),
                    "riskPct": p.get("risk_pct_account"), "account": p.get("account")}
    if rejected:
        o["why"] = s.get("rejected_because", [])
    for k in ("entry_low", "entry_high", "entry", "stop", "tp1", "tp2", "tp3"):
        o[k] = r(o[k])
    return o


def vp_summary(vp: dict | None) -> dict | None:
    bins = (vp or {}).get("bins") or []
    if not bins:
        return None
    tot = sum(b["volume"] for b in bins) or 1
    i = max(range(len(bins)), key=lambda k: bins[k]["volume"])
    lo = hi = i
    acc = bins[i]["volume"]
    while acc / tot < 0.7 and (lo > 0 or hi < len(bins) - 1):
        a = bins[lo - 1]["volume"] if lo > 0 else -1
        b = bins[hi + 1]["volume"] if hi < len(bins) - 1 else -1
        if a >= b:
            lo -= 1
            acc += a
        else:
            hi += 1
            acc += b
    return {"poc": r((bins[i]["low"] + bins[i]["high"]) / 2), "vaLow": r(bins[lo]["low"]), "vaHigh": r(bins[hi]["high"])}


def stock_shard(t: str, b: dict, info_cache: dict) -> dict:
    from app.ai import assistant
    from app.data import service
    from app.engine import signals
    from app.ml import model as mlmodel
    acc, rej = signals.evaluate_setups(b)
    try:
        pred = mlmodel.prediction_for(t)
    except Exception as e:  # noqa: BLE001
        log.debug("pred %s: %s", t, e)
        pred = {}
    simple = assistant.simple_stock(b, pred, acc)
    df = db.load_prices(t, start=(date.today() - timedelta(days=560)).isoformat())
    tech, fund, q = b["tech"], b["fund"], b.get("quote") or {}
    m = dict(tech.get("metrics") or {})
    rs = m.pop("rs", None) or {}
    news = db.q("SELECT title,url,source,published_at,category,sentiment,impact FROM news WHERE ticker=? AND is_primary=1 "
                "ORDER BY published_at DESC LIMIT 12", (t,))
    info = service.get_company(t, fetch=False) or {}
    sig = [s for s in info_cache.get("signals", []) if s["ticker"] == t][:8]
    fm = fund.get("metrics") or {}
    out = {
        "v": 2, "ticker": t, "name": b.get("name"), "sector": b.get("sector"), "industry": b.get("industry"),
        "asOf": tech.get("as_of") or (df.index[-1].strftime("%Y-%m-%d") if len(df) else None),
        "price": r(q.get("price") or m.get("close")), "chg": r(q.get("change_pct") if q.get("change_pct") is not None else m.get("change_pct"), 2),
        "tech": {"technical": tech.get("technical_score"), "momentum": tech.get("momentum_score"), "flags": tech.get("flags", []),
                 "pros": tech.get("pros", []), "cons": tech.get("cons", []), "m": {k: r(v) for k, v in m.items()},
                 "rs": {k: (r(v, 2) if not isinstance(v, bool) else v) for k, v in rs.items()},
                 "levels": [{"price": r(x["price"]), "touches": x.get("touches"), "type": x.get("type")} for x in tech.get("levels") or []],
                 "vp": vp_summary(tech.get("volume_profile"))},
        "risk": {"score": b["risk"].get("score"), "warnings": [w.get("text") for w in b["risk"].get("warnings", [])]},
        "sc": {"score": b["scored"]["score"], "bias": b["scored"]["bias"], "coverage": b["scored"].get("coverage"),
               "contrib": [{"label": c["label"], "score": c.get("score"), "weight": c.get("weight"), "impact": c.get("impact")}
                           for c in b["scored"].get("contributions", [])],
               "explain": {k: (b["scored"].get("explain") or {}).get(k) for k in ("summary", "pros", "cons", "what_changes")}},
        "fund": {"score": fund.get("score"), "coverage": fund.get("coverage"), "pros": fund.get("pros", []), "cons": fund.get("cons", []),
                 "risks": fund.get("risks", []), "m": {k: r(v) for k, v in fm.items()}},
        "news": {"score": b["news"].get("score"), "n": b["news"].get("n_clusters", 0),
                 "items": [{"title": n["title"], "url": n["url"], "source": n["source"], "at": n["published_at"],
                            "sent": r(n["sentiment"], 2), "cat": n["category"]} for n in news]},
        "pred": {h: {"label": p.get("label"), "kind": p.get("kind"), "days": p.get("days"), "p": r(p.get("p")), "rank": r(p.get("rank_pct")),
                     "exp": r(p.get("exp_r"), 5), "validated": bool(p.get("validated")), "date": p.get("date"),
                     "breakeven": p.get("breakeven"),
                     "drivers": [{"label": d["label"], "value": d.get("value"), "effect": d.get("effect")} for d in (p.get("drivers") or [])[:8]]}
                 for h, p in (pred or {}).items()},
        "acc": [setup_out(s) for s in acc], "rej": [setup_out(s, True) for s in rej],
        "simple": simple,
        "profile": {"summary": info.get("longBusinessSummary"), "website": info.get("website"), "exchange": info.get("exchange"),
                    "country": info.get("country"), "employees": info.get("fullTimeEmployees")},
        "insiders": (info.get("insiders") or [])[:8], "analysts": (info.get("analyst_actions") or [])[:8],
        "signals": [{"horizon": s["horizon"], "setup": s.get("setup"), "date": s["created_at"][:10], "status": s["status"],
                     "outcome": s.get("outcome"), "ret": r(s.get("outcome_return"), 2)} for s in sig],
        "bars": {"d": [x.strftime("%Y-%m-%d") for x in df.index], "o": [r(x) for x in df["open"]], "h": [r(x) for x in df["high"]],
                 "l": [r(x) for x in df["low"]], "c": [r(x) for x in df["close"]], "v": [int(x or 0) for x in df["volume"].fillna(0)]},
    }
    return out


def model_out() -> tuple[dict, dict]:
    from app.ml import model as mlmodel
    st = mlmodel.status()
    out = {}
    for h, v in (st.get("models") or {}).items():
        mt = v.get("metrics") or {}
        oos = mt.get("oos") or {}
        cfg = (st.get("horizons") or {}).get(h, {})
        out[h] = {"label": v.get("label") or cfg.get("label"), "kind": v.get("kind") or cfg.get("kind"), "days": cfg.get("H"),
                  "validated": bool(v.get("validated")), "createdAt": v.get("created_at"), "nTrain": v.get("n_train"),
                  "dataEnd": v.get("data_end"), "gate": mt.get("gate", []), "nTickers": mt.get("n_tickers"),
                  "ic": oos.get("ic_mean"), "icT": oos.get("ic_t"), "icPos": oos.get("ic_pos_share"), "dates": oos.get("dates"),
                  "auc": oos.get("auc"), "top": oos.get("top_decile_R"), "bottom": oos.get("bottom_decile_R"), "ls": oos.get("long_short"),
                  "hit": oos.get("top_decile_hit"), "base": oos.get("base_rate"),
                  "deciles": [{"decile": d["decile"], "avg": d.get("avg_R"), "hit": d.get("hit")} for d in oos.get("deciles", [])],
                  "folds": [{"test": f.get("test"), "ic": f.get("ic_mean"), "auc": f.get("auc"), "top": f.get("top_decile_R")} for f in mt.get("folds", [])],
                  "importance": [{"label": i.get("label") or i.get("feature"), "gain": i.get("gain") or i.get("importance")} for i in (v.get("importance") or [])[:12]]}
    thr = st.get("throughput") or {}
    return out, {"engine": st.get("engine"), "features": st.get("n_features"), "values": thr.get("values"), "seconds": thr.get("seconds"),
                 "perSec": thr.get("values_per_sec"), "rawBars": thr.get("raw_bars"), "panelRows": thr.get("panel_rows"),
                 "predictedAt": st.get("last_prediction_date")}


def export(out: Path) -> dict:
    from app.ai import assistant
    from app.data import secdata
    from app.data.universe import MARKET_SYMBOLS
    from app.engine import pipeline, scanner, signals
    t0 = time.time()
    tmp = out.with_name(out.name + ".tmp")
    if tmp.exists():
        shutil.rmtree(tmp)
    (tmp / "s").mkdir(parents=True)
    ctx = db.kv_get("last_context", {}) or {}
    res = scanner.latest_results()
    if not res:
        raise SystemExit("Δεν υπάρχουν αποτελέσματα scan για εξαγωγή")
    by_t = {x["ticker"]: x for x in res}
    sigs = signals.list_signals("active")
    sigs.sort(key=signals._rank_key, reverse=True)
    allsig = signals.list_signals("all", 2000)
    cache = {"signals": allsig}

    # -------- shards: πλήρης ανάλυση ανά μετοχή
    pctx = None
    n_sh, bytes_sh = 0, 0
    for i, t in enumerate(by_t):
        b = CAPTURED.get(t)
        if b is None:
            if pctx is None:
                pctx = pipeline.Context.build(ctx.get("breadth"), ctx.get("member_scores"))
            try:
                b = pipeline.analyze_ticker(t, pctx)
            except Exception:  # noqa: BLE001
                log.exception("analyze %s", t)
                continue
            if not b.get("ok"):
                continue
        try:
            bytes_sh += dump(tmp / "s" / f"{t.replace('/', '_')}.json", stock_shard(t, b, cache))
            n_sh += 1
        except Exception:  # noqa: BLE001
            log.exception("shard %s", t)
        if i % 500 == 0:
            step(f"Εξαγωγή μετοχών: {i}/{len(by_t)}")
    # δείκτες αγοράς / ETF κλάδων: μόνο τιμές για γράφημα
    for sym in [*MARKET_SYMBOLS, *[s.get("etf") for s in ctx.get("sectors") or [] if s.get("etf")]]:
        if not sym or sym in by_t:
            continue
        df = db.load_prices(sym, start=(date.today() - timedelta(days=560)).isoformat())
        if len(df) < 30:
            continue
        c = df["close"]
        dump(tmp / "s" / f"{sym.replace('^', '_')}.json", {"v": 2, "ticker": sym, "name": sym, "index": True,
             "asOf": df.index[-1].strftime("%Y-%m-%d"), "price": r(c.iloc[-1]), "chg": r((c.iloc[-1] / c.iloc[-2] - 1) * 100, 2),
             "bars": {"d": [x.strftime("%Y-%m-%d") for x in df.index], "o": [r(x) for x in df["open"]], "h": [r(x) for x in df["high"]],
                      "l": [r(x) for x in df["low"]], "c": [r(x) for x in c], "v": [int(x or 0) for x in df["volume"].fillna(0)]}})

    # -------- snapshot
    def spark(sym, n=40):
        rows = db.q("SELECT close FROM prices_daily WHERE ticker=? ORDER BY date DESC LIMIT ?", (sym, n))
        return [r(x["close"]) for x in reversed(rows)]

    idx = {}
    for sym in ("SPY", "QQQ", "DIA", "IWM", "^VIX"):
        sp = spark(sym, 41)
        if len(sp) >= 2:
            idx[sym] = {"p": sp[-1], "ch": r((sp[-1] / sp[-2] - 1) * 100, 2) if sp[-2] else None, "sp": sp[-40:]}
    rows = []
    for x in res:
        rows.append({"t": x["ticker"], "n": x.get("name") or "", "sec": x.get("sector"), "p": r(x.get("price")), "ch": r(x.get("change_pct"), 2),
                     "s": x.get("score"), "b": x.get("bias"), "ml": x.get("ml"), "r5": r(x.get("rank5"), 3), "r21": r(x.get("rank21"), 3),
                     "mv": x.get("ml_val") or {}, "rv": x.get("rvol"), "m1": x.get("ret21"), "m3": x.get("ret63"), "atr": x.get("atr_pct"),
                     "rsi": x.get("rsi"), "dv": r(x.get("dollar_vol"), 0), "mc": r(x.get("market_cap"), 0), "pe": x.get("forward_pe"),
                     "cats": x.get("categories", []), "set": [s for s in x.get("setups", [])], "srank": x.get("sector_rank"),
                     "sn": x.get("sector_n"), "sp": [r(v, 3) for v in (x.get("spark") or [])[-30:]]})
    opp = []
    for s in sigs:
        x = by_t.get(s["ticker"]) or {}
        opp.append({"ticker": s["ticker"], "name": x.get("name"), "sector": x.get("sector"), "horizon": s["horizon"], "bias": s["bias"],
                    "setup": s.get("setup"), "price": r(s["price"]), "cur": r(x.get("price")), "chg": r(x.get("change_pct"), 2),
                    "entryLow": r(s["entry_low"]), "entryHigh": r(s["entry_high"]), "entry": r((s["entry_low"] + s["entry_high"]) / 2),
                    "stop": r(s["stop"]), "tp1": r(s["tp1"]), "tp2": r(s["tp2"]), "tp3": r(s["tp3"]), "rr": s.get("rr"),
                    "stopPct": r(abs(1 - s["stop"] / ((s["entry_low"] + s["entry_high"]) / 2)) * 100, 2), "holding": s.get("holding"),
                    "score": s.get("score"), "confidence": s.get("confidence"), "status": s["status"], "created": s["created_at"],
                    "rank": r(s.get("rank_pct"), 3), "mlP": r(s.get("ml_p"), 3), "mlR": r(s.get("ml_exp_r"), 3),
                    "conflicts": s.get("conflicts", []), "risks": s.get("risks", []), "catalysts": s.get("catalysts", []),
                    "history": s.get("history", [])[-6:], "spark": [r(v, 3) for v in (x.get("spark") or [])[-30:]]})
    hist = [{"ticker": s["ticker"], "horizon": s["horizon"], "setup": s.get("setup"), "date": s["created_at"][:10],
             "status": s["status"], "outcome": s.get("outcome"), "ret": r(s.get("outcome_return"), 2), "closed": (s.get("closed_at") or "")[:10],
             "price": r(s["price"]), "stop": r(s["stop"]), "tp2": r(s["tp2"])} for s in allsig[:400]]
    news = db.q("SELECT ticker,title,source,published_at,category,sentiment,url FROM news WHERE is_primary=1 "
                "ORDER BY published_at DESC LIMIT 40")
    model, stats = model_out()
    first = (db.q1("SELECT MIN(date) d FROM prices_daily WHERE ticker='SPY'") or {}).get("d")
    last = (db.q1("SELECT MAX(date) d FROM prices_daily WHERE ticker='SPY'") or {}).get("d")
    run = db.q1("SELECT * FROM scan_runs WHERE status='ok' ORDER BY started_at DESC LIMIT 1") or {}
    snap = {
        "v": 2, "builtAt": datetime.now(timezone.utc).isoformat(timespec="seconds"), "asOf": last, "firstDate": first,
        "universe": ctx.get("universe_n"), "analyzed": len(rows),
        "historyYears": settings.history_years, "histTickers": (db.q1("SELECT COUNT(DISTINCT ticker) n FROM prices_daily") or {}).get("n"),
        "market": {**(ctx.get("market") or {}), "simple": assistant.simple_market().get("lines")},
        "idx": idx,
        "sectors": [{"sector": s.get("sector"), "etf": s.get("etf"), "rel21": r(s.get("rel21"), 2), "ret21": r(s.get("ret21"), 2),
                     "ret1": r(s.get("ret1"), 2), "score": s.get("score")} for s in (ctx.get("sectors") or [])],
        "signals": opp, "rows": rows, "cats": scanner.CATEGORY_LABELS, "model": model, "stats": stats,
        "sigStats": signals.stats(), "hist": hist,
        "news": [{"t": n["ticker"], "title": n["title"], "source": n["source"], "at": n["published_at"], "cat": n["category"],
                  "sent": r(n["sentiment"], 2), "url": n["url"]} for n in news],
        "sec": {k: v for k, v in (secdata.status() or {}).items() if isinstance(v, (int, float, str, bool, type(None)))},
        "run": {"id": run.get("run_id"), "finished": run.get("finished_at"), "notes": (run.get("notes") or "")[:1500]},
        "shards": n_sh,
    }
    sz = dump(tmp / "snapshot.json", snap)
    if out.exists():
        shutil.rmtree(out)
    tmp.rename(out)
    step(f"Εξαγωγή: {n_sh} μετοχές ({bytes_sh / 1e6:.1f} MB), snapshot {sz / 1e6:.2f} MB, {time.time() - t0:.0f} δευτ.")
    return {"shards": n_sh, "snapshot_bytes": sz}


def main() -> None:
    global BUDGET
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    ap.add_argument("--budget-min", type=float, default=300)
    ap.add_argument("--export-only", action="store_true")
    a = ap.parse_args()
    BUDGET = a.budget_min * 60
    db.init_db()
    from app.data import secdata
    secdata.init()
    install_capture()
    if not a.export_only:
        run_pipeline()
    export(Path(a.out).resolve())
    step("Τέλος")


if __name__ == "__main__":
    main()
