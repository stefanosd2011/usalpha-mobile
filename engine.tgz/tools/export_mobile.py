"""US Alpha — καθημερινή ανάλυση στο cloud (GitHub Actions) για την εφαρμογή κινητού.

Τρέχει ΤΟΝ ΙΔΙΟ αλγόριθμο με το πρόγραμμα του υπολογιστή (scanner, LightGBM, SEC, setups, signals)
και γράφει έτοιμα αρχεία JSON που διαβάζει η εφαρμογή:
  <out>/snapshot.json      αγορά, ευκαιρίες, όλη η λίστα μετοχών, μοντέλο, ειδήσεις, ιστορικό signals
  <out>/s/<TICKER>.json    πλήρης ανάλυση + ημερήσιες τιμές για κάθε μετοχή

Δεν χρειάζεται κανένα API key (Yahoo, Nasdaq, SEC). Τα δεδομένα μένουν στο cache του GitHub
ώστε κάθε μέρα να κατεβαίνει μόνο η νέα μέρα.

Χρήση:  python tools/export_mobile.py --out ../_site/data [--budget-min 300] [--export-only]
"""
from __future__ import annotations

import argparse
import json
import logging
import math
import os
import shutil
import sys
import time
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.environ.setdefault("USALPHA_NO_SCHEDULER", "1")

from app import db  # noqa: E402
from app.config import settings  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("usalpha.export")
T0 = time.time()
BUDGET = 300 * 60


def left() -> float:
    return BUDGET - (time.time() - T0)


STEPS: list[str] = []


def step(msg: str) -> None:
    log.info("[%5.1f′] %s", (time.time() - T0) / 60, msg)
    STEPS.append(f"[{(time.time() - T0) / 60:5.1f}′] {msg}"[:600])


# ------------------------------------------------------------------ βοηθητικά
from app.mobile_data import clean, r  # noqa: E402  (κοινές συναρτήσεις με τον υπολογιστή)


def dump(path: Path, data) -> int:
    path.parent.mkdir(parents=True, exist_ok=True)
    txt = json.dumps(clean(data), ensure_ascii=False, separators=(",", ":"), default=str)
    path.write_text(txt, encoding="utf-8")
    return len(txt)


# ------------------------------------------------------------------ pipeline (ίδια σειρά με το πρόγραμμα του υπολογιστή)
CAPTURED: dict[str, dict] = {}


def install_capture():
    """Κρατά κάθε πλήρη ανάλυση του scanner ώστε να εξαχθεί χωρίς να ξαναϋπολογιστεί."""
    from app.engine import pipeline
    orig = pipeline.analyze_ticker

    def wrapped(t, ctx, *a, **kw):
        b = orig(t, ctx, *a, **kw)
        if isinstance(b, dict) and b.get("ok"):
            CAPTURED[t] = b
        return b
    pipeline.analyze_ticker = wrapped


def scan(update_data: bool, fetch_companies: bool) -> dict:
    from app.engine import scanner
    CAPTURED.clear()
    r_ = scanner.run_scan(update_data=update_data, fetch_companies=fetch_companies,
                          max_company_fetch=min(settings.deep_n, 150))
    step(f"scan: {r_.get('status')} · {r_.get('analyzed')} μετοχές · notes: {'; '.join(r_.get('notes', []))[:600]}")
    return r_


def eod_lifecycle() -> int:
    """Οι ευκαιρίες ελέγχονται με τις ημερήσιες τιμές (υψηλό/χαμηλό). Αν την ίδια μέρα πιάστηκαν
    και stop και στόχος, μετράει το stop (συντηρητικά)."""
    from app.engine import signals as S
    done = db.kv_get("eod_lifecycle", {}) or {}
    n = 0
    for s in db.q(f"SELECT * FROM signals WHERE status IN {S.ACTIVE}"):
        t, long = s["ticker"], s["bias"] == "bullish"
        since = done.get(str(s["id"])) or s["created_at"][:10]
        df = db.load_prices(t, start=since)
        df = df[df.index.strftime("%Y-%m-%d") > since]
        if df.empty:
            continue
        status, stop = s["status"], s["stop"]
        hist = json.loads(s["history_json"] or "[]")
        closed = None
        days = 0
        for d, row in df.iterrows():
            days += 1
            ds = d.strftime("%Y-%m-%d")
            hi, lo, cl = float(row["high"]), float(row["low"]), float(row["close"])
            if status == "new" and lo <= s["entry_high"] and hi >= s["entry_low"]:
                status = "active"
                hist.append({"at": ds, "event": "Μπήκε στη ζώνη εισόδου", "price": r(min(max(s["entry"] if "entry" in s.keys() else cl, lo), hi))})
            lost = lo <= stop if long else hi >= stop
            if lost:
                ret = (stop / s["price"] - 1) * (1 if long else -1) * 100
                closed = ("closed", "stop" if status in ("new", "active") else f"stop μετά από {status.upper()}", ret, ds)
                break
            order = ["new", "active", "tp1", "tp2", "tp3"]
            for lvl in ("tp1", "tp2", "tp3"):
                hit = hi >= s[lvl] if long else lo <= s[lvl]
                if order.index(status) < order.index(lvl) and hit:
                    status = lvl
                    if lvl == "tp1":
                        stop = s["price"]
                    elif lvl == "tp2":
                        stop = s["tp1"]
                    hist.append({"at": ds, "event": f"Χτυπήθηκε {lvl.upper()} {s[lvl]:.2f}", "price": r(s[lvl]), "stop": r(stop)})
            if status == "tp3":
                closed = ("closed", "tp3", (s["tp3"] / s["price"] - 1) * (1 if long else -1) * 100, ds)
                break
            if S._trading_days_since(s["created_at"]) > S.HORIZONS[s["horizon"]]["max_days"] and d == df.index[-1]:
                closed = ("expired", "expired", (cl / s["price"] - 1) * (1 if long else -1) * 100, ds)
                break
        if closed:
            db.execute("UPDATE signals SET status=?, closed_at=?, outcome=?, outcome_return=?, history_json=? WHERE id=?",
                       (closed[0], closed[3], closed[1], closed[2], json.dumps(hist), s["id"]))
        else:
            db.execute("UPDATE signals SET status=?, stop=?, history_json=? WHERE id=?",
                       (status, stop, json.dumps(hist), s["id"]))
        done[str(s["id"])] = df.index[-1].strftime("%Y-%m-%d")
        n += 1
    db.kv_set("eod_lifecycle", done)
    return n


NASDAQ_SECTOR = {"Technology": "Technology", "Health Care": "Healthcare", "Finance": "Financial Services",
                 "Consumer Discretionary": "Consumer Cyclical", "Consumer Staples": "Consumer Defensive",
                 "Industrials": "Industrials", "Energy": "Energy", "Utilities": "Utilities", "Real Estate": "Real Estate",
                 "Basic Materials": "Basic Materials", "Telecommunications": "Communication Services"}


def alt_meta() -> int:
    """Κλάδος / όνομα / κλάδος δραστηριότητας για όλη την αγορά με μία κλήση (Nasdaq screener).
    Χρησιμοποιείται μόνο όπου λείπουν τα στοιχεία από Yahoo/SEC."""
    import httpx
    db.execute("CREATE TABLE IF NOT EXISTS meta_alt (ticker TEXT PRIMARY KEY, name TEXT, sector TEXT, industry TEXT, "
               "market_cap REAL, updated_at TEXT)")
    n = (db.q1("SELECT COUNT(*) n FROM meta_alt WHERE sector IS NOT NULL") or {}).get("n") or 0
    at = db.kv_get("meta_alt_at")
    if n > 1000 and at and (datetime.now(timezone.utc) - datetime.fromisoformat(at)).days < 7:
        return n
    try:
        r = httpx.get("https://api.nasdaq.com/api/screener/stocks", params={"tableonly": "true", "limit": "10000", "download": "true"},
                      headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
                               "Chrome/126.0 Safari/537.36", "Accept": "application/json, text/plain, */*",
                               "Accept-Language": "en-US,en;q=0.9", "Origin": "https://www.nasdaq.com", "Referer": "https://www.nasdaq.com/"},
                      timeout=60)
        r.raise_for_status()
        rows = ((r.json().get("data") or {}).get("rows")) or []
    except Exception as e:  # noqa: BLE001
        step(f"Nasdaq screener (κλάδοι): απέτυχε {e}")
        return n
    now = db.now_iso()
    out = []
    for x in rows:
        t = (x.get("symbol") or "").strip().upper().replace("/", "-")
        if not t:
            continue
        try:
            mc = float(str(x.get("marketCap") or "").replace(",", "") or "nan")
        except ValueError:
            mc = None
        nm = (x.get("name") or "").replace(" Common Stock", "").replace(" Class A", " (A)").strip() or None
        out.append((t, nm, NASDAQ_SECTOR.get((x.get("sector") or "").strip()), (x.get("industry") or "").strip() or None,
                    mc if mc == mc else None, now))
    db.executemany("INSERT OR REPLACE INTO meta_alt(ticker,name,sector,industry,market_cap,updated_at) VALUES(?,?,?,?,?,?)", out)
    db.kv_set("meta_alt_at", now)
    step(f"Nasdaq screener: {len(out)} μετοχές με κλάδο")
    return len(out)


def sec_probe() -> bool:
    """Η SEC θέλει δηλωμένο User-Agent. Δοκιμάζει παραλλαγές και κρατά όποια περνά."""
    import httpx
    base = settings.sec_user_agent
    cands = list(dict.fromkeys([base, "Stefanos Dimitropoulos stefanosd2011@users.noreply.github.com",
                                "USAlpha stefanosd2011@users.noreply.github.com"]))
    for ua in cands:
        try:
            r = httpx.get("https://www.sec.gov/files/company_tickers.json", headers={"User-Agent": ua, "Accept-Encoding": "gzip, deflate"},
                          timeout=30)
            step(f"SEC έλεγχος ({ua}): HTTP {r.status_code}")
            if r.status_code == 200:
                settings.sec_user_agent = ua
                return True
        except Exception as e:  # noqa: BLE001
            step(f"SEC έλεγχος: σφάλμα {e}")
        time.sleep(1)
    # μπλοκαρισμένη από εδώ: παράλειψη των κλήσεων SEC ώστε να μη χάνεται χρόνος σε αποτυχίες
    from app.data import sec as secmod
    secmod.recent_filings = lambda *a, **k: []
    return False


def run_pipeline() -> None:
    from app.data import secdata
    from app.jobs import scheduler
    from app.ml import features as MLF
    from app.ml import model as mlmodel

    step(f"Ιστορικό {settings.history_years} ετών, ML έως {settings.ml_max_tickers} μετοχές")
    # εγγραφές εταιρειών χωρίς στοιχεία (αποτυχία Yahoo) δεν πρέπει να κρύβουν το snapshot του screener
    db.execute("DELETE FROM company WHERE name IS NULL OR name=''")
    sec_ok = sec_probe()
    alt_meta()
    try:
        n = eod_lifecycle()
        step(f"Έλεγχος ενεργών ευκαιριών με τις νέες τιμές: {n}")
    except Exception:  # noqa: BLE001
        log.exception("lifecycle")
    try:
        if db.kv_get("last_run_id"):
            scheduler.job_news()
            step("Ειδήσεις")
    except Exception:  # noqa: BLE001
        log.exception("news")

    r1 = scan(update_data=True, fetch_companies=True)
    if r1.get("status") != "ok":
        raise SystemExit("Το scan απέτυχε: " + str(r1.get("error")))

    age = mlmodel.model_age_days()
    stale = any(mlmodel.load(h) is None for h in MLF.HORIZONS)
    sec_n = (secdata.status() or {}).get("companies") or 0
    if ((age is None or age >= settings.ml_retrain_days or stale) or (sec_ok and sec_n < 500)) and left() > 75 * 60:
        if sec_ok:
            try:
                from app.data.listings import universe_tickers
                step("SEC: επίσημα οικονομικά στοιχεία και ημερομηνίες αποτελεσμάτων")
                secdata.sync_all(universe_tickers(settings.ml_max_tickers))
            except Exception:  # noqa: BLE001
                log.exception("SEC sync failed")
        else:
            step("SEC: δεν είναι προσβάσιμη από εδώ σήμερα, το μοντέλο εκπαιδεύεται χωρίς τα στοιχεία της")
        step("Εκπαίδευση μοντέλου πρόβλεψης (LightGBM, walk-forward)")
        tr = mlmodel.train_all()
        step(f"Εκπαίδευση: {tr.get('status')} · επικυρωμένα: "
             f"{[h for h, v in (tr.get('results') or {}).items() if v.get('validated')]}")
        if tr.get("status") == "ok":
            scan(update_data=False, fetch_companies=False)
    # μοντέλο v4 δίπλα στο v3: εκπαιδεύονται όσοι ορίζοντες λείπουν ή είναι παλιοί, μέσα στον διαθέσιμο χρόνο.
    # Ό,τι δεν προλάβει συνεχίζεται την επόμενη μέρα. Σφάλμα εδώ δεν επηρεάζει το υπόλοιπο.
    try:
        from app.ml import v4 as ml4
        ml4.init()
        stale4 = [h for h in ml4.ORDER if ml4._stale(h, settings.ml_retrain_days)]
        if stale4 and left() > 90 * 60:
            step(f"Μοντέλο v4: εκπαίδευση {', '.join(stale4)} και σύγκριση με το v3 στις ίδιες περιόδους")
            r4 = ml4.train_all(only_stale=True, deadline=time.time() + left() - 30 * 60)
            res4 = r4.get("results") or {}
            step(f"Μοντέλο v4: {r4.get('status')} {r4.get('error') or ''} · "
                 + "; ".join(f"{h}: {'ΕΝΕΡΓΟ' if v.get('active') else ('επικυρωμένο' if v.get('validated') else 'όχι')} "
                             f"({' · '.join(v.get('compare') or [])}, {v.get('seconds')} δευτ.)" for h, v in res4.items())
                 + (f" · επόμενη φορά: {', '.join(r4.get('skipped') or [])}" if r4.get("skipped") else ""))
            if any(v.get("active") for v in res4.values()):
                scan(update_data=False, fetch_companies=False)
        elif stale4:
            step(f"Μοντέλο v4: δεν φτάνει ο χρόνος σήμερα ({left() / 60:.0f}′), συνεχίζει την επόμενη φορά")
    except Exception:  # noqa: BLE001
        log.exception("v4")
    try:
        if db.kv_get("last_run_id"):
            from app.report import daily
            daily.build()
    except Exception:  # noqa: BLE001
        log.exception("report")


# ------------------------------------------------------------------ εξαγωγή
def export(out: Path) -> dict:
    from app import mobile_data as MD
    from app.data.universe import MARKET_SYMBOLS
    t0 = time.time()
    tmp = out.with_name(out.name + ".tmp")
    if tmp.exists():
        shutil.rmtree(tmp)
    (tmp / "s").mkdir(parents=True)
    cx = MD.Ctx()
    if not cx.res:
        raise SystemExit("Δεν υπάρχουν αποτελέσματα scan για εξαγωγή")
    n_sh, bytes_sh = 0, 0
    for i, t in enumerate(cx.by_t):
        try:
            d = MD.shard(t, CAPTURED.get(t), cx)
            if d:
                bytes_sh += dump(tmp / "s" / f"{t.replace('/', '_')}.json", d)
                n_sh += 1
        except Exception:  # noqa: BLE001
            log.exception("shard %s", t)
        if i % 500 == 0:
            step(f"Εξαγωγή μετοχών: {i}/{len(cx.by_t)}")
    # δείκτες αγοράς / ETF κλάδων: μόνο τιμές για γράφημα
    for sym in [*MARKET_SYMBOLS, *[s.get("etf") for s in cx.ctx.get("sectors") or [] if s.get("etf")]]:
        if sym and sym not in cx.by_t:
            d = MD.index_shard(sym)
            if d:
                dump(tmp / "s" / f"{sym.replace('^', '_')}.json", d)
    snap = MD.snapshot(cx, n_sh)
    sz = dump(tmp / "snapshot.json", snap)
    # σημειώσεις AI (μόνο αν υπάρχει το κρυφό GEMINI_API_KEY· το κλειδί δεν γράφεται πουθενά)
    try:
        from app.ai import notes
        ai = notes.build(snap) if left() > 8 * 60 else None
        if ai:
            dump(tmp / "ai.json", ai)
        step("Σημειώσεις AI: " + (f"σύνοψη αγοράς και {len(ai['stocks'])} μετοχές" if ai else "όχι σήμερα (χωρίς κλειδί ή χωρίς απάντηση)"))
    except Exception:  # noqa: BLE001
        log.exception("ai notes")
    # μικρή αναφορά για τα μοντέλα (v3 και v4 δίπλα-δίπλα) — αποθηκεύεται και στο repository για ιστορικό
    try:
        rep_ = {"builtAt": snap.get("builtAt"), "asOf": snap.get("asOf"), "run": snap.get("run"), "stats": snap.get("stats"),
                "v3": {h: {k: v.get(k) for k in ("validated", "ic", "icT", "auc", "top", "hit", "base", "gate", "createdAt")}
                       for h, v in (snap.get("model") or {}).items()},
                "v4": {k: v for k, v in (snap.get("model4") or {}).items() if k != "models"},
                "v4_models": {h: {k: v.get(k) for k in ("validated", "active", "better", "notes", "gate", "v3gate", "v4", "v3",
                                                         "createdAt", "seconds", "rows", "engine", "importance")}
                              for h, v in ((snap.get("model4") or {}).get("models") or {}).items()},
                "steps": STEPS[-80:]}
        dump(tmp / "model_report.json", rep_)
    except Exception:  # noqa: BLE001
        log.exception("model report")
    if out.exists():
        shutil.rmtree(out)
    tmp.rename(out)
    step(f"Εξαγωγή: {n_sh} μετοχές ({bytes_sh / 1e6:.1f} MB), snapshot {sz / 1e6:.2f} MB, {time.time() - t0:.0f} δευτ.")
    return {"shards": n_sh, "snapshot_bytes": sz}


def main() -> None:
    global BUDGET
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    ap.add_argument("--budget-min", type=float, default=300)
    ap.add_argument("--export-only", action="store_true")
    a = ap.parse_args()
    BUDGET = a.budget_min * 60
    db.init_db()
    from app.data import secdata
    secdata.init()
    install_capture()
    if not a.export_only:
        run_pipeline()
    export(Path(a.out).resolve())
    step("Τέλος")


if __name__ == "__main__":
    main()
