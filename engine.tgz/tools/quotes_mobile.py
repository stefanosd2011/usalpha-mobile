"""US Alpha Mobile — τιμές μέσα στη μέρα, χωρίς κωδικούς.

Τρέχει στο GitHub Actions κάθε 30 λεπτά όσο είναι ανοιχτή η αγορά ΗΠΑ. Παίρνει την τρέχουσα τιμή
(Yahoo, πιθανή καθυστέρηση ~15′) για όλες τις μετοχές της βραδινής ανάλυσης και γράφει <site>/data/quotes.json.

Χρήση:  python tools/quotes_mobile.py <φάκελος_site> [--force]
Γράφει "deploy=true|false" στο $GITHUB_OUTPUT.
"""
from __future__ import annotations

import json
import math
import os
import sys
import time
import warnings
from datetime import datetime, time as dtime, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

warnings.filterwarnings("ignore")
NY = ZoneInfo("America/New_York")


def out(deploy: bool, msg: str) -> None:
    print(msg)
    f = os.getenv("GITHUB_OUTPUT")
    if f:
        with open(f, "a", encoding="utf-8") as fh:
            fh.write(f"deploy={'true' if deploy else 'false'}\n")


def main() -> None:
    site = Path(sys.argv[1])
    force = "--force" in sys.argv
    snap_p = site / "data" / "snapshot.json"
    if not snap_p.exists():
        return out(False, "Δεν υπάρχει ακόμα βραδινή ανάλυση (snapshot.json)")
    now = datetime.now(NY)
    open_now = now.weekday() < 5 and dtime(9, 25) <= now.time() <= dtime(16, 35)
    if not open_now:
        # εκτός ωραρίου: μόνο νέα έκδοση εφαρμογής (αν ζητήθηκε), χωρίς τιμές
        (site / "data" / "quotes.json").unlink(missing_ok=True)
        return out(force, f"Αγορά κλειστή ({now:%a %H:%M} Ν. Υόρκη)")
    snap = json.loads(snap_p.read_text(encoding="utf-8"))
    tickers = [r["t"] for r in snap.get("rows", [])]
    tickers += [t for t in ("SPY", "QQQ", "DIA", "IWM", "^VIX") if t not in tickers]
    import yfinance as yf
    day = now.strftime("%Y-%m-%d")
    q: dict[str, list] = {}
    for i in range(0, len(tickers), 250):
        part = tickers[i:i + 250]
        for attempt in range(3):
            try:
                df = yf.download(part, period="5d", interval="1d", group_by="ticker", auto_adjust=False,
                                 threads=True, progress=False, multi_level_index=True)
                break
            except Exception as e:  # noqa: BLE001
                print("retry", i, e)
                time.sleep(5 * (attempt + 1))
        else:
            continue
        for t in part:
            try:
                sub = df[t].dropna(subset=["Close"]) if t in set(df.columns.get_level_values(0)) else None
            except Exception:  # noqa: BLE001
                sub = None
            if sub is None or len(sub) < 2 or sub.index[-1].strftime("%Y-%m-%d") != day:
                continue
            p, prev = float(sub["Close"].iloc[-1]), float(sub["Close"].iloc[-2])
            if not (math.isfinite(p) and math.isfinite(prev) and prev > 0):
                continue
            q[t] = [round(p, 4), round((p / prev - 1) * 100, 2)]
        time.sleep(0.5)
    if len(q) < 50:
        return out(force, f"Λίγες τιμές ({len(q)}): πιθανή αργία ή πρόβλημα πηγής")
    (site / "data" / "quotes.json").write_text(json.dumps(
        {"at": datetime.now(timezone.utc).isoformat(timespec="seconds"), "day": day, "q": q},
        separators=(",", ":")), encoding="utf-8")
    out(True, f"Τιμές: {len(q)} μετοχές, {now:%H:%M} Ν. Υόρκη")


if __name__ == "__main__":
    main()
