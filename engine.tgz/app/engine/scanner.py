"""Advanced stock scanner: εξετάζει όλο το σύμπαν, κατηγοριοποιεί ευκαιρίες, συγκρίνει με
τον κλάδο, αποθηκεύει scores/predictions και δημιουργεί signals."""
from __future__ import annotations

import json
import logging
import uuid
from datetime import date, timedelta

import numpy as np

from .. import db
from ..data import service
from ..data.universe import MARKET_SYMBOLS, etf_universe, full_universe
from . import pipeline, signals

log = logging.getLogger("usalpha.scanner")

CATEGORY_LABELS = {
    "ml_top": "Top πρόβλεψη ML", "undervalued": "Υποτιμημένες", "high_growth": "Υψηλή ανάπτυξη", "momentum": "Momentum",
    "breakout": "Breakout υποψήφιες", "high_volatility": "Υψηλή μεταβλητότητα", "unusual_volume": "Ασυνήθιστος όγκος",
    "small_cap": "Small cap ευκαιρίες", "short_squeeze": "Short squeeze υποψήφιες", "catalyst": "Σημαντικά catalysts",
    "reversal": "Πιθανή αντιστροφή τάσης",
}

_progress = {"running": False, "step": "", "done": 0, "total": 0, "run_id": None}


def progress() -> dict:
    return dict(_progress)


def categorize(b: dict) -> list[str]:
    if not b.get("ok"):
        return []
    t, f = b["tech"], b["fund"]
    fl = set(t.get("flags", [])) | set(f.get("flags", []))
    m, fm = t.get("metrics", {}), f.get("metrics", {})
    cats = []
    if "cheap_vs_sector" in fl and f.get("score", 0) >= 55:
        cats.append("undervalued")
    if (fm.get("revenue_growth") or 0) > 0.25:
        cats.append("high_growth")
    if t.get("momentum_score", 0) >= 65 and "trend_up" in fl:
        cats.append("momentum")
    if fl & {"breakout_20", "breakout_55", "squeeze"}:
        cats.append("breakout")
    if (m.get("atr_pct") or 0) > 5:
        cats.append("high_volatility")
    if (m.get("rvol") or 0) >= 2:
        cats.append("unusual_volume")
    mc = fm.get("market_cap")
    if mc and 300e6 <= mc <= 2e9 and b["scored"]["score"] >= 55:
        cats.append("small_cap")
    if (fm.get("short_pct_float") or 0) >= 0.15 and (m.get("rvol") or 0) >= 1.5 and (m.get("ret5") or 0) > 0 \
            and (fm.get("short_ratio") or 0) >= 2:
        cats.append("short_squeeze")
    if "earnings_soon" in fl or any(n.get("importance", 0) >= 0.75 for n in b["news"].get("top", [])[:3]):
        cats.append("catalyst")
    if fl & {"bull_div", "trend_change_up"} or ("oversold" in fl and (m.get("stoch_k") or 50) > (m.get("stoch_d") or 50)):
        cats.append("reversal")
    return cats


def _deep_set(universe: list[str], ctx_ml: dict, limit: int) -> list[str]:
    """Ποιες μετοχές παίρνουν ΠΛΗΡΗ εταιρική ανάλυση (Yahoo info, insiders, αναλυτές, SEC).
    Όλες οι υπόλοιπες αναλύονται με τα ελαφριά θεμελιώδη του screener."""
    from ..data import universe as core
    pick: list[str] = []
    pick += service.watchlist()
    pick += [r["ticker"] for r in db.q("SELECT DISTINCT ticker FROM signals WHERE status IN ('new','active','tp1','tp2')")]
    pick += [r["ticker"] for r in db.q("SELECT DISTINCT ticker FROM paper_trades WHERE status='open'")]
    ml_rank = sorted(((max((h.get("rank_pct") or 0) for h in v.values() if h.get("validated")) if any(
        h.get("validated") for h in v.values()) else 0, t) for t, v in ctx_ml.items()), reverse=True)
    pick += [t for r, t in ml_rank[: limit // 2] if r > 0]
    prev = latest_results(limit=limit)
    pick += [r["ticker"] for r in prev[: limit // 3]]
    pick += [r["ticker"] for r in sorted(prev, key=lambda r: -(r.get("rvol") or 0))[:30]]
    if not prev:
        pick += core.base_universe()
    uni = set(universe)
    out = [t for t in dict.fromkeys(pick) if t in uni]
    return out[:limit]


def run_scan(update_data: bool = True, fetch_companies: bool = True, max_company_fetch: int | None = None) -> dict:
    from ..config import settings
    from ..data import listings
    from ..ml import model as mlmodel
    if _progress["running"]:
        return {"status": "already_running"}
    run_id = date.today().isoformat() + "-" + uuid.uuid4().hex[:6]
    _progress.update(running=True, step="Ξεκίνημα", done=0, total=0, run_id=run_id)
    db.execute("INSERT INTO scan_runs(run_id,started_at,status) VALUES(?,?,?)", (run_id, db.now_iso(), "running"))
    notes = []
    try:
        wl = service.watchlist()
        if update_data:
            _progress["step"] = "Λίστα ΟΛΩΝ των μετοχών ΗΠΑ (NASDAQ / NYSE / AMEX)"
            u = listings.build_universe()
            notes.append(f"Σύμπαν: {u.get('n')} μετοχές ({u.get('source') or db.kv_get('universe_source')})")
            if u.get("errors"):
                notes.append("Σφάλματα πηγών λίστας: " + "; ".join(u["errors"])[:500])
        universe = list(dict.fromkeys(listings.universe_tickers() + wl)) or full_universe(wl)
        if update_data:
            def cb(i, n):
                _progress.update(step=f"Ιστορικές τιμές: {i}/{n} μετοχές", done=i, total=n)
            r = service.update_history(universe + etf_universe() + list(MARKET_SYMBOLS), progress_cb=cb)
            if r["failed"]:
                notes.append(f"Χωρίς δεδομένα ({len(r['failed'])}): {', '.join(r['failed'][:40])}")
            if r.get("split_refetch"):
                notes.append(f"Splits/αναπροσαρμογές (ξανακατέβηκαν): {', '.join(r['split_refetch'][:40])}")
            if u.get("status") == "fresh":
                _progress["step"] = "Θεμελιώδη όλης της αγοράς (screener)"
                listings.refresh_snapshots()
        from ..ml import features as MLF
        if any(mlmodel.load(h) for h in MLF.HORIZONS):
            _progress["step"] = "Μοντέλο πρόβλεψης: πρόβλεψη για όλη την αγορά"
            try:
                pr = mlmodel.predict_today(universe)
                notes.append(f"ML πρόβλεψη: {pr.get('n')} μετοχές ({pr.get('date')})")
            except Exception as e:  # noqa: BLE001
                notes.append(f"ML πρόβλεψη απέτυχε: {e}")
        prev_ctx = db.kv_get("last_context", {}) or {}
        ctx = pipeline.Context.build(prev_ctx.get("breadth"), prev_ctx.get("member_scores"))
        if fetch_companies:
            deep = _deep_set(universe, ctx.ml, max_company_fetch or settings.deep_n)
            _progress.update(step=f"Πλήρη εταιρικά στοιχεία για {len(deep)} κορυφαίες (cache 24h)", done=0, total=len(deep))
            service.refresh_companies(deep, max_age_hours=24)
            ctx = pipeline.Context.build(prev_ctx.get("breadth"), prev_ctx.get("member_scores"))

        _progress.update(step="Πλήρης ανάλυση & scoring όλης της αγοράς", total=len(universe), done=0)
        start = (date.today() - timedelta(days=620)).isoformat()
        bundles = {}
        today = service.today_ny_str()
        rows_scores, rows_scan, rows_pred = [], [], []
        above50, member = [], {}
        for t in universe:
            _progress["done"] += 1
            try:
                df = db.load_prices(t, start=start)
                if len(df) < 60:
                    continue
                b = pipeline.analyze_ticker(t, ctx, df=df)
            except Exception as e:  # noqa: BLE001
                log.exception("analyze %s", t)
                notes.append(f"{t}: σφάλμα ανάλυσης {e}")
                continue
            if not b.get("ok"):
                continue
            bundles[t] = b
            m = b["tech"]["metrics"]
            if m.get("sma50"):
                above50.append(m["close"] > m["sma50"])
            if b.get("sector"):
                member.setdefault(b["sector"], []).append(b["tech"]["technical_score"])
            sc = b["scored"]
            cats = categorize(b)
            b["categories"] = cats
            prob = sc.get("probability")
            rows_scores.append((t, today, sc["score"], json.dumps(sc["components"]),
                                json.dumps({"explain": sc["explain"], "contributions": sc["contributions"],
                                            "confirmation": sc["confirmation"], "coverage": sc["coverage"]}, default=str),
                                prob["p_up"] if prob else None, db.now_iso()))
            ml = b.get("ml") or {}
            q = b.get("quote") or {}
            rows_scan.append((run_id, t, ",".join(cats), json.dumps({
                "name": b["name"], "sector": b["sector"], "price": q.get("price") or m["close"],
                "change_pct": q.get("change_pct") if q.get("change_pct") is not None else m.get("change_pct"),
                "rvol": m.get("rvol"), "atr_pct": m.get("atr_pct"), "rsi": m.get("rsi"),
                "ret21": m.get("ret21"), "ret63": m.get("ret63"), "dollar_vol": m.get("dollar_vol20"),
                "market_cap": b["fund"]["metrics"].get("market_cap"),
                "forward_pe": b["fund"]["metrics"].get("forward_pe"),
                "rev_growth": b["fund"]["metrics"].get("revenue_growth"),
                "short_pct": b["fund"]["metrics"].get("short_pct_float"),
                "tech": b["tech"]["technical_score"], "fund": b["fund"]["score"], "news": b["news"]["score"],
                "momentum": b["tech"]["momentum_score"], "risk": b["risk"]["score"], "bias": sc["bias"],
                "ml": sc["components"].get("ml"),
                "ml_short": (ml.get("short") or {}).get("p"), "ml_swing": (ml.get("swing") or {}).get("p"),
                "ml_short_r": (ml.get("short") or {}).get("exp_r"), "ml_swing_r": (ml.get("swing") or {}).get("exp_r"),
                "ml_day": (ml.get("day") or {}).get("p"), "ml_day_r": (ml.get("day") or {}).get("exp_r"),
                "rank5": (ml.get("rank5") or {}).get("rank_pct"), "rank5_ex": (ml.get("rank5") or {}).get("exp_r"),
                "rank21": (ml.get("rank21") or {}).get("rank_pct"), "rank21_ex": (ml.get("rank21") or {}).get("exp_r"),
                "ml_val": {h: bool(v.get("validated")) for h, v in ml.items()},
                "spark": [round(float(x), 4) for x in df["close"].tail(40).tolist()],
                "ml_validated": any(v.get("validated") for v in ml.values()),
                "flags": b["tech"]["flags"], "quality": q.get("quality"),
                "setups": [f"{s['horizon']}:{s['bias']}" for s in b["setups"]],
            }, default=str), sc["score"]))
            for h in (5, 20):
                rows_pred.append((t, db.now_iso(), h, sc["score"], prob["p_up"] if prob else None, m["close"],
                                  (date.today() + timedelta(days=int(h * 1.45))).isoformat()))
        breadth = float(np.mean(above50) * 100) if above50 else None
        db.executemany("INSERT OR REPLACE INTO scores(ticker,date,score,components_json,explain_json,calibrated_prob,"
                       "created_at) VALUES(?,?,?,?,?,?,?)", rows_scores)
        db.executemany("INSERT OR REPLACE INTO scan_results(run_id,ticker,categories,metrics_json,score) VALUES(?,?,?,?,?)",
                       rows_scan)
        db.execute("DELETE FROM predictions WHERE substr(made_at,1,10)=? AND resolved=0", (db.now_iso()[:10],))
        db.executemany("INSERT INTO predictions(ticker,made_at,horizon_days,score,prob,price,target_date) "
                       "VALUES(?,?,?,?,?,?,?)", rows_pred)
        _rank_in_sector(run_id)
        _ml_top_category(run_id)

        _progress["step"] = "Δημιουργία & επανέλεγχος signals"
        acc_all = []
        for b in bundles.values():
            acc, _rej = signals.evaluate_setups(b)
            acc_all.extend(acc)
        signals.recheck(bundles, force=not update_data)  # μετά από νέα εκπαίδευση: άμεσος έλεγχος με το μοντέλο
        signals.persist(acc_all)
        trimmed = signals.trim_active()
        if trimmed:
            notes.append(f"Κρατήθηκαν μόνο τα {settings.max_active_per_horizon} καλύτερα signals ανά κατηγορία ({trimmed} έκλεισαν)")
        from ..analysis import market as mkt
        mcond = mkt.market_conditions(breadth)
        try:  # υποψήφιες day trade για την επόμενη συνεδρίαση (ίδιοι κανόνες σε υπολογιστή και κινητό)
            from . import daytrade
            db.kv_set("daytrade", {**daytrade.pick(bundles, mcond), "run_id": run_id, "at": db.now_iso()})
        except Exception as e:  # noqa: BLE001
            log.exception("daytrade")
            notes.append(f"Day trade: σφάλμα {e}")
        db.kv_set("last_context", {"market": mcond, "sectors": mkt.sector_strength(member),
                                   "breadth": breadth, "member_scores": member, "universe_n": len(universe),
                                   "analyzed": len(bundles)})
        db.kv_set("last_run_id", run_id)
        db.execute("UPDATE scan_runs SET finished_at=?, n_tickers=?, n_ok=?, status=?, notes=? WHERE run_id=?",
                   (db.now_iso(), len(universe), len(bundles), "ok", "\n".join(notes)[:4000], run_id))
        return {"status": "ok", "run_id": run_id, "analyzed": len(bundles), "signals_new": len(acc_all), "notes": notes}
    except Exception as e:  # noqa: BLE001
        log.exception("scan failed")
        db.execute("UPDATE scan_runs SET finished_at=?, status=?, notes=? WHERE run_id=?",
                   (db.now_iso(), "error", (str(e) + "\n" + "\n".join(notes))[:2000], run_id))
        return {"status": "error", "error": str(e)}
    finally:
        _progress.update(running=False, step="Ολοκληρώθηκε")


def _ml_top_category(run_id: str) -> None:
    """Κατηγορία «Top πρόβλεψη ML»: top 3% της αγοράς από επικυρωμένο μοντέλο."""
    rows = db.q("SELECT ticker, categories, metrics_json FROM scan_results WHERE run_id=?", (run_id,))
    vals = []
    for r in rows:
        m = json.loads(r["metrics_json"])
        if m.get("ml") is not None:
            vals.append((m["ml"], r))
    if not vals:
        return
    cut = np.quantile([v for v, _ in vals], 0.97)
    upd = []
    for v, r in vals:
        if v >= cut:
            cats = [c for c in (r["categories"] or "").split(",") if c] + ["ml_top"]
            upd.append((",".join(cats), run_id, r["ticker"]))
    db.executemany("UPDATE scan_results SET categories=? WHERE run_id=? AND ticker=?", upd)


def _rank_in_sector(run_id: str) -> None:
    rows = db.q("SELECT ticker, score, metrics_json FROM scan_results WHERE run_id=?", (run_id,))
    by: dict[str, list] = {}
    for r in rows:
        m = json.loads(r["metrics_json"])
        by.setdefault(m.get("sector") or "?", []).append((r["ticker"], r["score"], m))
    upd = []
    for sec, items in by.items():
        scores = [i[1] for i in items]
        med = float(np.median(scores))
        for t, s, m in items:
            m["sector_rank"] = sum(1 for x in scores if x > s) + 1
            m["sector_n"] = len(items)
            m["vs_sector_median"] = round(s - med, 1)
            upd.append((json.dumps(m, default=str), run_id, t))
    db.executemany("UPDATE scan_results SET metrics_json=? WHERE run_id=? AND ticker=?", upd)


_results_cache: dict = {}


def latest_results(category: str | None = None, limit: int = 100000) -> list[dict]:
    run = db.kv_get("last_run_id")
    if not run:
        return []
    if _results_cache.get("run") != run:
        rows = db.q("SELECT * FROM scan_results WHERE run_id=? ORDER BY score DESC", (run,))
        _results_cache.update(run=run, rows=[{"ticker": r["ticker"], "score": r["score"],
                                              "categories": [c for c in (r["categories"] or "").split(",") if c],
                                              **json.loads(r["metrics_json"])} for r in rows])
    out = [dict(r) for r in _results_cache["rows"] if not category or category in r["categories"]]
    return out[:limit]
