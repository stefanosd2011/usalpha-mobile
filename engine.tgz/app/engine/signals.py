"""Trading signal generator με αυστηρά φίλτρα, multi-layer confirmation και 3 χρονικούς ελέγχους.
Δεν προτείνει είσοδο όταν τα δεδομένα είναι ανεπαρκή ή το risk/reward δεν αξίζει."""
from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone

from .. import db
from ..config import settings
from ..data.session import is_trading_day
from . import alerts, confirmation, risk as riskmod
from .strategies import HORIZONS
from ..ml.features import HORIZONS as ML_HORIZONS, RANK_FOR_SIGNAL

GATES = {
    "day": {"score": 55, "tech": 50, "support": 3, "need": {"ml"}, "independent": False},
    "short": {"score": 55, "tech": 58, "support": 3, "need": {"volume"}, "independent": False},
    "swing": {"score": 58, "tech": 52, "support": 3, "need": set(), "independent": True},
    "invest": {"score": 60, "tech": 45, "support": 3, "need": {"fundamentals"}, "independent": True},
}
ACTIVE = ("new", "active", "tp1", "tp2")
RECHECK_MIN_GAP = timedelta(minutes=60)


def evaluate_setups(bundle: dict) -> tuple[list[dict], list[dict]]:
    """Επιστρέφει (accepted, rejected) με αιτιολόγηση για κάθε απόρριψη."""
    accepted, rejected = [], []
    if not bundle.get("ok"):
        return [], []
    sc = bundle["scored"]
    tech, fund = bundle["tech"], bundle["fund"]
    q = bundle.get("quote") or {}
    for s in bundle.get("setups", []):
        g = GATES[s["horizon"]]
        reasons = []
        long = s["bias"] == "bullish"
        is_ml = s["name"].startswith("ML:")
        score = sc["score"] if long else 100 - sc["score"]
        tscore = tech.get("technical_score", 50) if long else 100 - tech.get("technical_score", 50)
        conf = confirmation.evaluate({"tech": tech, "fund": fund, "news": bundle["news"],
                                      "sector_score": bundle.get("sector_score"),
                                      "market": {"score": sc["components"].get("market")},
                                      "ml_score": sc["components"].get("ml")}, s["bias"])
        if score < g["score"] - (5 if is_ml else 0):
            reasons.append(f"Συνολική βαθμολογία {sc['score']:.0f} δεν πληροί το όριο")
        if tscore < g["tech"] and not is_ml:
            reasons.append("Αδύναμη τεχνική εικόνα για αυτή την κατεύθυνση")
        # ---- φίλτρο μοντέλου πρόβλεψης (μόνο όταν είναι επικυρωμένο out-of-sample)
        ml = (bundle.get("ml") or {}).get(s["horizon"]) or {}
        ml_p, ml_r = None, None
        if ml.get("validated") and ml.get("p") is not None and s["horizon"] in ML_HORIZONS:
            ml_p, ml_r = ml["p"], ml.get("exp_r")
            if long and ml_r is not None and ml_r < settings.ml_min_exp_r:
                reasons.append(f"Μοντέλο πρόβλεψης: παρόμοιες περιπτώσεις έδιναν ιστορικά {ml_r:+.2f}R "
                               f"(χρειάζεται τουλάχιστον {settings.ml_min_exp_r:+.2f}R)")
            if not long and (ml.get("rank_pct") or 0) >= 0.7:
                reasons.append("Το μοντέλο βλέπει ανοδικό δυναμικό (top 30% της αγοράς) — σύγκρουση με short")
        # ---- φίλτρο μοντέλου κατάταξης: θα πάει καλύτερα ή χειρότερα από την υπόλοιπη αγορά;
        rk_h = RANK_FOR_SIGNAL.get(s["horizon"])
        rk = (bundle.get("ml") or {}).get(rk_h) or {}
        rank_pct, rank_ex = None, None
        if rk.get("validated") and rk.get("rank_pct") is not None:
            rank_pct, rank_ex = rk["rank_pct"], rk.get("exp_r")
            if long and rank_pct < 0.5:
                reasons.append(f"Μοντέλο κατάταξης: η μετοχή είναι στο κάτω μισό της αγοράς ({rank_pct*100:.0f}%) — "
                               "ιστορικά τέτοιες πάνε χειρότερα από τις υπόλοιπες")
            if not long and rank_pct > 0.5:
                reasons.append(f"Μοντέλο κατάταξης: η μετοχή είναι στο πάνω μισό της αγοράς ({rank_pct*100:.0f}%) — όχι για short")
        if conf["n_support"] < g["support"]:
            reasons.append(f"Μόνο {conf['n_support']} επιβεβαιώσεις (χρειάζονται {g['support']})")
        missing = g["need"] - set(conf["supporting"])
        if missing:
            reasons.append("Λείπει επιβεβαίωση: " + ", ".join(confirmation.CATEGORY_LABELS[m] for m in missing))
        if g["independent"] and not conf["independent_ok"]:
            reasons.append("Δεν υπάρχουν ανεξάρτητες επιβεβαιώσεις εκτός τεχνικής ανάλυσης")
        if s["rr"] < settings.min_rr:
            reasons.append(f"Risk/Reward {s['rr']:.2f} < {settings.min_rr}")
        dv = tech.get("metrics", {}).get("dollar_vol20")
        if dv is None or dv < settings.min_dollar_volume:
            reasons.append("Ανεπαρκής ρευστότητα")
        if q.get("quality") in ("STALE", "NO_DATA"):
            reasons.append("Παλιά/ελλιπή δεδομένα τιμής")
        fm = fund.get("metrics", {})
        dte = fm.get("days_to_earnings")
        risks = [w["text"] for w in bundle["risk"]["warnings"]]
        if dte is not None and 0 <= dte <= {"day": 1, "short": 5, "swing": 25, "invest": 0}[s["horizon"]]:
            if s["horizon"] in ("day", "short"):
                reasons.append(f"Earnings σε {dte} μέρες μέσα στο διάστημα διακράτησης")
            else:
                risks.insert(0, f"Earnings στις {fm.get('earnings_date')} μέσα στο διάστημα διακράτησης")
        item = {**s, "setup": s["name"], "ticker": bundle["ticker"], "name": bundle.get("name"), "score": sc["score"],
                "price": q.get("price") or tech["metrics"]["close"], "confirmation": conf,
                "catalysts": _catalysts(bundle), "risks": risks[:8], "ml_p": ml_p, "ml_exp_r": ml_r,
                "rank_pct": rank_pct, "rank_ex": rank_ex,
                "position": riskmod.position_size(s["entry"], s["stop"])}
        lvl = confirmation.level(conf["n_support"], conf["n_oppose"], 1)
        if lvl == "Χαμηλή" and not reasons:
            reasons.append(f"Χαμηλό επίπεδο επιβεβαίωσης ({conf['n_support']} υπέρ / {conf['n_oppose']} κατά)")
        if reasons:
            rejected.append({**item, "rejected_because": reasons})
        else:
            item["confidence"] = lvl
            accepted.append(item)
    return accepted, rejected


def _catalysts(bundle: dict) -> list[str]:
    out = []
    fm = bundle["fund"].get("metrics", {})
    if fm.get("earnings_date") and (fm.get("days_to_earnings") or 99) <= 30:
        out.append(f"Earnings {fm['earnings_date']}")
    for n in bundle["news"].get("top", [])[:5]:
        if n.get("importance", 0) >= 0.6 and abs(n.get("contribution", 0)) > 0.02:
            out.append(f"{n['published_at'][:10]} · {n['category']}: {n['title'][:90]}")
    if "insider_buying" in bundle["fund"].get("flags", []):
        out.append("Πρόσφατες αγορές insiders")
    if "breakout_20" in bundle["tech"].get("flags", []):
        out.append("Τεχνικό breakout με όγκο")
    return out[:6]


def _rank_key(s: dict) -> tuple:
    """Κατάταξη ευκαιριών: μοντέλο κατάταξης → ιστορικό R του μοντέλου → score → R/R."""
    sc = s.get("score") or 50
    sc = sc if s.get("bias") == "bullish" else 100 - sc
    rk = s.get("rank_pct")
    rk = rk if rk is not None else -1
    if s.get("bias") != "bullish" and rk >= 0:
        rk = 1 - rk
    return (rk, (s.get("ml_exp_r") if s.get("ml_exp_r") is not None else -1), sc, s.get("rr") or 0)


def trim_active() -> int:
    """Κρατά ενεργά μόνο τα top N ανά ορίζοντα· τα υπόλοιπα κλείνουν με σημείωση (δεν διαγράφονται)."""
    n_closed = 0
    for hz in HORIZONS:
        rows = db.q(f"SELECT * FROM signals WHERE status IN {ACTIVE} AND horizon=?", (hz,))
        if len(rows) <= settings.max_active_per_horizon:
            continue
        # όσα έχουν ήδη μπει (active/tp) έχουν προτεραιότητα έναντι των νέων
        rows.sort(key=lambda r: (r["status"] != "new", *_rank_key(r)), reverse=True)
        for r in rows[settings.max_active_per_horizon:]:
            db.execute("UPDATE signals SET status='invalidated', closed_at=?, outcome='trimmed' WHERE id=?",
                       (db.now_iso(), r["id"]))
            n_closed += 1
    return n_closed


def persist(accepted: list[dict]) -> list[int]:
    ids = []
    accepted = sorted(accepted, key=lambda a: _rank_key({**a, "ml_exp_r": a.get("ml_exp_r")}), reverse=True)
    per_hz: dict[str, int] = {}
    for s in accepted:
        per_hz[s["horizon"]] = per_hz.get(s["horizon"], 0) + 1
        if per_hz[s["horizon"]] > settings.max_active_per_horizon:
            continue
        ex = db.q1(f"SELECT * FROM signals WHERE ticker=? AND horizon=? AND bias=? AND status IN {ACTIVE}",
                   (s["ticker"], s["horizon"], s["bias"]))
        if ex:
            continue
        hist = [{"at": db.now_iso(), "event": "created", "price": s["price"], "score": s["score"],
                 "stop": s["stop"], "tp1": s["tp1"], "tp2": s["tp2"], "tp3": s["tp3"]}]
        sid = db.execute(
            "INSERT INTO signals(ticker,horizon,bias,created_at,price,entry_low,entry_high,stop,tp1,tp2,tp3,rr,holding,"
            "score,confidence,confirmations,checks_passed,catalysts_json,risks_json,conflicts_json,status,last_check_at,"
            "history_json,setup,ml_p,ml_exp_r,rank_pct) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (s["ticker"], s["horizon"], s["bias"], db.now_iso(), s["price"], s["entry_low"], s["entry_high"],
             s["stop"], s["tp1"], s["tp2"], s["tp3"], s["rr"], s["holding"], s["score"], s["confidence"],
             s["confirmation"]["n_support"], 1, json.dumps(s["catalysts"]), json.dumps(s["risks"]),
             json.dumps(s["confirmation"]["conflicts"]), "new", db.now_iso(), json.dumps(hist),
             s.get("setup"), s.get("ml_p"), s.get("ml_exp_r"), s.get("rank_pct")))
        ids.append(sid)
        hz = HORIZONS[s["horizon"]]["label"]
        mlt = f", ML {s['ml_p']*100:.0f}%" if s.get("ml_p") is not None else ""
        alerts.add("signal", f"Νέο {hz} signal {s['bias']} {s['ticker']} @ {s['price']:.2f} "
                   f"(stop {s['stop']:.2f}, TP2 {s['tp2']:.2f}, R/R {s['rr']:.1f}{mlt})",
                   s["ticker"], "high", f"signal:{sid}")
    return ids


def recheck(bundles: dict[str, dict], force: bool = False) -> None:
    """Χρονικός επανέλεγχος: κάθε ενεργό signal επανεξετάζεται έως 3 φορές σε διαφορετικές
    στιγμές (≥60'). Επιβεβαίωση ανεβάζει το επίπεδο επιβεβαίωσης — όχι την «πιθανότητα»."""
    now = datetime.now(timezone.utc)
    for s in db.q(f"SELECT * FROM signals WHERE status IN {ACTIVE}"):
        b = bundles.get(s["ticker"])
        if not b or not b.get("ok"):
            continue
        last = datetime.fromisoformat(s["last_check_at"]) if s["last_check_at"] else now - RECHECK_MIN_GAP
        if now - last < RECHECK_MIN_GAP and not force:
            continue
        hist = json.loads(s["history_json"] or "[]")
        conf = confirmation.evaluate({"tech": b["tech"], "fund": b["fund"], "news": b["news"],
                                      "sector_score": b.get("sector_score"),
                                      "market": {"score": b["scored"]["components"].get("market")},
                                      "ml_score": b["scored"]["components"].get("ml")}, s["bias"])
        long = s["bias"] == "bullish"
        sc = b["scored"]["score"]
        still = (sc >= GATES[s["horizon"]]["score"] - 5) if long else (sc <= 100 - GATES[s["horizon"]]["score"] + 5)
        checks = s["checks_passed"]
        event = {"at": db.now_iso(), "score": sc, "support": conf["n_support"], "oppose": conf["n_oppose"]}
        if still and conf["n_support"] >= 3:
            checks = min(3, checks + 1)
            event["event"] = f"check {checks}/3 επιβεβαιώθηκε"
        else:
            event["event"] = "check: ΔΕΝ επιβεβαιώθηκε"
            if conf["n_oppose"] > conf["n_support"]:
                db.execute("UPDATE signals SET status='invalidated', closed_at=?, outcome='invalidated' WHERE id=?",
                           (db.now_iso(), s["id"]))
                alerts.add("signal", f"Ακυρώθηκε signal {s['ticker']} ({s['horizon']}): οι ενδείξεις αντιστράφηκαν",
                           s["ticker"], "medium", f"invalid:{s['id']}")
                continue
        ml = (b.get("ml") or {}).get(s["horizon"]) or {}
        if long and ml.get("validated") and ml.get("p") is not None and s["horizon"] in ML_HORIZONS:
            er = ml.get("exp_r")
            db.execute("UPDATE signals SET ml_p=?, ml_exp_r=? WHERE id=?", (ml["p"], er, s["id"]))
            event["ml_p"] = ml["p"]
            if er is not None and er < 0:
                db.execute("UPDATE signals SET status='invalidated', closed_at=?, outcome='invalidated' WHERE id=?",
                           (db.now_iso(), s["id"]))
                hist.append({**event, "event": f"Ακυρώθηκε: το μοντέλο δείχνει ιστορικά αρνητικό αποτέλεσμα ({er:+.2f}R)"})
                db.execute("UPDATE signals SET history_json=? WHERE id=?", (json.dumps(hist), s["id"]))
                alerts.add("signal", f"Ακυρώθηκε signal {s['ticker']} ({s['horizon']}): το μοντέλο δεν το στηρίζει",
                           s["ticker"], "medium", f"invalid_ml:{s['id']}")
                continue
        if conf["conflicts"]:
            event["conflicts"] = conf["conflicts"]
            alerts.add("conflict", f"{s['ticker']}: {conf['conflicts'][0]}", s["ticker"], "medium",
                       f"conflict:{s['id']}:{checks}")
        hist.append(event)
        lvl = confirmation.level(conf["n_support"], conf["n_oppose"], checks)
        if (sc - (s["score"] or sc)) >= 8 or ((s["score"] or sc) - sc) >= 8:
            alerts.add("score", f"{s['ticker']}: AI Score {s['score']:.0f} → {sc:.0f}", s["ticker"], "info",
                       f"score:{s['id']}:{int(sc)}")
        db.execute("UPDATE signals SET checks_passed=?, confidence=?, confirmations=?, conflicts_json=?, "
                   "last_check_at=?, history_json=?, score=? WHERE id=?",
                   (checks, lvl, conf["n_support"], json.dumps(conf["conflicts"]), db.now_iso(),
                    json.dumps(hist), sc, s["id"]))


def _trading_days_since(iso: str) -> int:
    d0 = datetime.fromisoformat(iso).date()
    d1 = datetime.now(timezone.utc).date()
    n, d = 0, d0
    while d < d1:
        d += timedelta(days=1)
        if is_trading_day(d):
            n += 1
    return n


def update_lifecycle(quotes: dict[str, dict]) -> None:
    """Ενημερώνει κατάσταση signals με βάση τις τιμές: είσοδος, stop, TP1-3, trailing, λήξη."""
    for s in db.q(f"SELECT * FROM signals WHERE status IN {ACTIVE}"):
        q = quotes.get(s["ticker"])
        if not q or q.get("price") is None or q.get("quality") in ("STALE", "NO_DATA"):
            continue
        p = float(q["price"])
        long = s["bias"] == "bullish"
        hist = json.loads(s["history_json"] or "[]")
        status, stop = s["status"], s["stop"]
        changed = None

        def hit(level):
            return p >= level if long else p <= level

        def lost(level):
            return p <= level if long else p >= level

        if status == "new" and (s["entry_low"] <= p <= s["entry_high"]):
            status, changed = "active", f"Μπήκε στη ζώνη εισόδου @ {p:.2f}"
        if status in ("new", "active", "tp1", "tp2") and lost(stop):
            ret = (p / s["price"] - 1) * (1 if long else -1) * 100
            outcome = "stop" if status in ("new", "active") else f"stop μετά από {status.upper()}"
            db.execute("UPDATE signals SET status='closed', closed_at=?, outcome=?, outcome_return=? WHERE id=?",
                       (db.now_iso(), outcome, ret, s["id"]))
            alerts.add("stop", f"{s['ticker']}: χτυπήθηκε το stop {stop:.2f}", s["ticker"], "high", f"stop:{s['id']}")
            continue
        for lvl_name, nxt in (("tp1", "tp1"), ("tp2", "tp2"), ("tp3", "tp3")):
            order = ["new", "active", "tp1", "tp2", "tp3"]
            if order.index(status) < order.index(nxt) and hit(s[lvl_name]):
                status = nxt
                changed = f"Χτυπήθηκε {lvl_name.upper()} {s[lvl_name]:.2f}"
                if nxt == "tp1":
                    stop = s["price"]  # trailing: stop στο breakeven
                    changed += f" — stop μεταφέρθηκε στο breakeven {stop:.2f}"
                elif nxt == "tp2":
                    stop = s["tp1"]
                    changed += f" — stop μεταφέρθηκε στο TP1 {stop:.2f}"
        if status == "tp3":
            ret = (s["tp3"] / s["price"] - 1) * (1 if long else -1) * 100
            db.execute("UPDATE signals SET status='closed', closed_at=?, outcome='tp3', outcome_return=? WHERE id=?",
                       (db.now_iso(), ret, s["id"]))
            alerts.add("tp", f"{s['ticker']}: TP3 επιτεύχθηκε", s["ticker"], "high", f"tp3:{s['id']}")
            continue
        if _trading_days_since(s["created_at"]) > HORIZONS[s["horizon"]]["max_days"]:
            ret = (p / s["price"] - 1) * (1 if long else -1) * 100
            db.execute("UPDATE signals SET status='expired', closed_at=?, outcome='expired', outcome_return=? WHERE id=?",
                       (db.now_iso(), ret, s["id"]))
            continue
        if changed:
            hist.append({"at": db.now_iso(), "event": changed, "price": p, "stop": stop})
            db.execute("UPDATE signals SET status=?, stop=?, history_json=? WHERE id=?",
                       (status, stop, json.dumps(hist), s["id"]))
            alerts.add("signal_update", f"{s['ticker']}: {changed}", s["ticker"], "medium", f"upd:{s['id']}:{status}")


def list_signals(status: str = "active", limit: int = 200) -> list[dict]:
    if status == "active":
        rows = db.q(f"SELECT * FROM signals WHERE status IN {ACTIVE} ORDER BY id DESC LIMIT ?", (limit,))
    else:
        rows = db.q("SELECT * FROM signals ORDER BY id DESC LIMIT ?", (limit,))
    for r in rows:
        for k in ("catalysts_json", "risks_json", "conflicts_json", "history_json"):
            r[k[:-5]] = json.loads(r.pop(k) or "[]")
    return rows


def stats() -> dict:
    rows = db.q("SELECT horizon, outcome, outcome_return FROM signals WHERE status IN ('closed','expired')")
    by: dict[str, dict] = {}
    for r in rows:
        d = by.setdefault(r["horizon"], {"n": 0, "wins": 0, "sum": 0.0})
        d["n"] += 1
        d["sum"] += r["outcome_return"] or 0
        if (r["outcome_return"] or 0) > 0:
            d["wins"] += 1
    return {h: {"n": d["n"], "win_rate": round(d["wins"] / d["n"] * 100, 1), "avg_return": round(d["sum"] / d["n"], 2)}
            for h, d in by.items() if d["n"]}
