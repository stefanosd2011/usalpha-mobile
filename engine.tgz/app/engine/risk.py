"""Risk management: βαθμολογία κινδύνου μετοχής, προειδοποιήσεις, position sizing,
έλεγχοι χαρτοφυλακίου (έκθεση, κλάδοι, συσχέτιση)."""
from __future__ import annotations

import math

import numpy as np
import pandas as pd

from .. import db
from ..config import settings


def stock_risk(tech: dict, fund: dict, quote: dict | None, data_quality: str | None) -> dict:
    """Επιστρέφει score 0-100 όπου ΥΨΗΛΟ = ΧΑΜΗΛΟΣ κίνδυνος, + λίστα προειδοποιήσεων."""
    m = tech.get("metrics", {}) if tech.get("ok") else {}
    fm = fund.get("metrics", {}) if fund else {}
    warnings: list[dict] = []
    pts = 0.0

    dv = m.get("dollar_vol20")
    if dv is not None:
        if dv < settings.min_dollar_volume:
            pts -= 3; warnings.append({"level": "high", "text": f"Χαμηλή ρευστότητα: μέσος όγκος ${dv/1e6:.1f}M/ημέρα"})
        elif dv > 200e6:
            pts += 1.5
    else:
        warnings.append({"level": "medium", "text": "Άγνωστη ρευστότητα"})

    bid, ask = (quote or {}).get("bid"), (quote or {}).get("ask")
    if bid and ask and ask > bid > 0:
        spread = (ask - bid) / ((ask + bid) / 2) * 100
        if spread > settings.max_spread_pct:
            pts -= 2; warnings.append({"level": "high", "text": f"Μεγάλο bid/ask spread {spread:.2f}%"})
    atrp = m.get("atr_pct")
    if atrp is not None:
        if atrp > 8:
            pts -= 3; warnings.append({"level": "high", "text": f"Ακραία μεταβλητότητα: ATR {atrp:.1f}% ημερησίως"})
        elif atrp > 5:
            pts -= 1.5; warnings.append({"level": "medium", "text": f"Υψηλή μεταβλητότητα: ATR {atrp:.1f}%"})
        elif atrp < 2.5:
            pts += 1
    mc = fm.get("market_cap")
    if mc is not None:
        if mc < 300e6:
            pts -= 2; warnings.append({"level": "medium", "text": f"Micro cap (${mc/1e6:.0f}M)"})
        elif mc > 50e9:
            pts += 1
    flags = set(fund.get("flags", [])) if fund else set()
    if "earnings_soon" in flags:
        pts -= 1.5
        warnings.append({"level": "high", "text": f"Earnings σε {fm.get('days_to_earnings')} μέρες ({fm.get('earnings_date')})"})
    if "dilution_risk" in flags:
        pts -= 2; warnings.append({"level": "high", "text": "Κίνδυνος dilution / αύξησης κεφαλαίου"})
    if "high_short_interest" in flags:
        pts -= 1; warnings.append({"level": "medium", "text": f"Short interest {(fm.get('short_pct_float') or 0)*100:.0f}% του float"})
    if "unprofitable" in flags:
        pts -= 0.5
    if data_quality in ("STALE", "NO_DATA"):
        pts -= 2; warnings.append({"level": "high", "text": f"Ελλιπή ή παλιά δεδομένα τιμής ({data_quality})"})
    if fund and fund.get("coverage", 1) < 0.3:
        warnings.append({"level": "low", "text": "Ελλιπή θεμελιώδη δεδομένα"})
    score = max(0.0, min(100.0, 60 + pts * 6))
    return {"score": round(score, 1), "warnings": warnings}


def position_size(entry: float, stop: float, account: float | None = None, risk_pct: float | None = None,
                  max_pos_pct: float | None = None) -> dict:
    account = account or settings.account_size
    risk_pct = risk_pct if risk_pct is not None else settings.risk_per_trade_pct
    max_pos_pct = max_pos_pct or settings.max_position_pct
    per_share = abs(entry - stop)
    if per_share <= 0 or entry <= 0:
        return {"shares": 0, "reason": "Μη έγκυρο stop"}
    risk_amt = account * risk_pct / 100
    shares = math.floor(risk_amt / per_share)
    cap = math.floor(account * max_pos_pct / 100 / entry)
    limited = shares > cap
    shares = min(shares, cap)
    return {"shares": int(shares), "position_value": round(shares * entry, 2),
            "risk_amount": round(shares * per_share, 2), "risk_pct_account": round(shares * per_share / account * 100, 2),
            "stop_distance_pct": round(per_share / entry * 100, 2), "limited_by_max_position": limited,
            "account": account}


def portfolio_risk(positions: list[dict], account: float | None = None) -> dict:
    """positions: [{ticker, qty, price, stop, sector}]"""
    account = account or settings.account_size
    if not positions:
        return {"exposure_pct": 0, "open_risk_pct": 0, "sectors": {}, "warnings": [], "correlation": None}
    warnings = []
    exposure = sum(p["qty"] * p["price"] for p in positions)
    open_risk = sum(max(0, p["qty"] * (p["price"] - (p.get("stop") or p["price"]))) for p in positions)
    sectors: dict[str, float] = {}
    for p in positions:
        s = p.get("sector") or "Άγνωστο"
        sectors[s] = sectors.get(s, 0) + p["qty"] * p["price"]
    sectors_pct = {k: round(v / account * 100, 1) for k, v in sectors.items()}
    for s, v in sectors_pct.items():
        if v > settings.max_sector_pct:
            warnings.append(f"Συγκέντρωση κλάδου {s}: {v:.0f}% (όριο {settings.max_sector_pct:.0f}%)")
    if exposure / account > 1:
        warnings.append(f"Συνολική έκθεση {exposure/account*100:.0f}% του κεφαλαίου (μόχλευση)")
    corr = correlation_matrix([p["ticker"] for p in positions])
    if corr is not None:
        hi = [(a, b, v) for a in corr for b, v in corr[a].items() if a < b and v > 0.8]
        for a, b, v in hi:
            warnings.append(f"Υψηλή συσχέτιση {a}/{b} ({v:.2f}): στην πράξη μοιάζει με μία θέση")
    return {"exposure_pct": round(exposure / account * 100, 1), "open_risk_pct": round(open_risk / account * 100, 2),
            "sectors": sectors_pct, "warnings": warnings, "correlation": corr}


def correlation_matrix(tickers: list[str], days: int = 120) -> dict | None:
    tickers = sorted(set(tickers))
    if len(tickers) < 2:
        return None
    rets = {}
    for t in tickers:
        df = db.load_prices(t)
        if len(df) > 30:
            rets[t] = df["close"].pct_change().tail(days)
    if len(rets) < 2:
        return None
    c = pd.DataFrame(rets).corr()
    return {a: {b: round(float(c.loc[a, b]), 2) for b in c.columns if not np.isnan(c.loc[a, b])} for a in c.index}
