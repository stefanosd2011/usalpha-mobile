"""Κανόνες setups και υπολογισμός επιπέδων (entry/stop/TP). Καθαρές συναρτήσεις που
χρησιμοποιούνται ΚΑΙ live ΚΑΙ στο backtest, ώστε αυτό που ελέγχεται να είναι αυτό που τρέχει."""
from __future__ import annotations

import math
from dataclasses import dataclass, field

import pandas as pd

HORIZONS = {
    "day": {"label": "Day trade", "holding": "ίδια μέρα (αύριο)", "max_days": 1, "stop_atr": 0.67},
    "short": {"label": "Βραχυπρόθεσμο", "holding": "1-5 ημέρες", "max_days": 5, "stop_atr": 1.2},
    "swing": {"label": "Swing", "holding": "1-6 εβδομάδες", "max_days": 25, "stop_atr": 2.0},
    "invest": {"label": "Επένδυση", "holding": "3-12 μήνες", "max_days": 120, "stop_atr": 3.0},
}


@dataclass
class Setup:
    horizon: str
    bias: str  # bullish / bearish
    name: str
    reasons: list[str] = field(default_factory=list)


def _ok(*vals) -> bool:
    return all(v is not None and not (isinstance(v, float) and math.isnan(v)) for v in vals)


def detect(x: pd.DataFrame, i: int = -1, fund_score: float | None = None) -> list[Setup]:
    """x: DataFrame με indicators.add_all(). Εξετάζει τη γραμμή i χρησιμοποιώντας μόνο x[:i+1]."""
    if len(x) < 60:
        return []
    r = x.iloc[i]
    p = x.iloc[i - 1]
    out: list[Setup] = []
    c = r["close"]
    if not _ok(c, r["atr"], r["ema20"], r["ema50"], r["rsi"]):
        return out
    rvol = r["rvol"] if _ok(r["rvol"]) else 0
    sma200_ok = _ok(r["sma200"])

    # ---------------- SHORT-TERM
    if _ok(r["hi20"], r["vwap20"]) and c > r["hi20"] and rvol >= 1.5 and c > r["vwap20"] and r["rsi"] < 78 \
            and c > r["open"]:
        out.append(Setup("short", "bullish", "Breakout υψηλού 20 ημερών με όγκο",
                         [f"Κλείσιμο πάνω από {r['hi20']:.2f}", f"RVOL {rvol:.1f}x", "Πάνω από VWAP20"]))
    elif _ok(r["gap"]) and r["gap"] > 0.03 and c > r["open"] and rvol >= 2 and r["rsi"] < 80:
        out.append(Setup("short", "bullish", "Gap & Go",
                         [f"Gap {r['gap']*100:.1f}% που κράτησε", f"RVOL {rvol:.1f}x"]))
    if _ok(r["lo20"], r["vwap20"]) and c < r["lo20"] and rvol >= 1.5 and c < r["vwap20"] and r["rsi"] > 25 \
            and c < r["open"]:
        out.append(Setup("short", "bearish", "Breakdown χαμηλού 20 ημερών με όγκο",
                         [f"Κλείσιμο κάτω από {r['lo20']:.2f}", f"RVOL {rvol:.1f}x"]))

    # ---------------- SWING
    uptrend = r["ema20"] > r["ema50"] and (not sma200_ok or r["ema50"] > r["sma200"])
    downtrend = r["ema20"] < r["ema50"] and (not sma200_ok or r["ema50"] < r["sma200"])
    mh_up = _ok(r["macd_hist"], p["macd_hist"]) and r["macd_hist"] > p["macd_hist"]
    mh_dn = _ok(r["macd_hist"], p["macd_hist"]) and r["macd_hist"] < p["macd_hist"]
    if uptrend and r["low"] <= r["ema20"] * 1.01 and c > r["ema20"] and 40 <= r["rsi"] <= 62 and mh_up:
        out.append(Setup("swing", "bullish", "Pullback στον EMA20 σε ανοδική τάση",
                         ["Τάση: EMA20 > EMA50 > SMA200", f"RSI {r['rsi']:.0f}", "MACD histogram ανεβαίνει"]))
    elif _ok(r["hi55"], r["adx"]) and c > r["hi55"] and rvol >= 1.3 and r["adx"] > 20 and uptrend:
        out.append(Setup("swing", "bullish", "Breakout υψηλού 55 ημερών",
                         [f"Πάνω από {r['hi55']:.2f}", f"ADX {r['adx']:.0f}", f"RVOL {rvol:.1f}x"]))
    elif _ok(r["stoch_k"], r["stoch_d"]) and r["rsi"] < 40 and p["rsi"] < r["rsi"] and c > r["ema9"] \
            and r["stoch_k"] > r["stoch_d"] and r["stoch_k"] < 40 and sma200_ok and c > r["sma200"] * 0.9:
        out.append(Setup("swing", "bullish", "Αντιστροφή από υπερπουλημένη ζώνη",
                         [f"RSI {r['rsi']:.0f} γυρίζει πάνω", "Stoch RSI cross", "Πάνω από EMA9"]))
    if downtrend and r["high"] >= r["ema20"] * 0.99 and c < r["ema20"] and 38 <= r["rsi"] <= 60 and mh_dn:
        out.append(Setup("swing", "bearish", "Απόρριψη στον EMA20 σε καθοδική τάση",
                         ["Τάση: EMA20 < EMA50 < SMA200", f"RSI {r['rsi']:.0f}", "MACD histogram πέφτει"]))

    # ---------------- INVESTMENT (μόνο long, απαιτεί θεμελιώδη)
    if fund_score is not None and fund_score >= 65 and sma200_ok and c > r["sma200"] \
            and _ok(r["ret126"]) and r["ret126"] > 0 and r["sma50"] > r["sma200"] * 0.98:
        out.append(Setup("invest", "bullish", "Ποιοτική εταιρεία σε μακροπρόθεσμη ανοδική τάση",
                         [f"Θεμελιώδη {fund_score:.0f}/100", "Πάνω από SMA200", f"Απόδοση 6μ {r['ret126']*100:.0f}%"]))
    return out


def levels(x: pd.DataFrame, setup: Setup, sr_levels: list[dict] | None = None, i: int = -1,
           extra_targets: list[float] | None = None) -> dict | None:
    r = x.iloc[i]
    c, a = float(r["close"]), float(r["atr"])
    if not a or a <= 0 or c <= 0:
        return None
    h = HORIZONS[setup.horizon]
    long = setup.bias == "bullish"
    sgn = 1 if long else -1
    if setup.horizon == "day":
        lo, hi = c - 0.15 * a, c + 0.15 * a
    elif setup.horizon == "short":
        lo, hi = c - 0.25 * a, c + 0.25 * a
    elif setup.horizon == "swing":
        if long:
            lo, hi = max(float(r["ema20"]), c - 0.6 * a), c + 0.2 * a
        else:
            lo, hi = c - 0.2 * a, min(float(r["ema20"]), c + 0.6 * a)
    else:
        lo, hi = c - 1.0 * a, c
    lo, hi = min(lo, hi), max(lo, hi)
    entry = (lo + hi) / 2
    stop = entry - sgn * h["stop_atr"] * a
    # structure stop: πίσω από την πλησιέστερη στήριξη/αντίσταση αν είναι σε λογική απόσταση
    band = 1.5 * h["stop_atr"] * a
    if long:
        sup = [lv["price"] for lv in (sr_levels or []) if entry - band <= lv["price"] <= entry - 0.5 * a]
        if sup:
            stop = max(sup) - 0.25 * a
    else:
        res = [lv["price"] for lv in (sr_levels or []) if entry + 0.5 * a <= lv["price"] <= entry + band]
        if res:
            stop = min(res) + 0.25 * a
    R = abs(entry - stop)
    if R <= 0:
        return None
    tp1 = entry + sgn * 1.5 * R
    tp2 = entry + sgn * 2.5 * R
    tp3 = entry + sgn * 4.0 * R
    # αντιστάσεις/στόχοι ως TP2/TP3 αν είναι πιο λογικοί
    cands = sorted([lv["price"] for lv in (sr_levels or [])] + list(extra_targets or []))
    if long:
        above = [p for p in cands if p >= entry + 2.0 * R]
        if above:
            tp2 = min(above[0], tp3)
        if len(above) > 1:
            tp3 = max(tp3, above[1])
    else:
        below = [p for p in reversed(cands) if p <= entry - 2.0 * R]
        if below:
            tp2 = max(below[0], tp3)
    tp2 = max(tp2, tp1 + 0.1 * R) if long else min(tp2, tp1 - 0.1 * R)
    # TP3 πάντα πέρα από το TP2
    if long and tp3 <= tp2 + 0.5 * R:
        tp3 = tp2 + 1.5 * R
    if not long and tp3 >= tp2 - 0.5 * R:
        tp3 = tp2 - 1.5 * R
    rr = abs(tp2 - entry) / R
    return {"entry_low": round(lo, 4), "entry_high": round(hi, 4), "entry": round(entry, 4),
            "stop": round(stop, 4), "tp1": round(tp1, 4), "tp2": round(tp2, 4), "tp3": round(tp3, 4),
            "rr": round(rr, 2), "risk_per_share": round(R, 4), "stop_pct": round(R / entry * 100, 2),
            "holding": h["holding"], "max_days": h["max_days"]}


def ml_setups(ml_info: dict, existing: set) -> list[Setup]:
    """Ευκαιρίες που εντοπίζει ένα ΕΠΙΚΥΡΩΜΕΝΟ μοντέλο, ακόμα κι αν δεν υπάρχει κλασικό τεχνικό setup:
    - barrier: top 5% της αγοράς και ιστορικό αναμενόμενο R ≥ όριο
    - rank: top 3% της αγοράς σε κατάταξη και θετική ιστορική υπεραπόδοση (επίπεδα ATR του αντίστοιχου ορίζοντα)."""
    from ..config import settings
    from ..ml.features import HORIZONS as MLH
    out = []
    for hz, r in (ml_info or {}).items():
        cfg = MLH.get(hz)
        if not cfg or not r.get("validated") or r.get("p") is None:
            continue
        er = r.get("exp_r")
        if cfg["kind"] == "barrier":
            if (hz, "bullish") in existing or hz not in HORIZONS:
                continue
            if er is not None and er >= settings.ml_min_exp_r and (r.get("rank_pct") or 0) >= 0.95:
                out.append(Setup(hz, "bullish", "ML: υψηλή πιθανότητα στόχου",
                                 [f"Πιθανότητα στόχου πριν το stop {r['p']*100:.0f}%",
                                  f"Top {max(1, round((1 - r['rank_pct']) * 100))}% της αγοράς",
                                  f"Ιστορικό αναμενόμενο R {er:+.2f} (out-of-sample)"]))
        else:
            target = "short" if cfg["H"] <= 5 else "swing"
            if (target, "bullish") in existing or any(s.horizon == target for s in out):
                continue
            if er is not None and er > 2 * settings.slippage_bps / 10000 and (r.get("rank_pct") or 0) >= 0.97:
                out.append(Setup(target, "bullish", "ML: κορυφαία κατάταξη αγοράς",
                                 [f"Top {max(1, round((1 - r['rank_pct']) * 100))}% όλης της αγοράς ({cfg['label']})",
                                  f"Ιστορικά: +{er*100:.2f}% καλύτερα από την αγορά σε {cfg['H']} ημ. (out-of-sample)"]))
    return out
