"""Πλήρης ανάλυση μιας μετοχής: τεχνικά + θεμελιώδη + ειδήσεις + κλάδος + αγορά + κίνδυνος
-> score, εξήγηση, setups. Ένα σημείο αλήθειας για scanner, σελίδα μετοχής και signals."""
from __future__ import annotations

import json
from dataclasses import dataclass, field

import pandas as pd

from .. import db
from ..analysis import fundamentals, market as mkt, news as newsmod, technical
from ..analysis import indicators as ind
from ..data import service
from . import risk as riskmod, scoring, strategies


@dataclass
class Context:
    bench: pd.DataFrame
    market: dict
    sectors: list[dict]
    sector_medians: dict = field(default_factory=dict)
    ml: dict = field(default_factory=dict)            # ticker -> {horizon: prediction row}
    ml_validated: dict = field(default_factory=dict)  # horizon -> bool

    @classmethod
    def build(cls, breadth: float | None = None, member_scores: dict | None = None) -> "Context":
        rows = []
        for r in db.q("SELECT sector, data_json FROM company"):
            try:
                d = json.loads(r["data_json"])
                d["sector"] = r["sector"]
                rows.append(d)
            except Exception:
                pass
        ml_val = {r["horizon"]: bool(r["validated"]) for r in db.q("SELECT horizon, validated FROM ml_models")}
        ml: dict = {}
        for r in db.q("SELECT ticker, horizon, p, rank_pct, exp_r, date FROM ml_predictions WHERE "
                      "date=(SELECT MAX(date) FROM ml_predictions)"):
            r["validated"] = ml_val.get(r["horizon"], False)
            ml.setdefault(r["ticker"], {})[r["horizon"]] = r
        try:  # v4: παίρνει τη θέση του v3 ΜΟΝΟ όπου είναι επικυρωμένο και καλύτερο (αλλιώς δεν αλλάζει τίποτα)
            from ..ml import v4 as ml4
            ml = ml4.overlay(ml)
            for h, a in ml4.active_horizons().items():
                if a:
                    ml_val[h] = True
        except Exception:  # noqa: BLE001
            pass
        return cls(bench=db.load_prices("SPY"), market=mkt.market_conditions(breadth),
                   sectors=mkt.sector_strength(member_scores), sector_medians=fundamentals.sector_medians(rows),
                   ml=ml, ml_validated=ml_val)

    def ml_for(self, ticker: str) -> tuple[float | None, dict]:
        from ..ml.model import combined_rank
        info = self.ml.get(ticker, {})
        return combined_rank(info), info


def with_live_bar(ticker: str, df: pd.DataFrame) -> tuple[pd.DataFrame, bool]:
    """Κατά τη διάρκεια της συνεδρίασης προσθέτει τη σημερινή (ημιτελή) μπάρα από τα πραγματικά
    intraday δεδομένα, ώστε οι επανέλεγχοι να βλέπουν την τρέχουσα τιμή. Σημειώνεται ως provisional."""
    from ..data.session import session
    q = db.q1("SELECT * FROM quotes WHERE ticker=?", (ticker,))
    if df.empty or not q or not q.get("price") or session() != "regular" or not q.get("as_of"):
        return df, False
    today = service.today_ny_str()
    if str(df.index[-1].date()) >= today or not q.get("day_high") or not q.get("volume"):
        return df, False
    prev_close = float(df["close"].iloc[-1])
    bar = pd.DataFrame({"open": [q.get("day_open") or prev_close], "high": [max(q["day_high"], q["price"])],
                        "low": [min(q["day_low"] or q["price"], q["price"])], "close": [q["price"]],
                        "adj_close": [q["price"]], "volume": [q["volume"]]}, index=[pd.Timestamp(today)])
    return pd.concat([df, bar]), True


def analyze_ticker(ticker: str, ctx: Context, fetch_company: bool = False, df: pd.DataFrame | None = None,
                   live: bool = False) -> dict:
    df = df if df is not None else db.load_prices(ticker)
    if df.empty:
        return {"ticker": ticker, "ok": False, "reason": "Δεν υπάρχουν ιστορικές τιμές"}
    provisional = False
    if live:
        df, provisional = with_live_bar(ticker, df)
    tech = technical.analyze(df, ctx.bench)
    info = service.get_company(ticker, fetch=fetch_company)
    sector = (info.get("sector") if info else None) or service.sector_of(ticker)
    quote = service.get_quote(ticker)
    price = (quote or {}).get("price") or (tech.get("metrics", {}).get("close") if tech.get("ok") else None)
    fund = fundamentals.analyze(info, price, ctx.sector_medians.get(sector or "", {}))
    nws = newsmod.news_score(ticker)
    ssc = mkt.sector_score_for(sector, ctx.sectors) if sector else None
    rk = riskmod.stock_risk(tech, fund, quote, (quote or {}).get("quality"))
    ml_score, ml_info = ctx.ml_for(ticker)
    scored = scoring.build(ticker, tech, fund, nws, ssc, ctx.market, rk, ml_score=ml_score, ml_info=ml_info)

    setups = []
    if tech.get("ok"):
        x = ind.add_all(df)
        extra = [v for v in [fund.get("metrics", {}).get("target_mean"), tech["metrics"].get("hi52")] if v]
        found = strategies.detect(x, fund_score=fund.get("score") if fund.get("coverage", 0) >= 0.3 else None)
        found += strategies.ml_setups(ml_info, {(s.horizon, s.bias) for s in found})
        for s in found:
            ml_s = s.name.startswith("ML:")
            # τα ML setups χρησιμοποιούν ΑΚΡΙΒΩΣ τα επίπεδα (ATR) πάνω στα οποία εκπαιδεύτηκε το μοντέλο
            lv = strategies.levels(x, s, None if ml_s else tech.get("levels"), extra_targets=None if ml_s else extra)
            if lv:
                setups.append({"horizon": s.horizon, "bias": s.bias, "name": s.name, "reasons": s.reasons, **lv})
    return {
        "ticker": ticker, "ok": tech.get("ok", False), "name": (info or {}).get("longName") or (info or {}).get("shortName"),
        "sector": sector, "industry": (info or {}).get("industry"), "quote": quote, "tech": tech, "fund": fund,
        "news": nws, "sector_score": ssc, "risk": rk, "scored": scored, "setups": setups, "ml": ml_info,
        "company_fetched_at": (info or {}).get("_fetched_at"), "provisional_bar": provisional,
    }
