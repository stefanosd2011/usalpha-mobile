"""AI Financial Intelligence score (0-100): σταθμισμένος συνδυασμός 7 παραγόντων με
παραμετροποιήσιμα βάρη (config/weights.json). Η βαθμολογία ΔΕΝ είναι πιθανότητα.
Πιθανότητα εμφανίζεται μόνο αν υπάρχει βαθμονόμηση από out-of-sample backtest."""
from __future__ import annotations

import json

from .. import db
from ..config import settings
from . import confirmation

COMPONENT_LABELS = {
    "ml": "Μοντέλο πρόβλεψης (ML)",
    "technical": "Τεχνική ανάλυση", "fundamentals": "Θεμελιώδη", "news": "Ειδήσεις & Catalysts",
    "momentum_volume": "Momentum & Όγκος", "sector": "Δύναμη κλάδου", "market": "Συνθήκες αγοράς",
    "risk": "Αξιολόγηση κινδύνου",
}


def compose(components: dict[str, float | None], weights: dict | None = None) -> tuple[float, float]:
    """Επιστρέφει (score, coverage). Παράγοντες χωρίς δεδομένα εξαιρούνται και τα βάρη
    επανακανονικοποιούνται· το coverage δείχνει πόσο βάρος είχε πραγματικά δεδομένα."""
    w = weights or settings.weights
    num = den = 0.0
    for k, wt in w.items():
        v = components.get(k)
        if v is None:
            continue
        num += wt * v
        den += wt
    if den == 0:
        return 50.0, 0.0
    return round(num / den, 1), round(den / sum(w.values()), 2)


def build(ticker: str, tech: dict, fund: dict, news: dict, sector_score: float | None,
          market: dict, risk: dict, weights: dict | None = None, ml_score: float | None = None,
          ml_info: dict | None = None) -> dict:
    comps = {
        "ml": ml_score,
        "technical": tech.get("technical_score") if tech.get("ok") else None,
        "momentum_volume": tech.get("momentum_score") if tech.get("ok") else None,
        "fundamentals": fund.get("score") if fund.get("ok") and fund.get("coverage", 0) > 0 else None,
        "news": news.get("score") if news.get("n_clusters", 0) > 0 else None,
        "sector": sector_score,
        "market": market.get("score") if market.get("ok") else None,
        "risk": risk.get("score"),
    }
    score, coverage = compose(comps, weights)
    bias = "bullish" if score >= 55 else ("bearish" if score <= 45 else "neutral")
    conf = confirmation.evaluate({"tech": tech, "fund": fund, "news": news, "sector_score": sector_score,
                                  "market": market, "ml_score": ml_score}, "bearish" if bias == "bearish" else "bullish")
    # επεξήγηση
    w = weights or settings.weights
    contrib = []
    for k, v in comps.items():
        if v is None:
            contrib.append({"key": k, "label": COMPONENT_LABELS[k], "score": None, "weight": w.get(k),
                            "impact": None, "note": "Χωρίς δεδομένα — εξαιρέθηκε"})
        else:
            contrib.append({"key": k, "label": COMPONENT_LABELS[k], "score": round(v, 1), "weight": w.get(k),
                            "impact": round((v - 50) * w.get(k, 0), 2)})
    contrib.sort(key=lambda c: -(abs(c["impact"]) if c["impact"] is not None else -1))
    pros = (tech.get("pros") or []) + (fund.get("pros") or [])
    cons = (tech.get("cons") or []) + (fund.get("cons") or [])
    for it in (news.get("top") or [])[:4]:
        (pros if it["contribution"] > 0.02 else cons if it["contribution"] < -0.02 else []).append(
            f"Είδηση ({it['source']}, {it['published_at'][:10]}): {it['title'][:110]}")
    if ml_score is not None:
        txt = f"Μοντέλο πρόβλεψης: κατάταξη {ml_score:.0f}/100 μέσα σε όλη την αγορά"
        (pros if ml_score >= 65 else cons if ml_score <= 35 else []).insert(0, txt)
    risks = [w_["text"] for w_ in risk.get("warnings", [])] + (fund.get("risks") or [])
    what_changes = _what_changes(tech, fund, bias)
    counter = cons if bias == "bullish" else pros
    prob = calibrated_probability(score)
    ml_prob = {}
    for hz, r in (ml_info or {}).items():
        if r.get("validated") and r.get("p") is not None:
            ml_prob[hz] = r
    return {
        "ticker": ticker, "score": score, "coverage": coverage, "bias": bias, "components": comps,
        "contributions": contrib, "confirmation": conf,
        "explain": {
            "summary": _summary(ticker, score, bias, contrib, conf),
            "pros": pros[:10], "cons": cons[:10], "risks": list(dict.fromkeys(risks))[:10],
            "what_changes": what_changes, "counter_evidence": counter[:6],
        },
        "probability": prob,          # από το rule-based walk-forward backtest (αν υπάρχει)
        "ml_probability": ml_prob,    # από το επικυρωμένο μοντέλο πρόβλεψης (αν υπάρχει)
    }


def _summary(ticker, score, bias, contrib, conf) -> str:
    top = [c for c in contrib if c["impact"] is not None][:2]
    drv = " και ".join(f"{c['label']} ({c['score']:.0f})" for c in top)
    b = {"bullish": "θετική", "bearish": "αρνητική", "neutral": "ουδέτερη"}[bias]
    s = f"{ticker}: συνολική βαθμολογία {score:.0f}/100, {b} εικόνα. Κύριοι παράγοντες: {drv}."
    if conf["conflicts"]:
        s += " Προσοχή: υπάρχουν συγκρουόμενες ενδείξεις."
    return s


def _what_changes(tech: dict, fund: dict, bias: str) -> list[str]:
    out = []
    m = tech.get("metrics", {})
    lv = tech.get("levels") or []
    price = m.get("close")
    if price:
        sup = [l for l in lv if l["price"] < price]
        res = [l for l in lv if l["price"] > price]
        if sup:
            out.append(f"Κλείσιμο κάτω από τη στήριξη {sup[-1]['price']:.2f} θα χάλαγε την ανοδική εικόνα")
        if res:
            out.append(f"Κλείσιμο πάνω από την αντίσταση {res[0]['price']:.2f} με όγκο θα ενίσχυε την ανοδική εικόνα")
        if m.get("ema50"):
            out.append(f"{'Απώλεια' if price > m['ema50'] else 'Ανάκτηση'} του EMA50 ({m['ema50']:.2f})")
    fm = fund.get("metrics", {}) if fund else {}
    if fm.get("earnings_date"):
        out.append(f"Τα αποτελέσματα στις {fm['earnings_date']} μπορούν να αλλάξουν πλήρως την εικόνα")
    out.append("Νέα είδηση υψηλής σημασίας (FDA, συμβόλαιο, αύξηση κεφαλαίου, guidance)")
    out.append("Αλλαγή κλίματος αγοράς (VIX, S&P 500 κάτω από SMA50)")
    return out


def calibrated_probability(score: float, horizon: str = "swing") -> dict | None:
    row = db.q1("SELECT * FROM calibration WHERE horizon=?", (horizon,))
    if not row or (row["n_samples"] or 0) < 200:
        return None
    table = json.loads(row["table_json"])
    for b in table:
        if b["lo"] <= score < b["hi"]:
            if b["n"] < 30:
                return None
            return {"p_up": b["p_up"], "n": b["n"], "avg_ret": b.get("avg_ret"), "horizon_days": b.get("h"),
                    "brier": row["brier"], "calibrated_at": row["created_at"],
                    "note": "Ιστορική συχνότητα σε out-of-sample δεδομένα για αυτό το εύρος βαθμολογίας — όχι εγγύηση."}
    return None
