"""Multi-layer confirmation: ανεξάρτητες επιβεβαιώσεις από ΔΙΑΦΟΡΕΤΙΚΕΣ κατηγορίες δεδομένων.
Ένας δείκτης μόνος του δεν φτάνει ποτέ για ισχυρό signal."""
from __future__ import annotations

CATEGORY_LABELS = {
    "ml": "Μοντέλο ML", "trend": "Τάση", "momentum": "Momentum", "volume": "Όγκος", "relative": "Σχετική δύναμη",
    "fundamentals": "Θεμελιώδη", "news": "Ειδήσεις", "sector": "Κλάδος", "market": "Αγορά",
}


def evaluate(bundle: dict, bias: str = "bullish") -> dict:
    """bundle: {tech, fund, news, sector_score, market}. Επιστρέφει τις επιβεβαιώσεις υπέρ/κατά."""
    tech, fund, news = bundle.get("tech") or {}, bundle.get("fund") or {}, bundle.get("news") or {}
    flags = set(tech.get("flags", []))
    m = tech.get("metrics", {})
    rs = m.get("rs") or {}
    votes: dict[str, int] = {}

    # Trend
    if "trend_up" in flags or "trend_change_up" in flags or "golden_cross" in flags:
        votes["trend"] = 1
    elif "trend_down" in flags or "trend_change_down" in flags or "death_cross" in flags:
        votes["trend"] = -1
    # Momentum
    rsi, mh = m.get("rsi"), m.get("macd_hist")
    if rsi is not None and mh is not None:
        if 50 <= rsi <= 72 and mh > 0:
            votes["momentum"] = 1
        elif rsi < 45 and mh < 0:
            votes["momentum"] = -1
        elif "bull_div" in flags:
            votes["momentum"] = 1
        elif "bear_div" in flags or rsi > 78:
            votes["momentum"] = -1
    # Volume
    rv, ud = m.get("rvol"), m.get("updown_vol_ratio")
    if ("breakout_20" in flags or (rv and rv >= 1.5 and (m.get("change_pct") or 0) > 0)) or (ud and ud > 1.3):
        votes["volume"] = 1
    elif (rv and rv >= 1.5 and (m.get("change_pct") or 0) < 0) or (ud and ud < 0.75):
        votes["volume"] = -1
    # Relative strength
    if rs:
        if rs.get("excess", 0) > 3 and rs.get("rs_slope_21d", 0) > 0:
            votes["relative"] = 1
        elif rs.get("excess", 0) < -3 and rs.get("rs_slope_21d", 0) < 0:
            votes["relative"] = -1
    # Fundamentals
    fs = fund.get("score")
    if fund.get("ok") and fund.get("coverage", 0) >= 0.3 and fs is not None:
        if fs >= 60:
            votes["fundamentals"] = 1
        elif fs <= 40:
            votes["fundamentals"] = -1
    # News
    ns = news.get("score")
    if ns is not None and news.get("n_clusters", 0) > 0:
        if ns >= 58:
            votes["news"] = 1
        elif ns <= 42:
            votes["news"] = -1
    # Sector
    ss = bundle.get("sector_score")
    if ss is not None:
        if ss >= 58:
            votes["sector"] = 1
        elif ss <= 42:
            votes["sector"] = -1
    # Μοντέλο πρόβλεψης (μόνο αν είναι επικυρωμένο — αλλιώς ml_score = None)
    ml = bundle.get("ml_score")
    if ml is not None:
        if ml >= 75:
            votes["ml"] = 1
        elif ml <= 25:
            votes["ml"] = -1
    # Market
    mk = (bundle.get("market") or {}).get("score")
    if mk is not None:
        if mk >= 60:
            votes["market"] = 1
        elif mk <= 40:
            votes["market"] = -1

    sign = 1 if bias == "bullish" else -1
    supporting = [k for k, v in votes.items() if v == sign]
    opposing = [k for k, v in votes.items() if v == -sign]
    conflicts = []
    if supporting and opposing:
        conflicts.append("Συγκρουόμενες ενδείξεις: υπέρ " + ", ".join(CATEGORY_LABELS[k] for k in supporting)
                         + " / κατά " + ", ".join(CATEGORY_LABELS[k] for k in opposing))
    tech_side = [k for k in ("trend", "momentum", "volume", "relative") if k in supporting]
    other_side = [k for k in ("ml", "fundamentals", "news", "sector", "market") if k in supporting]
    return {
        "supporting": supporting, "opposing": opposing, "conflicts": conflicts,
        "n_support": len(supporting), "n_oppose": len(opposing),
        # «ανεξάρτητες»: απαιτούμε τουλάχιστον μία επιβεβαίωση εκτός τεχνικής ανάλυσης
        "independent_ok": len(tech_side) >= 2 and len(other_side) >= 1,
        "labels": {k: CATEGORY_LABELS[k] for k in votes},
        "votes": votes,
    }


def level(n_support: int, n_oppose: int, checks_passed: int) -> str:
    base = n_support - n_oppose
    if base >= 5 and checks_passed >= 3:
        return "Υψηλή"
    if base >= 4 and checks_passed >= 2:
        return "Μέτρια-Υψηλή"
    if base >= 3:
        return "Μέτρια"
    return "Χαμηλή"
