"""Ειδοποιήσεις με αποφυγή διπλών (dedup_key). Τα clients τις λαμβάνουν μέσω SSE."""
from __future__ import annotations

import queue
import threading

from .. import db

_subscribers: list[queue.Queue] = []
_lock = threading.Lock()


def subscribe() -> queue.Queue:
    qq: queue.Queue = queue.Queue(maxsize=200)
    with _lock:
        _subscribers.append(qq)
    return qq


def unsubscribe(qq: queue.Queue) -> None:
    with _lock:
        if qq in _subscribers:
            _subscribers.remove(qq)


def broadcast(event: str, data: dict) -> None:
    with _lock:
        subs = list(_subscribers)
    for qq in subs:
        try:
            qq.put_nowait({"event": event, "data": data})
        except queue.Full:
            pass


def add(kind: str, message: str, ticker: str | None = None, severity: str = "info",
        dedup_key: str | None = None) -> bool:
    key = dedup_key or f"{kind}:{ticker}:{message[:80]}"
    try:
        db.execute("INSERT INTO alerts(created_at,ticker,kind,severity,message,dedup_key) VALUES(?,?,?,?,?,?)",
                   (db.now_iso(), ticker, kind, severity, message, key))
    except Exception:
        return False  # ήδη υπάρχει
    broadcast("alert", {"ticker": ticker, "kind": kind, "severity": severity, "message": message,
                        "created_at": db.now_iso()})
    return True


def recent(limit: int = 100) -> list[dict]:
    return db.q("SELECT * FROM alerts ORDER BY id DESC LIMIT ?", (limit,))
