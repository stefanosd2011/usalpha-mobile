"""Υποψήφιες μετοχές για day trade την επόμενη συνεδρίαση.

Κανόνες (όχι επικυρωμένο μοντέλο): μόνο ρευστές μετοχές με αρκετή κίνηση μέσα στη μέρα, καθαρή κατεύθυνση
(τάση + momentum + όγκος + σχετική δύναμη) και χωρίς ανακοίνωση αποτελεσμάτων μέσα στην ημέρα συναλλαγής.
Επίπεδα με τους ίδιους κανόνες day του strategies.levels (ζώνη ±0.15 ATR, stop 0.67 ATR ή πίσω από στήριξη).
Χρησιμοποιείται ίδιο σε υπολογιστή και κινητό."""
from __future__ import annotations

import math

import pandas as pd

from . import confirmation, strategies

MIN_PRICE = 5.0
MIN_DOLLAR_VOL = 20e6
ATR_RANGE = (1.8, 10.0)


def _f(v):
    try:
        v = float(v)
        return None if math.isnan(v) or math.isinf(v) else v
    except (TypeError, ValueError):
        return None


def _candidate(b: dict, market_score: float | None) -> dict | None:
    if not b.get("ok"):
        return None
    tech, fund = b["tech"], b.get("fund") or {}
    m = tech.get("metrics") or {}
    flags = set(tech.get("flags") or [])
    c, atr, atrp = _f(m.get("close")), _f(m.get("atr")), _f(m.get("atr_pct"))
    dv, rv, rsi = _f(m.get("dollar_vol20")) or 0, _f(m.get("rvol")) or 0, _f(m.get("rsi"))
    e20, e50, mh, chg = _f(m.get("ema20")), _f(m.get("ema50")), _f(m.get("macd_hist")), _f(m.get("change_pct")) or 0
    rs = (m.get("rs") or {}).get("excess")
    if None in (c, atr, atrp, rsi, e20, e50) or c < MIN_PRICE or dv < MIN_DOLLAR_VOL or not (ATR_RANGE[0] <= atrp <= ATR_RANGE[1]):
        return None
    dte = (fund.get("metrics") or {}).get("days_to_earnings")
    if dte is not None and 0 <= dte <= 1:
        return None  # αποτελέσματα μέσα στη μέρα συναλλαγής: απρόβλεπτο
    long_ok = c > e20 > e50 and 50 <= rsi <= 76 and (mh or 0) > 0 and chg > 0
    short_ok = c < e20 < e50 and 24 <= rsi <= 50 and (mh or 0) < 0 and chg < 0
    if not (long_ok or short_ok):
        return None
    bias = "bullish" if long_ok else "bearish"
    sg = 1 if long_ok else -1
    reasons, score = [], 0.0
    ts = tech.get("technical_score") or 50
    ms = tech.get("momentum_score") or 50
    score += 0.30 * (ts if long_ok else 100 - ts) + 0.20 * (ms if long_ok else 100 - ms)
    reasons.append("Ανοδική τάση: τιμή πάνω από EMA20 και EMA50" if long_ok else "Πτωτική τάση: τιμή κάτω από EMA20 και EMA50")
    reasons.append(f"Σήμερα {chg:+.1f}% με RSI {rsi:.0f}")
    if rv >= 1.2:
        score += min(15, (rv - 1) * 12)
        reasons.append(f"Όγκος {rv:.1f}× του κανονικού: υπάρχει ενδιαφέρον")
    if "breakout_20" in flags and long_ok:
        score += 8
        reasons.append("Έσπασε το υψηλό 20 ημερών")
    if rs is not None and sg * rs > 0:
        score += min(10, abs(rs) / 3)
        reasons.append(("Πιο δυνατή" if long_ok else "Πιο αδύναμη") + f" από το S&P 500 ({rs:+.0f}% σε 3 μήνες)")
    if 2.5 <= atrp <= 6:
        score += 6
    reasons.append(f"Κινείται κατά μέσο όρο ±{atrp:.1f}% τη μέρα (${atr:.2f})")
    if market_score is not None:
        score += (market_score - 50) * 0.15 * sg
    if rsi > 72 and long_ok:
        score -= 6
        reasons.append("Προσοχή: RSI ψηλά, πιθανή ανάσα")
    if dte is not None and 2 <= dte <= 5:
        reasons.append(f"Αποτελέσματα σε {dte} μέρες")
    ml = (b.get("ml") or {}).get("day") or {}
    if ml.get("validated") and ml.get("p") is not None:
        score += (ml.get("rank_pct", 0.5) - 0.5) * 20 * sg
    x = pd.DataFrame([{"close": c, "atr": atr, "ema20": e20}])
    lv = strategies.levels(x, strategies.Setup("day", bias, "Day trade"), sr_levels=tech.get("levels"))
    if not lv:
        return None
    conf = confirmation.evaluate({"tech": tech, "fund": fund, "news": b.get("news") or {},
                                  "sector_score": b.get("sector_score"),
                                  "market": {"score": market_score},
                                  "ml_score": (b.get("scored") or {}).get("components", {}).get("ml")}, bias)
    score += 2 * conf["n_support"] - 2 * conf["n_oppose"]
    q = b.get("quote") or {}
    return {"ticker": b["ticker"], "name": b.get("name"), "sector": b.get("sector"), "bias": bias,
            "setup": "Day trade: συνέχεια ανόδου" if long_ok else "Day trade: συνέχεια πτώσης (short)",
            "price": round(c, 4), "chg": round(chg, 2), "score": round(score, 1), "total": (b.get("scored") or {}).get("score"),
            "atr_pct": atrp, "rvol": rv, "dollar_vol": dv, "rsi": rsi, "reasons": reasons[:6],
            "support": conf["supporting"], "oppose": conf["opposing"],
            "entry_low": lv["entry_low"], "entry_high": lv["entry_high"], "entry": lv["entry"], "stop": lv["stop"],
            "tp1": lv["tp1"], "tp2": lv["tp2"], "tp3": lv["tp3"], "rr": lv["rr"], "stop_pct": lv["stop_pct"],
            "holding": "ίδια μέρα: κλείσιμο πριν το τέλος της συνεδρίασης", "quality": q.get("quality")}


def pick(bundles: dict, market: dict | None = None, n_long: int = 10, n_short: int = 5) -> dict:
    ms = (market or {}).get("score")
    cands = [c for c in (_candidate(b, ms) for b in bundles.values()) if c]
    longs = sorted([c for c in cands if c["bias"] == "bullish"], key=lambda c: -c["score"])[:n_long]
    shorts = sorted([c for c in cands if c["bias"] == "bearish"], key=lambda c: -c["score"])[:n_short]
    return {"long": longs, "short": shorts, "n_candidates": len(cands),
            "rules": [f"Τιμή πάνω από ${MIN_PRICE:.0f} και τζίρος πάνω από ${MIN_DOLLAR_VOL / 1e6:.0f} εκατ. τη μέρα",
                      f"Κίνηση μέσα στη μέρα (ATR) {ATR_RANGE[0]:.1f}%–{ATR_RANGE[1]:.0f}%",
                      "Τάση, momentum και κλείσιμο στην ίδια κατεύθυνση",
                      "Όχι αποτελέσματα την ίδια ή την επόμενη μέρα",
                      "Stop 0,67 ATR ή πίσω από στήριξη, στόχοι 1,5R / 2,5R / 4R, έξοδος μέχρι το κλείσιμο"],
            "note": "Υποψήφιες με κανόνες, όχι επικυρωμένη πρόβλεψη. Το day trade έχει υψηλό ρίσκο: μπαίνεις μόνο αν η τιμή "
                    "είναι μέσα στη ζώνη εισόδου και βγαίνεις πάντα στο stop ή πριν το κλείσιμο."}
