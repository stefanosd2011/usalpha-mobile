"""FastAPI server: REST API + Server-Sent Events + στατικό UI.
Τα API keys μένουν στον server· ο browser δεν τα βλέπει ποτέ (μόνο masked μορφή)."""
from __future__ import annotations

import asyncio
import json
import logging
import queue
import sys
import threading
from contextlib import asynccontextmanager
from pathlib import Path

import pandas as pd
from fastapi import Body, FastAPI, HTTPException, Query
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles

from . import db
from .ai import analyst, assistant, manager as ai
from .analysis import technical
from .backtest import engine as bt, walkforward as wf
from .config import (DEFAULT_WEIGHTS, ROOT, SECRET_KEYS, mask, save_weights, set_env_value, settings)
from .data import finnhub, service, yahoo
from .data.session import session, session_info, session_label
from .data.universe import MARKET_SYMBOLS, full_universe
from .engine import alerts, pipeline, risk, scanner, signals
from .jobs import scheduler
from .ml import model as mlmodel
from .data import listings
from .paper import service as paper
from .report import daily

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("usalpha")
WEB = ROOT / "web"


@asynccontextmanager
async def lifespan(app: FastAPI):
    db.init_db()
    from .data import secdata
    secdata.init()
    if settings.__dict__.get("_no_scheduler"):
        yield
        return
    scheduler.start()
    yield
    scheduler.stop()


app = FastAPI(title="US Alpha Terminal", lifespan=lifespan)


def _clean(o):
    """NaN/inf -> None ώστε το JSON να είναι έγκυρο."""
    if isinstance(o, float):
        return None if o != o or o in (float("inf"), float("-inf")) else o
    if isinstance(o, dict):
        return {k: _clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_clean(v) for v in o]
    return o


def ok(data) -> JSONResponse:
    return JSONResponse(_clean(json.loads(json.dumps(data, default=str))))


def _ctx() -> pipeline.Context:
    c = db.kv_get("last_context", {}) or {}
    return pipeline.Context.build(c.get("breadth"))


# ------------------------------------------------------------------ status
@app.get("/api/status")
def api_status():
    s = session()
    prov = {}
    for p in ("yahoo", "finnhub", "sec"):
        last = db.q1("SELECT at, ok, error FROM api_log WHERE provider=? ORDER BY id DESC LIMIT 1", (p,))
        lastok = db.q1("SELECT at FROM api_log WHERE provider=? AND ok=1 ORDER BY id DESC LIMIT 1", (p,))
        errs = db.q1("SELECT COUNT(*) n FROM api_log WHERE provider=? AND ok=0 AND at>=datetime('now','-1 hour')", (p,))
        prov[p] = {"last_call": last, "last_ok": lastok["at"] if lastok else None, "errors_1h": errs["n"] if errs else 0}
    prov["finnhub"]["configured"] = finnhub.enabled()
    prov["yahoo"]["quality"] = "Καθυστερημένα/μη εγγυημένα (δωρεάν)"
    prov["finnhub"]["quality"] = "Real-time τιμές ΗΠΑ (με key)"
    last_run = db.q1("SELECT * FROM scan_runs ORDER BY started_at DESC LIMIT 1")
    return ok({
        "session": s, "session_label": session_label(s), "session_info": session_info(), "server_time": db.now_iso(),
        "history_updated_at": db.kv_get("history_updated_at"), "quotes_updated_at": db.kv_get("quotes_updated_at"),
        "last_scan": last_run, "scan_progress": scanner.progress(), "wf_progress": wf.progress(),
        "ml_progress": mlmodel.progress(), "universe_n": (db.q1("SELECT COUNT(*) n FROM universe WHERE active=1") or {}).get("n"),
        "universe_source": db.kv_get("universe_source"), "ml_predicted_at": db.kv_get("ml_predicted_at"),
        "providers": prov, "ai": ai.status(), "ai_enabled": ai.enabled(), "jobs": scheduler.jobs_info(),
        "news_sources": db.kv_get("news_sources"),
        "sec": __import__("app.data.secdata", fromlist=["status"]).status(),
        "counts": {"tickers_with_history": (db.q1("SELECT COUNT(DISTINCT ticker) n FROM prices_daily") or {}).get("n"),
                   "news": (db.q1("SELECT COUNT(*) n FROM news") or {}).get("n"),
                   "active_signals": (db.q1("SELECT COUNT(*) n FROM signals WHERE status IN ('new','active','tp1','tp2')") or {}).get("n")},
    })


# ------------------------------------------------------------------ dashboard
@app.get("/api/dashboard")
def api_dashboard():
    ctx = db.kv_get("last_context", {}) or {}
    res = scanner.latest_results()
    quotes = service.all_quotes()
    for r in res:
        q = quotes.get(r["ticker"])
        if q and q.get("price") is not None:
            r["price"], r["change_pct"], r["quality"] = q["price"], q.get("change_pct"), q["quality"]
    market_q = {s: quotes.get(s) or service.get_quote(s) for s in MARKET_SYMBOLS}
    opp = [r for r in res if r.get("setups") and any("bullish" in x for x in r["setups"])]
    if any(r.get("ml_validated") for r in res):
        opp.sort(key=lambda r: -((r.get("ml") or 0) + r["score"]))
    opp = opp[:12]
    ml_top = sorted([r for r in res if r.get("ml") is not None], key=lambda r: -r["ml"])[:12]
    with_chg = [r for r in res if r.get("change_pct") is not None]
    by_t = {r["ticker"]: r for r in res}
    # ευκαιρίες = ενεργά signals ταξινομημένα (μοντέλο κατάταξης → ιστορικό R → score), με mini-γράφημα
    sigs = signals.list_signals("active")
    sigs.sort(key=signals._rank_key, reverse=True)
    for sg in sigs:
        r = by_t.get(sg["ticker"]) or {}
        q = quotes.get(sg["ticker"]) or {}
        sg.update(name=r.get("name"), spark=r.get("spark"), sector=r.get("sector"), cur=q.get("price") or r.get("price"),
                  cur_chg=q.get("change_pct") if q.get("change_pct") is not None else r.get("change_pct"))
    market_spark = {}
    for sym in ("SPY", "QQQ", "DIA", "IWM", "^VIX"):
        rows = db.q("SELECT close FROM prices_daily WHERE ticker=? ORDER BY date DESC LIMIT 60", (sym,))
        market_spark[sym] = [round(x["close"], 4) for x in reversed(rows)]
    rep = daily.get()
    news = db.q("SELECT ticker,title,source,published_at,category,sentiment,impact,priced_in,url,ai_json FROM news "
                "WHERE is_primary=1 ORDER BY published_at DESC LIMIT 25")
    return ok({
        "market": ctx.get("market"), "market_quotes": market_q, "sectors": (ctx.get("sectors") or [])[:12],
        "ml_top": ml_top, "ml_status": {h: {"validated": v["validated"], "created_at": v["created_at"]}
                                        for h, v in mlmodel.status()["models"].items()},
        "universe_n": ctx.get("universe_n"), "analyzed": ctx.get("analyzed"),
        "top_opportunities": opp, "top_scores": res[:15],
        "gainers": sorted(with_chg, key=lambda r: -r["change_pct"])[:10],
        "losers": sorted(with_chg, key=lambda r: r["change_pct"])[:10],
        "rvol": sorted([r for r in res if r.get("rvol")], key=lambda r: -r["rvol"])[:10],
        "news": news, "signals": sigs[:20], "opportunities": sigs[:10], "market_spark": market_spark,
        "portfolio": paper.equity(),
        "ai_summary": (rep or {}).get("ai_summary"), "report_date": (rep or {}).get("date"),
        "simple_market": assistant.simple_market(),
        "session": session(), "session_label": session_label(session()),
        "quotes_updated_at": db.kv_get("quotes_updated_at"), "last_run_id": db.kv_get("last_run_id"),
    })


# ------------------------------------------------------------------ scanner
@app.get("/api/scanner")
def api_scanner(category: str | None = None, sector: str | None = None, min_score: float = 0, limit: int = 400,
                sort: str = "score", min_price: float = 0, max_price: float = 0, min_dvol: float = 0):
    rows = [r for r in scanner.latest_results(category, limit=100000)
            if r["score"] >= min_score and (not sector or r.get("sector") == sector)
            and (not min_price or (r.get("price") or 0) >= min_price) and (not max_price or (r.get("price") or 0) <= max_price)
            and (not min_dvol or (r.get("dollar_vol") or 0) >= min_dvol)]
    keys = {"score": "score", "ml": "ml", "ml_short": "ml_short", "ml_swing": "ml_swing", "rvol": "rvol",
            "change": "change_pct", "atr": "atr_pct", "ret21": "ret21"}
    k = keys.get(sort, "score")
    rows.sort(key=lambda r: -(r.get(k) if isinstance(r.get(k), (int, float)) else -1e9))
    sectors = sorted({r.get("sector") for r in rows if r.get("sector")})
    return ok({"rows": rows[:limit], "total": len(rows), "categories": scanner.CATEGORY_LABELS,
               "run_id": db.kv_get("last_run_id"), "sectors": sectors})


@app.post("/api/scan")
def api_scan(update_data: bool = True):
    if scanner.progress()["running"]:
        return ok({"status": "already_running"})
    threading.Thread(target=scheduler.job_scan_and_report, daemon=True).start()
    return ok({"status": "started"})


@app.get("/api/scan/progress")
def api_scan_progress():
    return ok(scanner.progress())


# ------------------------------------------------------------------ stock
@app.get("/api/stock/{ticker}")
def api_stock(ticker: str, refresh: bool = False):
    t = ticker.upper().strip()
    if refresh or db.last_price_date(t) is None:
        service.update_history([t])
    if db.last_price_date(t) is None:
        raise HTTPException(404, f"Δεν βρέθηκαν δεδομένα για {t}")
    if refresh:
        service.refresh_quotes([t])
    b = pipeline.analyze_ticker(t, _ctx(), fetch_company=True, live=True)
    _acc, rej = signals.evaluate_setups(b)
    df = db.load_prices(t)
    news = db.q("SELECT * FROM news WHERE ticker=? ORDER BY published_at DESC LIMIT 40", (t,))
    for n in news:
        n["ai"] = json.loads(n.pop("ai_json")) if n.get("ai_json") else None
    info = service.get_company(t, fetch=False)
    sigs = [s for s in signals.list_signals("all", 500) if s["ticker"] == t][:20]
    hist_scores = db.q("SELECT date, score FROM scores WHERE ticker=? ORDER BY date", (t,))
    try:
        ml_pred = mlmodel.prediction_for(t)
    except Exception as e:  # noqa: BLE001
        ml_pred = {"error": str(e)}
    simple = assistant.simple_stock(b, ml_pred if isinstance(ml_pred, dict) and "error" not in ml_pred else {}, _acc)
    return ok({**b, "accepted": _acc, "rejected": rej, "chart": technical.chart_series(df), "ml_prediction": ml_pred,
               "simple": simple,
               "news_list": news, "filings": (info or {}).get("filings", []),
               "insiders": (info or {}).get("insiders", []), "analyst_actions": (info or {}).get("analyst_actions", []),
               "profile": {k: (info or {}).get(k) for k in ("longBusinessSummary", "website", "exchange", "country")},
               "signals": sigs, "score_history": hist_scores, "in_watchlist": t in service.watchlist(),
               "ai_enabled": ai.enabled()})


@app.get("/api/stock/{ticker}/intraday")
def api_intraday(ticker: str, interval: str = "5m", period: str = "5d"):
    if interval not in ("1m", "2m", "5m", "15m", "30m", "60m"):
        raise HTTPException(400, "interval")
    df = yahoo.intraday_bars(ticker.upper(), interval, period)
    if df.empty:
        return ok({"candles": [], "note": "Δεν υπάρχουν intraday δεδομένα"})
    d = df.rename(columns=str.lower)
    from .analysis import indicators as ind
    d["vwap"] = ind.vwap_intraday(d)
    t = [int(pd.Timestamp(i).timestamp()) for i in d.index]
    return ok({"candles": [{"time": ti, "open": o, "high": h, "low": l, "close": c} for ti, o, h, l, c in
                           zip(t, d["open"], d["high"], d["low"], d["close"])],
               "volume": [{"time": ti, "value": float(v or 0)} for ti, v in zip(t, d["volume"])],
               "vwap": [{"time": ti, "value": float(v)} for ti, v in zip(t, d["vwap"]) if v == v],
               "source": "yahoo", "note": "Yahoo intraday: πιθανή καθυστέρηση έως ~15'"})


@app.post("/api/stock/{ticker}/ai_explain")
def api_ai_explain(ticker: str):
    if not ai.enabled():
        return ok({"text": None, "error": "Δεν έχει οριστεί AI API key — λειτουργεί η ανάλυση κανόνων."})
    b = pipeline.analyze_ticker(ticker.upper(), _ctx(), live=True)
    txt = analyst.explain_stock(b)
    return ok({"text": txt, "error": None if txt else "Το AI δεν απάντησε (δες Κατάσταση)."})


# ------------------------------------------------------------------ signals / news / sectors
@app.get("/api/signals")
def api_signals(status: str = "active"):
    rows = signals.list_signals(status)
    by_t = {r["ticker"]: r for r in scanner.latest_results()}
    quotes = service.all_quotes()
    for sg in rows:
        r = by_t.get(sg["ticker"]) or {}
        q = quotes.get(sg["ticker"]) or {}
        sg.update(name=r.get("name"), spark=r.get("spark"), cur=q.get("price") or r.get("price"),
                  cur_chg=q.get("change_pct") if q.get("change_pct") is not None else r.get("change_pct"))
    if status == "active":
        rows.sort(key=signals._rank_key, reverse=True)
    return ok({"rows": rows, "stats": signals.stats()})


@app.get("/api/news")
def api_news(ticker: str | None = None, limit: int = 100, market_only: bool = False):
    if ticker:
        rows = db.q("SELECT * FROM news WHERE ticker=? ORDER BY published_at DESC LIMIT ?", (ticker.upper(), limit))
    elif market_only:
        rows = db.q("SELECT * FROM news WHERE ticker IS NULL ORDER BY published_at DESC LIMIT ?", (limit,))
    else:
        rows = db.q("SELECT * FROM news WHERE is_primary=1 ORDER BY published_at DESC LIMIT ?", (limit,))
    for n in rows:
        n["ai"] = json.loads(n.pop("ai_json")) if n.get("ai_json") else None
        n["duplicates"] = (db.q1("SELECT COUNT(*) n FROM news WHERE cluster_id=?", (n["cluster_id"],)) or {}).get("n", 1) - 1
    return ok({"rows": rows})


@app.get("/api/sectors")
def api_sectors():
    ctx = db.kv_get("last_context", {}) or {}
    res = scanner.latest_results()
    by = {}
    for r in res:
        by.setdefault(r.get("sector") or "?", []).append(r)
    return ok({"sectors": ctx.get("sectors") or [], "members": {k: v[:8] for k, v in by.items()},
               "market": ctx.get("market"), "breadth": ctx.get("breadth")})


# ------------------------------------------------------------------ watchlist & alerts
@app.get("/api/watchlist")
def api_watchlist():
    wl = service.watchlist()
    qs = service.all_quotes()
    sc = {r["ticker"]: r for r in scanner.latest_results()}
    return ok({"rows": [{"ticker": t, "quote": qs.get(t), "scan": sc.get(t)} for t in wl]})


@app.post("/api/watchlist/{ticker}")
def api_watch_add(ticker: str):
    t = ticker.upper().strip()
    if not t or len(t) > 12:
        raise HTTPException(400, "ticker")
    db.execute("INSERT OR IGNORE INTO watchlist(ticker, added_at) VALUES(?,?)", (t, db.now_iso()))
    threading.Thread(target=lambda: (service.update_history([t]), service.refresh_quotes([t])), daemon=True).start()
    return ok({"ok": True})


@app.delete("/api/watchlist/{ticker}")
def api_watch_del(ticker: str):
    db.execute("DELETE FROM watchlist WHERE ticker=?", (ticker.upper(),))
    return ok({"ok": True})


@app.get("/api/alerts")
def api_alerts(limit: int = 100):
    return ok({"rows": alerts.recent(limit), "unseen": (db.q1("SELECT COUNT(*) n FROM alerts WHERE seen=0") or {}).get("n")})


@app.post("/api/alerts/seen")
def api_alerts_seen():
    db.execute("UPDATE alerts SET seen=1 WHERE seen=0")
    return ok({"ok": True})


@app.post("/api/quotes/refresh")
def api_quotes_refresh():
    r = scheduler.job_quotes(force=True)
    return ok(r or {"status": "busy"})


# ------------------------------------------------------------------ reports
@app.get("/api/reports")
def api_reports():
    return ok({"dates": daily.dates()})


@app.get("/api/reports/latest")
def api_report_latest():
    return ok(daily.get() or {})


@app.get("/api/reports/{date}")
def api_report(date: str):
    r = daily.get(date)
    if not r:
        raise HTTPException(404, "Δεν υπάρχει report")
    return ok(r)


@app.post("/api/reports/build")
def api_report_build():
    return ok(daily.build())


# ------------------------------------------------------------------ backtest
@app.post("/api/backtest/walkforward")
def api_wf(universe: str = "scan", years_train: int = 2, months_test: int = 6):
    if wf.progress()["running"]:
        return ok({"status": "already_running"})
    tickers = listings.universe_tickers(settings.bt_max_tickers) or full_universe(service.watchlist())
    threading.Thread(target=wf.run_full, args=(tickers, years_train, months_test), daemon=True).start()
    return ok({"status": "started", "tickers": len(tickers)})


@app.get("/api/backtest/progress")
def api_wf_progress():
    return ok(wf.progress())


@app.get("/api/backtests")
def api_backtests():
    rows = db.q("SELECT id, created_at, name, params_json, metrics_json FROM backtests ORDER BY id DESC LIMIT 30")
    for r in rows:
        m = json.loads(r.pop("metrics_json"))
        r["summary"] = {"walk_forward": m.get("walk_forward"), "test": (m.get("static") or {}).get("test")}
        r["params"] = json.loads(r.pop("params_json"))
    return ok({"rows": rows, "suggestion": db.kv_get("wf_suggestion"), "weights_history": db.kv_get("weights_history", [])})


@app.get("/api/backtests/{bid}")
def api_backtest(bid: int):
    r = db.q1("SELECT * FROM backtests WHERE id=?", (bid,))
    if not r:
        raise HTTPException(404)
    return ok({"id": r["id"], "created_at": r["created_at"], "name": r["name"], "params": json.loads(r["params_json"]),
               "metrics": json.loads(r["metrics_json"]), "equity": json.loads(r["equity_json"]),
               "trades": json.loads(r["trades_json"])[-300:]})


@app.post("/api/backtest/apply_suggestion")
def api_apply_suggestion(note: str = Body("", embed=True)):
    s = db.kv_get("wf_suggestion") or {}
    sug = s.get("suggestion")
    if not sug:
        raise HTTPException(400, "Δεν υπάρχει τεκμηριωμένη πρόταση")
    old = dict(settings.weights)
    new = dict(old)
    # τα βάρη του backtest αφορούν 4 παράγοντες· κρατάμε το ίδιο συνολικό βάρος τους
    tot = sum(old[k] for k in bt.BT_COMPONENTS)
    for k in bt.BT_COMPONENTS:
        new[k] = sug["weights"][k] * tot
    w = save_weights(new)
    hist = db.kv_get("weights_history", []) or []
    hist.append({"at": db.now_iso(), "from": old, "to": w, "backtest_id": s.get("backtest_id"), "reason": sug["why"], "note": note})
    db.kv_set("weights_history", hist[-50:])
    return ok({"weights": w})


@app.get("/api/predictions/report")
def api_pred_report():
    wf.resolve_predictions()
    return ok(wf.prediction_report())


# ------------------------------------------------------------------ paper trading & risk
@app.get("/api/paper")
def api_paper():
    return ok({"equity": paper.equity(), "positions": paper.positions(), "history": paper.history()})


@app.post("/api/paper/open")
def api_paper_open(payload: dict = Body(...)):
    return ok(paper.open_trade(payload.get("ticker", ""), payload.get("side", "long"), payload.get("qty"),
                               payload.get("stop"), payload.get("target"), payload.get("signal_id"), payload.get("note", "")))


@app.post("/api/paper/close/{tid}")
def api_paper_close(tid: int):
    return ok(paper.close_trade(tid))


@app.get("/api/risk/position")
def api_position(entry: float, stop: float, account: float | None = None, risk_pct: float | None = None):
    return ok(risk.position_size(entry, stop, account, risk_pct))


# ------------------------------------------------------------------ AI βοηθός
@app.post("/api/assistant")
def api_assistant(payload: dict = Body(...)):
    msg = str(payload.get("message", "")).strip()[:2000]
    if not msg:
        raise HTTPException(400, "Κενό μήνυμα")
    try:
        r = assistant.chat(msg, payload.get("ticker"), payload.get("history") or [])
    except Exception as e:  # noqa: BLE001
        log.exception("assistant")
        return ok({"reply": f"Κάτι πήγε στραβά στην ανάλυση: {e}", "used_ai": False})
    r.pop("simple", None)
    r["ai_enabled"] = ai.enabled()
    return ok(r)


# ------------------------------------------------------------------ ML & universe
@app.get("/api/ml/status")
def api_ml_status():
    return ok(mlmodel.status())


@app.post("/api/ml/train")
def api_ml_train():
    if mlmodel.progress()["running"]:
        return ok({"status": "already_running"})
    threading.Thread(target=scheduler.job_ml_train, daemon=True).start()
    return ok({"status": "started"})


@app.get("/api/ml/top")
def api_ml_top(horizon: str = "short", limit: int = 50):
    rows = db.q("SELECT p.ticker, p.p, p.rank_pct, p.exp_r, p.date, u.name, u.price, u.dollar_volume, u.market_cap "
                "FROM ml_predictions p LEFT JOIN universe u ON u.ticker=p.ticker WHERE p.horizon=? AND "
                "p.date=(SELECT MAX(date) FROM ml_predictions WHERE horizon=?) ORDER BY p.p DESC LIMIT ?",
                (horizon, horizon, limit))
    return ok({"rows": rows})


@app.get("/api/search")
def api_search(q: str = "", limit: int = 12):
    q = q.strip().upper()
    if not q:
        return ok({"rows": []})
    rows = db.q("SELECT ticker, name, price, dollar_volume FROM universe WHERE active=1 AND (ticker LIKE ? OR UPPER(name) LIKE ?) "
                "ORDER BY (ticker=?) DESC, (ticker LIKE ?) DESC, COALESCE(dollar_volume,0) DESC LIMIT ?",
                (q + "%", "%" + q + "%", q, q + "%", limit))
    return ok({"rows": rows})


@app.get("/api/sec/status")
def api_sec_status():
    from .data import secdata
    return ok(secdata.status())


@app.get("/api/universe")
def api_universe():
    n = db.q1("SELECT COUNT(*) n FROM universe WHERE active=1") or {}
    by = db.q("SELECT COALESCE(exchange,'?') exchange, COUNT(*) n FROM universe WHERE active=1 GROUP BY 1 ORDER BY 2 DESC")
    return ok({"n": n.get("n"), "by_exchange": by, "source": db.kv_get("universe_source"),
               "built_at": db.kv_get("universe_built_at"), "errors": db.kv_get("universe_errors"),
               "min_price": settings.min_price, "min_dollar_volume": settings.universe_min_dollar_vol,
               "listing_progress": listings.progress()})


@app.post("/api/universe/rebuild")
def api_universe_rebuild():
    threading.Thread(target=listings.build_universe, kwargs={"force": True}, daemon=True).start()
    return ok({"status": "started"})


# ------------------------------------------------------------------ settings
EDITABLE = {
    "ACCOUNT_SIZE": "account_size", "RISK_PER_TRADE_PCT": "risk_per_trade_pct", "MAX_POSITION_PCT": "max_position_pct",
    "MAX_SECTOR_PCT": "max_sector_pct", "MIN_RR": "min_rr", "MIN_DOLLAR_VOLUME": "min_dollar_volume",
    "SLIPPAGE_BPS": "slippage_bps", "AI_PROVIDER": "ai_provider", "AI_MODEL": "ai_model",
    "AI_MONTHLY_BUDGET_USD": "ai_monthly_budget_usd", "SEC_USER_AGENT": "sec_user_agent",
    "MIN_PRICE": "min_price", "UNIVERSE_MIN_DOLLAR_VOL": "universe_min_dollar_vol", "MAX_UNIVERSE": "max_universe",
    "DEEP_N": "deep_n", "ML_MIN_EXP_R": "ml_min_exp_r", "ML_RETRAIN_DAYS": "ml_retrain_days",
    "MAX_ACTIVE_PER_HORIZON": "max_active_per_horizon", "HISTORY_YEARS": "history_years",
}


@app.get("/api/settings")
def api_settings():
    return ok({
        "weights": settings.weights, "default_weights": DEFAULT_WEIGHTS,
        "values": {k: getattr(settings, a) for k, a in EDITABLE.items()},
        "keys": {k: {"configured": settings.has(k), "masked": mask(settings.secret(k))} for k in SECRET_KEYS},
    })


@app.post("/api/settings")
def api_settings_save(payload: dict = Body(...)):
    if "weights" in payload:
        save_weights(payload["weights"])
    for k, v in (payload.get("values") or {}).items():
        if k in EDITABLE:
            attr = EDITABLE[k]
            cur = getattr(settings, attr)
            try:
                val = type(cur)(v) if not isinstance(cur, str) else str(v)
            except (TypeError, ValueError):
                raise HTTPException(400, f"Μη έγκυρη τιμή για {k}")
            setattr(settings, attr, val)
            set_env_value(k, str(val))
    for k, v in (payload.get("keys") or {}).items():
        if k in SECRET_KEYS and isinstance(v, str):
            set_env_value(k, v.strip())
    return api_settings()


@app.post("/api/ai/test/{provider}")
def api_ai_test(provider: str):
    if provider not in ai.PROVIDERS:
        raise HTTPException(400)
    return ok(ai.test_connection(provider))


@app.get("/api/ai/usage")
def api_ai_usage():
    return ok(ai.usage_summary())


@app.get("/api/debug/news")
def api_debug_news(ticker: str = "AAPL"):
    from .data import rss
    out = {}
    for name, fn in (("yahoo", lambda: yahoo.news(ticker)), ("yahoo_rss", lambda: rss.yahoo_rss(ticker)),
                     ("google_news", lambda: rss.google_news(ticker))):
        try:
            items = fn()
            out[name] = {"n": len(items), "sample": items[:2]}
        except Exception as e:  # noqa: BLE001
            out[name] = {"error": repr(e)[:300]}
    out["last_job_counts"] = db.kv_get("news_sources")
    return ok(out)


# ------------------------------------------------------------------ admin (μόνο τοπικά: ο server ακούει στο 127.0.0.1)
@app.post("/api/admin/shutdown")
def api_shutdown():
    import os
    threading.Timer(0.5, lambda: os._exit(0)).start()
    return ok({"status": "shutting_down"})


@app.post("/api/admin/restart")
def api_restart():
    """Επανεκκίνηση (φορτώνει νέα έκδοση κώδικα): ανοίγει νέο run.bat, το οποίο κλείνει αυτόν τον server."""
    import os
    import subprocess
    if os.name == "nt":
        subprocess.Popen(["cmd", "/c", "start", "US Alpha Terminal", "run.bat"], cwd=str(ROOT))
    else:
        subprocess.Popen([sys.executable, "run.py"], cwd=str(ROOT))
    return ok({"status": "restarting"})


# ------------------------------------------------------------------ SSE
@app.get("/api/stream")
async def api_stream():
    qq = alerts.subscribe()

    async def gen():
        try:
            yield "event: hello\ndata: {}\n\n"
            while True:
                try:
                    msg = await asyncio.to_thread(qq.get, True, 20)
                    yield f"event: {msg['event']}\ndata: {json.dumps(msg['data'], default=str)}\n\n"
                except queue.Empty:
                    yield ": keepalive\n\n"
        finally:
            alerts.unsubscribe(qq)

    return StreamingResponse(gen(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


# ------------------------------------------------------------------ η ίδια εφαρμογή με το κινητό (κοινά αρχεία στο mobile/)
MOBILE = ROOT / "mobile"
_mcache: dict = {}


def _mkey() -> str:
    return f"{db.kv_get('last_run_id')}|{(db.kv_get('daytrade') or {}).get('at')}|{db.kv_get('ml_predicted_at')}"


@app.get("/data/snapshot.json")
def data_snapshot():
    from . import mobile_data as MD
    k = _mkey()
    hit = _mcache.get("snap")
    if not hit or hit[0] != k or __import__("time").time() - hit[1] > 600:
        _mcache["snap"] = (k, __import__("time").time(), MD.clean(MD.snapshot()))
    if not _mcache["snap"][2].get("rows"):
        raise HTTPException(404, "Δεν υπάρχει ακόμα ανάλυση")
    return JSONResponse(_mcache["snap"][2])


@app.get("/data/quotes.json")
def data_quotes():
    from . import mobile_data as MD
    return JSONResponse(MD.clean(MD.live_quotes()))


@app.get("/data/s/{name}")
def data_shard(name: str):
    from . import mobile_data as MD
    t = name.removesuffix(".json").upper().replace("_", "^", 1) if name.startswith("_") else name.removesuffix(".json").upper()
    ck = ("s", t, _mkey())
    hit = _mcache.get(ck)
    if not hit or __import__("time").time() - hit[0] > 300:
        if db.last_price_date(t) is None:
            raise HTTPException(404, "Δεν βρέθηκε")
        d = MD.shard(t, live=True)
        if not d:
            raise HTTPException(404, "Δεν βρέθηκε")
        for kk in [kk for kk in _mcache if isinstance(kk, tuple) and kk[0] == "s"][:-40]:
            _mcache.pop(kk, None)
        _mcache[ck] = (__import__("time").time(), MD.clean(d))
    return JSONResponse(_mcache[ck][1])


@app.get("/api/daytrade")
def api_daytrade():
    return ok(db.kv_get("daytrade") or {"long": [], "short": []})


@app.get("/")
def index():
    if (MOBILE / "index.html").exists():
        return FileResponse(MOBILE / "index.html")
    return FileResponse(WEB / "index.html")


@app.get("/classic")
def index_classic():
    return FileResponse(WEB / "index.html")


app.mount("/static", StaticFiles(directory=WEB), name="static")
if MOBILE.exists():
    app.mount("/", StaticFiles(directory=MOBILE), name="mobile")
