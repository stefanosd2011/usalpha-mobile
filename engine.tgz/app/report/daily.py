"""Ημερήσιο Market Intelligence Report με σύγκριση με την προηγούμενη ημέρα."""
from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone

from .. import db
from ..ai import analyst
from ..backtest import walkforward
from ..engine import scanner, signals


def _prev_report(date: str) -> dict | None:
    r = db.q1("SELECT json FROM reports WHERE date<? ORDER BY date DESC LIMIT 1", (date,))
    return json.loads(r["json"]) if r else None


def build(date: str | None = None) -> dict:
    date = date or datetime.now(timezone.utc).date().isoformat()
    ctx = db.kv_get("last_context", {}) or {}
    results = scanner.latest_results()
    by_ticker = {r["ticker"]: r for r in results}
    mk = ctx.get("market") or {}
    sectors = ctx.get("sectors") or []

    gainers = sorted([r for r in results if r.get("change_pct") is not None], key=lambda r: -r["change_pct"])[:10]
    losers = sorted([r for r in results if r.get("change_pct") is not None], key=lambda r: r["change_pct"])[:10]
    unusual = sorted([r for r in results if (r.get("rvol") or 0) >= 2], key=lambda r: -(r.get("rvol") or 0))[:15]
    top = results[:20]
    cats = {c: [r["ticker"] for r in results if c in r["categories"]][:10] for c in scanner.CATEGORY_LABELS}

    # δυνατές μετοχές μέσα στους ισχυρότερους κλάδους
    leaders = []
    for s in sectors[:4]:
        mem = [r for r in results if r.get("sector") == s["sector"]][:3]
        leaders.append({"sector": s["sector"], "score": s["score"], "tickers": [m["ticker"] for m in mem]})

    since = (datetime.now(timezone.utc) - timedelta(hours=30)).isoformat()
    news = db.q("SELECT ticker,title,source,published_at,category,sentiment,impact,priced_in,url FROM news "
                "WHERE published_at>=? AND is_primary=1 ORDER BY ABS(impact) DESC LIMIT 25", (since,))
    new_signals = db.q("SELECT id,ticker,horizon,bias,price,stop,tp2,rr,score,confidence FROM signals WHERE created_at>=?",
                       (since,))
    closed = db.q("SELECT id,ticker,horizon,bias,outcome,outcome_return FROM signals WHERE closed_at>=?", (since,))
    active = signals.list_signals("active")

    walkforward.resolve_predictions()
    pred = walkforward.prediction_report()

    # ---- σύγκριση με χθες
    prev = _prev_report(date)
    changes = {}
    if prev:
        pm = prev.get("market", {})
        if pm.get("regime") != mk.get("regime"):
            changes["regime"] = f"{pm.get('regime')} → {mk.get('regime')}"
        prev_rank = {s["sector"]: s["rank"] for s in prev.get("sectors", [])}
        changes["sector_moves"] = [{"sector": s["sector"], "from": prev_rank.get(s["sector"]), "to": s["rank"]}
                                   for s in sectors if prev_rank.get(s["sector"]) and prev_rank[s["sector"]] != s["rank"]]
        prev_scores = prev.get("scores", {})
        deltas = []
        for t, r in by_ticker.items():
            if t in prev_scores:
                d = r["score"] - prev_scores[t]
                if abs(d) >= 5:
                    deltas.append({"ticker": t, "from": prev_scores[t], "to": r["score"], "delta": round(d, 1)})
        changes["score_changes"] = sorted(deltas, key=lambda x: -abs(x["delta"]))[:20]
        prev_top = set(prev.get("top_tickers", []))
        cur_top = {r["ticker"] for r in top}
        changes["new_in_top"] = sorted(cur_top - prev_top)
        changes["dropped_from_top"] = sorted(prev_top - cur_top)

    movers = {"gainers": [(g["ticker"], g["change_pct"]) for g in gainers[:5]],
              "losers": [(g["ticker"], g["change_pct"]) for g in losers[:5]],
              "unusual_volume": [(u["ticker"], u.get("rvol")) for u in unusual[:5]]}
    ai_text = analyst.market_summary({"market": mk, "sectors": sectors[:5]}, movers,
                                     [{"date": n["published_at"][:10], "title": n["title"], "ticker": n["ticker"]} for n in news],
                                     changes)
    rep = {
        "date": date, "created_at": db.now_iso(), "market": mk, "sectors": sectors, "sector_leaders": leaders,
        "gainers": gainers, "losers": losers, "unusual": unusual, "top": top, "categories": cats,
        "news": news, "signals_new": new_signals, "signals_closed": closed, "signals_active": active[:30],
        "signal_stats": signals.stats(), "predictions": pred, "changes": changes, "ai_summary": ai_text,
        "scores": {t: r["score"] for t, r in by_ticker.items()}, "top_tickers": [r["ticker"] for r in top],
    }
    db.execute("INSERT INTO reports(date,created_at,json) VALUES(?,?,?) ON CONFLICT(date) DO UPDATE SET "
               "created_at=excluded.created_at, json=excluded.json", (date, rep["created_at"], json.dumps(rep, default=str)))
    return rep


def get(date: str | None = None) -> dict | None:
    r = db.q1("SELECT json FROM reports WHERE date=?", (date,)) if date else \
        db.q1("SELECT json FROM reports ORDER BY date DESC LIMIT 1")
    return json.loads(r["json"]) if r else None


def dates() -> list[str]:
    return [r["date"] for r in db.q("SELECT date FROM reports ORDER BY date DESC LIMIT 60")]
