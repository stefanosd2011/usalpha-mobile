"""Paper trading: δοκιμή στρατηγικών χωρίς πραγματικά χρήματα. Οι εκτελέσεις γίνονται στην
τελευταία διαθέσιμη τιμή (με ένδειξη ποιότητας) και slippage. Καμία σύνδεση με broker."""
from __future__ import annotations

from .. import db
from ..config import settings
from ..data import service
from ..engine import alerts, risk


def _price(ticker: str) -> tuple[float | None, str]:
    q = service.get_quote(ticker)
    if not q or q.get("price") is None:
        return None, "NO_DATA"
    return float(q["price"]), q.get("quality") or "?"


def open_trade(ticker: str, side: str, qty: float | None = None, stop: float | None = None,
               target: float | None = None, signal_id: int | None = None, note: str = "") -> dict:
    ticker = ticker.upper().strip()
    price, quality = _price(ticker)
    if price is None:
        return {"ok": False, "error": "Δεν υπάρχει τιμή για το ticker"}
    if quality in ("STALE",):
        return {"ok": False, "error": "Η τιμή είναι παλιά (STALE) — δεν εκτελείται paper trade"}
    if side not in ("long", "short"):
        return {"ok": False, "error": "side: long ή short"}
    slip = settings.slippage_bps / 10000
    fill = price * (1 + slip if side == "long" else 1 - slip)
    if not qty:
        if not stop:
            return {"ok": False, "error": "Δώσε ποσότητα ή stop για αυτόματο position sizing"}
        qty = risk.position_size(fill, stop, account=equity()["equity"])["shares"]
    if qty <= 0:
        return {"ok": False, "error": "Μηδενική ποσότητα"}
    tid = db.execute("INSERT INTO paper_trades(ticker,side,qty,entry,stop,target,opened_at,status,signal_id,note) "
                     "VALUES(?,?,?,?,?,?,?,?,?,?)",
                     (ticker, side, qty, round(fill, 4), stop, target, db.now_iso(), "open", signal_id,
                      f"{note} [τιμή {quality}]".strip()))
    return {"ok": True, "id": tid, "fill": round(fill, 4), "qty": qty, "quality": quality}


def close_trade(tid: int, reason: str = "manual", price: float | None = None) -> dict:
    t = db.q1("SELECT * FROM paper_trades WHERE id=? AND status='open'", (tid,))
    if not t:
        return {"ok": False, "error": "Δεν βρέθηκε ανοιχτό trade"}
    if price is None:
        price, _q = _price(t["ticker"])
        if price is None:
            return {"ok": False, "error": "Δεν υπάρχει τιμή"}
    slip = settings.slippage_bps / 10000
    fill = price * (1 - slip if t["side"] == "long" else 1 + slip)
    pnl = (fill - t["entry"]) * t["qty"] * (1 if t["side"] == "long" else -1)
    db.execute("UPDATE paper_trades SET status='closed', closed_at=?, exit=?, pnl=?, note=COALESCE(note,'')||? WHERE id=?",
               (db.now_iso(), round(fill, 4), round(pnl, 2), f" | έξοδος: {reason}", tid))
    return {"ok": True, "pnl": round(pnl, 2), "exit": round(fill, 4)}


def check_stops(quotes: dict[str, dict]) -> None:
    for t in db.q("SELECT * FROM paper_trades WHERE status='open'"):
        q = quotes.get(t["ticker"])
        if not q or q.get("price") is None or q.get("quality") in ("STALE", "NO_DATA"):
            continue
        p = float(q["price"])
        long = t["side"] == "long"
        if t["stop"] and ((long and p <= t["stop"]) or (not long and p >= t["stop"])):
            r = close_trade(t["id"], "stop", p)
            alerts.add("paper", f"Paper {t['ticker']}: stop @ {p:.2f} (P/L {r.get('pnl')})", t["ticker"], "medium",
                       f"paper_stop:{t['id']}")
        elif t["target"] and ((long and p >= t["target"]) or (not long and p <= t["target"])):
            r = close_trade(t["id"], "target", p)
            alerts.add("paper", f"Paper {t['ticker']}: target @ {p:.2f} (P/L {r.get('pnl')})", t["ticker"], "medium",
                       f"paper_tgt:{t['id']}")


def positions() -> list[dict]:
    out = []
    for t in db.q("SELECT * FROM paper_trades WHERE status='open' ORDER BY id DESC"):
        price, quality = _price(t["ticker"])
        upnl = None
        if price is not None:
            upnl = (price - t["entry"]) * t["qty"] * (1 if t["side"] == "long" else -1)
        out.append({**t, "price": price, "quality": quality, "upnl": None if upnl is None else round(upnl, 2),
                    "sector": service.sector_of(t["ticker"])})
    return out


def history(limit: int = 200) -> list[dict]:
    return db.q("SELECT * FROM paper_trades WHERE status='closed' ORDER BY closed_at DESC LIMIT ?", (limit,))


def equity() -> dict:
    start = settings.account_size
    realized = (db.q1("SELECT COALESCE(SUM(pnl),0) s FROM paper_trades WHERE status='closed'") or {"s": 0})["s"]
    pos = positions()
    unreal = sum(p["upnl"] or 0 for p in pos)
    closed = db.q("SELECT pnl FROM paper_trades WHERE status='closed'")
    wins = sum(1 for c in closed if (c["pnl"] or 0) > 0)
    port = risk.portfolio_risk([{"ticker": p["ticker"], "qty": p["qty"], "price": p["price"] or p["entry"],
                                 "stop": p["stop"], "sector": p["sector"]} for p in pos if p["side"] == "long"],
                               account=start + realized + unreal)
    return {"start": start, "realized": round(realized, 2), "unrealized": round(unreal, 2),
            "equity": round(start + realized + unreal, 2), "open_positions": len(pos),
            "closed_trades": len(closed), "win_rate": round(wins / len(closed) * 100, 1) if closed else None,
            "risk": port}
