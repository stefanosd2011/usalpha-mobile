"""Δεδομένα για την εφαρμογή (ίδια σε κινητό και υπολογιστή).

Το κινητό τα παίρνει ως στατικά αρχεία από τη βραδινή ανάλυση στο GitHub (tools/export_mobile.py),
ο υπολογιστής τα σερβίρει ζωντανά από τη βάση του (main.py: /data/...). Ίδιες συναρτήσεις, ίδια μορφή."""
from __future__ import annotations

import math
from datetime import date, datetime, timedelta, timezone

from . import db
from .config import settings


def clean(o):
    if isinstance(o, float):
        return None if (math.isnan(o) or math.isinf(o)) else o
    if isinstance(o, dict):
        return {str(k): clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [clean(v) for v in o]
    if hasattr(o, "item") and callable(o.item):  # numpy scalar
        try:
            return clean(o.item())
        except Exception:  # noqa: BLE001
            return None
    if isinstance(o, (datetime, date)):
        return o.isoformat()
    return o


def r(v, n=4):
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None
    if math.isnan(f) or math.isinf(f):
        return None
    if abs(f) >= 1000:
        return round(f, 2 if abs(f) < 1e6 else 0)
    return round(f, n)



class Ctx:
    """Κοινά στοιχεία μιας εξαγωγής (τελευταίο scan, ονόματα, signals)."""

    def __init__(self):
        from .engine import scanner, signals
        self.ctx = db.kv_get("last_context", {}) or {}
        self.res = scanner.latest_results()
        self.by_t = {x["ticker"]: x for x in self.res}
        self.signals = signals.list_signals("all", 2000)
        self.alt = {}
        try:
            self.alt = {r_["ticker"]: r_ for r_ in db.q("SELECT ticker, name, sector, industry FROM meta_alt")}
        except Exception:  # noqa: BLE001
            pass
        self.uni = {r_["ticker"]: r_["name"] for r_ in db.q("SELECT ticker, name FROM universe")}
        self._pctx = None

    def nm(self, t: str, n: str | None = None) -> str:
        n = n or (self.alt.get(t) or {}).get("name") or self.uni.get(t) or ""
        for suf in (" - Common Stock", " Common Stock", " - Class A Common Stock", " - American Depositary Shares"):
            n = n.replace(suf, "")
        return n.strip()

    def as_cache(self) -> dict:
        return {"signals": self.signals, "nm": self.nm, "alt": self.alt}

    def pctx(self):
        if self._pctx is None:
            from .engine import pipeline
            self._pctx = pipeline.Context.build(self.ctx.get("breadth"), self.ctx.get("member_scores"))
        return self._pctx


SETUP_KEYS = ("horizon", "bias", "setup", "entry_low", "entry_high", "entry", "stop", "tp1", "tp2", "tp3", "rr",
              "stop_pct", "holding", "max_days", "reasons", "confidence", "ml_p", "ml_exp_r", "rank_pct", "rank_ex",
              "catalysts", "risks")


def setup_out(s: dict, rejected: bool = False) -> dict:
    o = {k: s.get(k) for k in SETUP_KEYS}
    c = s.get("confirmation") or {}
    o["conf"] = {"sup": c.get("supporting", []), "opp": c.get("opposing", []), "conflicts": c.get("conflicts", [])}
    if s.get("position"):
        p = s["position"]
        o["pos"] = {"shares": p.get("shares"), "value": p.get("position_value"), "risk": p.get("risk_amount"),
                    "riskPct": p.get("risk_pct_account"), "account": p.get("account")}
    if rejected:
        o["why"] = s.get("rejected_because", [])
    for k in ("entry_low", "entry_high", "entry", "stop", "tp1", "tp2", "tp3"):
        o[k] = r(o[k])
    return o


def vp_summary(vp: dict | None) -> dict | None:
    bins = (vp or {}).get("bins") or []
    if not bins:
        return None
    tot = sum(b["volume"] for b in bins) or 1
    i = max(range(len(bins)), key=lambda k: bins[k]["volume"])
    lo = hi = i
    acc = bins[i]["volume"]
    while acc / tot < 0.7 and (lo > 0 or hi < len(bins) - 1):
        a = bins[lo - 1]["volume"] if lo > 0 else -1
        b = bins[hi + 1]["volume"] if hi < len(bins) - 1 else -1
        if a >= b:
            lo -= 1
            acc += a
        else:
            hi += 1
            acc += b
    return {"poc": r((bins[i]["low"] + bins[i]["high"]) / 2), "vaLow": r(bins[lo]["low"]), "vaHigh": r(bins[hi]["high"])}


def _shard(t: str, b: dict, info_cache: dict) -> dict:
    from .ai import assistant
    from .data import service
    from .engine import signals
    from .ml import model as mlmodel
    acc, rej = signals.evaluate_setups(b)
    try:
        pred = mlmodel.prediction_for(t)
    except Exception as e:  # noqa: BLE001
        pred = {}
    try:  # μοντέλο v4 (δίπλα στο v3)
        from .ml import v4 as ml4
        pred4 = ml4.prediction_for(t)
    except Exception:  # noqa: BLE001
        pred4 = {}
    simple = assistant.simple_stock(b, pred, acc)
    df = db.load_prices(t, start=(date.today() - timedelta(days=560)).isoformat())
    tech, fund, q = b["tech"], b["fund"], b.get("quote") or {}
    m = dict(tech.get("metrics") or {})
    rs = m.pop("rs", None) or {}
    news = db.q("SELECT title,url,source,published_at,category,sentiment,impact FROM news WHERE ticker=? AND is_primary=1 "
                "ORDER BY published_at DESC LIMIT 12", (t,))
    info = service.get_company(t, fetch=False) or {}
    sig = [s for s in info_cache.get("signals", []) if s["ticker"] == t][:8]
    fm = fund.get("metrics") or {}
    out = {
        "v": 2, "ticker": t, "name": info_cache["nm"](t, b.get("name")), "sector": b.get("sector") or (info_cache["alt"].get(t) or {}).get("sector"),
        "industry": b.get("industry") or (info_cache["alt"].get(t) or {}).get("industry"),
        "asOf": tech.get("as_of") or (df.index[-1].strftime("%Y-%m-%d") if len(df) else None),
        "price": r(q.get("price") or m.get("close")), "chg": r(q.get("change_pct") if q.get("change_pct") is not None else m.get("change_pct"), 2),
        "tech": {"technical": tech.get("technical_score"), "momentum": tech.get("momentum_score"), "flags": tech.get("flags", []),
                 "pros": tech.get("pros", []), "cons": tech.get("cons", []), "m": {k: r(v) for k, v in m.items()},
                 "rs": {k: (r(v, 2) if not isinstance(v, bool) else v) for k, v in rs.items()},
                 "levels": [{"price": r(x["price"]), "touches": x.get("touches"), "type": x.get("type")} for x in tech.get("levels") or []],
                 "vp": vp_summary(tech.get("volume_profile"))},
        "risk": {"score": b["risk"].get("score"), "warnings": [w.get("text") for w in b["risk"].get("warnings", [])]},
        "sc": {"score": b["scored"]["score"], "bias": b["scored"]["bias"], "coverage": b["scored"].get("coverage"),
               "contrib": [{"label": c["label"], "score": c.get("score"), "weight": c.get("weight"), "impact": c.get("impact")}
                           for c in b["scored"].get("contributions", [])],
               "explain": {k: (b["scored"].get("explain") or {}).get(k) for k in ("summary", "pros", "cons", "what_changes")}},
        "fund": {"score": fund.get("score"), "coverage": fund.get("coverage"), "pros": fund.get("pros", []), "cons": fund.get("cons", []),
                 "risks": fund.get("risks", []), "m": {k: r(v) for k, v in fm.items()}},
        "news": {"score": b["news"].get("score"), "n": b["news"].get("n_clusters", 0),
                 "items": [{"title": n["title"], "url": n["url"], "source": n["source"], "at": n["published_at"],
                            "sent": r(n["sentiment"], 2), "cat": n["category"]} for n in news]},
        "pred": {h: {"label": p.get("label"), "kind": p.get("kind"), "days": p.get("days"), "p": r(p.get("p")), "rank": r(p.get("rank_pct")),
                     "exp": r(p.get("exp_r"), 5), "validated": bool(p.get("validated")), "date": p.get("date"),
                     "breakeven": p.get("breakeven"),
                     "drivers": [{"label": d["label"], "value": d.get("value"), "effect": d.get("effect")} for d in (p.get("drivers") or [])[:8]]}
                 for h, p in (pred or {}).items()},
        "pred4": {h: {"label": p.get("label"), "kind": p.get("kind"), "days": p.get("days"), "p": r(p.get("p")), "rank": r(p.get("rank_pct")),
                      "exp": r(p.get("exp_r"), 5), "validated": bool(p.get("validated")), "active": bool(p.get("active")),
                      "date": p.get("date"), "breakeven": p.get("breakeven"),
                      "drivers": [{"label": d["label"], "value": d.get("value"), "effect": d.get("effect")} for d in (p.get("drivers") or [])[:8]]}
                  for h, p in (pred4 or {}).items()},
        "acc": [setup_out(s) for s in acc], "rej": [setup_out(s, True) for s in rej],
        "simple": simple,
        "profile": {"summary": info.get("longBusinessSummary"), "website": info.get("website"), "exchange": info.get("exchange"),
                    "country": info.get("country"), "employees": info.get("fullTimeEmployees")},
        "insiders": (info.get("insiders") or [])[:8], "analysts": (info.get("analyst_actions") or [])[:8],
        "signals": [{"horizon": s["horizon"], "setup": s.get("setup"), "date": s["created_at"][:10], "status": s["status"],
                     "outcome": s.get("outcome"), "ret": r(s.get("outcome_return"), 2)} for s in sig],
        "bars": {"d": [x.strftime("%Y-%m-%d") for x in df.index], "o": [r(x) for x in df["open"]], "h": [r(x) for x in df["high"]],
                 "l": [r(x) for x in df["low"]], "c": [r(x) for x in df["close"]], "v": [int(x or 0) for x in df["volume"].fillna(0)]},
    }
    return out



def bars(df) -> dict:
    return {"d": [x.strftime("%Y-%m-%d") for x in df.index], "o": [r(x) for x in df["open"]], "h": [r(x) for x in df["high"]],
            "l": [r(x) for x in df["low"]], "c": [r(x) for x in df["close"]], "v": [int(x or 0) for x in df["volume"].fillna(0)]}


def shard(t: str, b: dict | None = None, cx: Ctx | None = None, live: bool = False) -> dict | None:
    """Πλήρης ανάλυση μιας μετοχής (ή γράφημα για δείκτη/ETF)."""
    cx = cx or Ctx()
    if b is None:
        from .engine import pipeline
        df = db.load_prices(t, start=(date.today() - timedelta(days=620)).isoformat())
        if len(df) < 30:
            return None
        if len(df) >= 60:
            b = pipeline.analyze_ticker(t, cx.pctx(), live=live)
        if not b or not b.get("ok"):
            return index_shard(t, df)
    return _shard(t, b, cx.as_cache())


def index_shard(sym: str, df=None) -> dict | None:
    if df is None:
        df = db.load_prices(sym, start=(date.today() - timedelta(days=560)).isoformat())
    if len(df) < 30:
        return None
    df = df.tail(390)
    c = df["close"]
    return {"v": 2, "ticker": sym, "name": sym, "index": True, "asOf": df.index[-1].strftime("%Y-%m-%d"), "price": r(c.iloc[-1]),
            "chg": r((c.iloc[-1] / c.iloc[-2] - 1) * 100, 2), "bars": bars(df)}


def model_out() -> tuple[dict, dict]:
    from .ml import model as mlmodel
    st = mlmodel.status()
    out = {}
    for h, v in (st.get("models") or {}).items():
        mt = v.get("metrics") or {}
        oos = mt.get("oos") or {}
        cfg = (st.get("horizons") or {}).get(h, {})
        out[h] = {"label": v.get("label") or cfg.get("label"), "kind": v.get("kind") or cfg.get("kind"), "days": cfg.get("H"),
                  "validated": bool(v.get("validated")), "createdAt": v.get("created_at"), "nTrain": v.get("n_train"),
                  "dataEnd": v.get("data_end"), "gate": mt.get("gate", []), "nTickers": mt.get("n_tickers"),
                  "ic": oos.get("ic_mean"), "icT": oos.get("ic_t"), "icPos": oos.get("ic_pos_share"), "dates": oos.get("dates"),
                  "auc": oos.get("auc"), "top": oos.get("top_decile_R"), "bottom": oos.get("bottom_decile_R"), "ls": oos.get("long_short"),
                  "hit": oos.get("top_decile_hit"), "base": oos.get("base_rate"),
                  "deciles": [{"decile": d["decile"], "avg": d.get("avg_R"), "hit": d.get("hit")} for d in oos.get("deciles", [])],
                  "folds": [{"test": f.get("test"), "ic": f.get("ic_mean"), "auc": f.get("auc"), "top": f.get("top_decile_R")} for f in mt.get("folds", [])],
                  "importance": [{"label": i.get("label") or i.get("feature"), "gain": i.get("gain") or i.get("importance")} for i in (v.get("importance") or [])[:12]]}
    thr = st.get("throughput") or {}
    return out, {"engine": st.get("engine"), "features": st.get("n_features"), "values": thr.get("values"), "seconds": thr.get("seconds"),
                 "perSec": thr.get("values_per_sec"), "rawBars": thr.get("raw_bars"), "panelRows": thr.get("panel_rows"),
                 "predictedAt": st.get("last_prediction_date")}



def _oos_out(oos: dict) -> dict:
    return {"ic": oos.get("ic_mean"), "icT": oos.get("ic_t"), "icPos": oos.get("ic_pos_share"), "auc": oos.get("auc"),
            "top": oos.get("top_decile_R"), "bottom": oos.get("bottom_decile_R"), "ls": oos.get("long_short"),
            "hit": oos.get("top_decile_hit"), "base": oos.get("base_rate"), "all": oos.get("avg_R_all"),
            "deciles": [{"decile": d["decile"], "avg": d.get("avg_R"), "hit": d.get("hit")} for d in oos.get("deciles", [])]}


def model4_out() -> dict:
    """Μοντέλο v4: μετρήσεις δίπλα-δίπλα με το v3 στις ΙΔΙΕΣ περιόδους ελέγχου."""
    try:
        from .ml import v4 as ml4
        st = ml4.status()
    except Exception:  # noqa: BLE001
        return {}
    out = {}
    for h, v in (st.get("models") or {}).items():
        mt, base, cmp_ = v.get("metrics") or {}, v.get("baseline") or {}, v.get("compare") or {}
        out[h] = {"label": v.get("label"), "kind": v.get("kind"), "validated": v.get("validated"), "active": v.get("active"),
                  "better": cmp_.get("better"), "notes": cmp_.get("notes", []), "createdAt": v.get("created_at"),
                  "variant": cmp_.get("variant"), "variants": cmp_.get("variants"),
                  "nTrain": v.get("n_train"), "dataEnd": v.get("data_end"), "gate": mt.get("gate", []),
                  "engine": mt.get("engine"), "seconds": mt.get("train_seconds"), "rows": mt.get("panel_rows"),
                  "v4": _oos_out(mt.get("oos") or {}), "v3": _oos_out(base.get("oos") or {}), "v3gate": base.get("gate", []),
                  "folds": [{"test": f.get("test"), "ic": f.get("ic_mean"), "auc": f.get("auc"), "top": f.get("top_decile_R"),
                             "v3": f.get("v3")} for f in mt.get("folds", [])],
                  "importance": [{"label": i.get("label"), "gain": i.get("importance"), "new": i.get("new")}
                                 for i in (v.get("importance") or [])[:14]]}
    return {"version": st.get("version"), "features": st.get("n_features"), "newFeatures": st.get("n_new_features"),
            "trainedAt": st.get("trained_at"), "predictedAt": st.get("last_prediction_date"), "models": out,
            "progress": {k: st.get("progress", {}).get(k) for k in ("running", "step", "pct", "error")}}


def _preds4() -> dict:
    try:
        rows = db.q("SELECT ticker, horizon, rank_pct FROM ml4_predictions WHERE horizon IN ('rank5','rank21') AND "
                    "date=(SELECT MAX(date) FROM ml4_predictions)")
    except Exception:  # noqa: BLE001
        return {}
    out: dict = {}
    for x in rows:
        out.setdefault(x["ticker"], {})[x["horizon"]] = x["rank_pct"]
    return out


def snapshot(cx: Ctx | None = None, n_shards: int | None = None) -> dict:
    from .ai import assistant
    from .data import secdata
    from .engine import scanner, signals
    cx = cx or Ctx()
    ctx, res, by_t, nm, alt = cx.ctx, cx.res, cx.by_t, cx.nm, cx.alt
    sigs = signals.list_signals("active")
    sigs.sort(key=signals._rank_key, reverse=True)

    def spark(sym, n=40):
        rows_ = db.q("SELECT close FROM prices_daily WHERE ticker=? ORDER BY date DESC LIMIT ?", (sym, n))
        return [r(x["close"]) for x in reversed(rows_)]

    idx = {}
    for sym in ("SPY", "QQQ", "DIA", "IWM", "^VIX"):
        sp = spark(sym, 41)
        if len(sp) >= 2:
            idx[sym] = {"p": sp[-1], "ch": r((sp[-1] / sp[-2] - 1) * 100, 2) if sp[-2] else None, "sp": sp[-40:]}
    rows = []
    p4 = _preds4()
    for x in res:
        rows.append({"t": x["ticker"], "n": nm(x["ticker"], x.get("name")), "sec": x.get("sector") or (alt.get(x["ticker"]) or {}).get("sector"),
                     "p": r(x.get("price")), "ch": r(x.get("change_pct"), 2),
                     "s": x.get("score"), "b": x.get("bias"), "ml": x.get("ml"), "r5": r(x.get("rank5"), 3), "r21": r(x.get("rank21"), 3),
                     "mv": x.get("ml_val") or {}, "rv": x.get("rvol"), "m1": x.get("ret21"), "m3": x.get("ret63"), "atr": x.get("atr_pct"),
                     "rsi": x.get("rsi"), "dv": r(x.get("dollar_vol"), 0), "mc": r(x.get("market_cap"), 0), "pe": x.get("forward_pe"),
                     "cats": x.get("categories", []), "set": [s for s in x.get("setups", [])], "srank": x.get("sector_rank"),
                     "sn": x.get("sector_n"), "sp": [r(v, 3) for v in (x.get("spark") or [])[-30:]],
                     **({"q5": r(p4[x["ticker"]].get("rank5"), 3), "q21": r(p4[x["ticker"]].get("rank21"), 3)} if x["ticker"] in p4 else {})})
    opp = []
    for s in sigs:
        x = by_t.get(s["ticker"]) or {}
        el, eh = s["entry_low"], s["entry_high"]
        opp.append({"ticker": s["ticker"], "name": nm(s["ticker"], x.get("name")), "sector": x.get("sector"), "horizon": s["horizon"], "bias": s["bias"],
                    "setup": s.get("setup"), "price": r(s["price"]), "cur": r(x.get("price")), "chg": r(x.get("change_pct"), 2),
                    "entryLow": r(el), "entryHigh": r(eh), "entry": r((el + eh) / 2),
                    "stop": r(s["stop"]), "tp1": r(s["tp1"]), "tp2": r(s["tp2"]), "tp3": r(s["tp3"]), "rr": s.get("rr"),
                    "stopPct": r(abs(1 - s["stop"] / ((el + eh) / 2)) * 100, 2), "holding": s.get("holding"),
                    "score": s.get("score"), "confidence": s.get("confidence"), "status": s["status"], "created": s["created_at"],
                    "rank": r(s.get("rank_pct"), 3), "mlP": r(s.get("ml_p"), 3), "mlR": r(s.get("ml_exp_r"), 3),
                    "conflicts": s.get("conflicts", []), "risks": s.get("risks", []), "catalysts": s.get("catalysts", []),
                    "history": s.get("history", [])[-6:], "spark": [r(v, 3) for v in (x.get("spark") or [])[-30:]]})
    hist = [{"ticker": s["ticker"], "horizon": s["horizon"], "setup": s.get("setup"), "date": s["created_at"][:10],
             "status": s["status"], "outcome": s.get("outcome"), "ret": r(s.get("outcome_return"), 2), "closed": (s.get("closed_at") or "")[:10],
             "price": r(s["price"]), "stop": r(s["stop"]), "tp2": r(s["tp2"])} for s in cx.signals[:400]]
    news = db.q("SELECT ticker,title,source,published_at,category,sentiment,url FROM news WHERE is_primary=1 "
                "ORDER BY published_at DESC LIMIT 40")
    dtr = db.kv_get("daytrade") or {}

    def day_item(c):
        x = by_t.get(c["ticker"]) or {}
        return {**{k: (r(v) if isinstance(v, float) else v) for k, v in c.items()}, "name": nm(c["ticker"], c.get("name")),
                "entryLow": r(c.get("entry_low")), "entryHigh": r(c.get("entry_high")), "stopPct": c.get("stop_pct"),
                "sector": c.get("sector") or (alt.get(c["ticker"]) or {}).get("sector"), "spark": [r(v, 3) for v in (x.get("spark") or [])[-30:]]}
    model, stats = model_out()
    first = (db.q1("SELECT MIN(date) d FROM prices_daily WHERE ticker='SPY'") or {}).get("d")
    last = (db.q1("SELECT MAX(date) d FROM prices_daily WHERE ticker='SPY'") or {}).get("d")
    run = db.q1("SELECT * FROM scan_runs WHERE status='ok' ORDER BY started_at DESC LIMIT 1") or {}
    return {
        "v": 2, "builtAt": datetime.now(timezone.utc).isoformat(timespec="seconds"), "asOf": last, "firstDate": first,
        "universe": ctx.get("universe_n"), "analyzed": len(rows),
        "historyYears": settings.history_years, "histTickers": (db.q1("SELECT COUNT(DISTINCT ticker) n FROM prices_daily") or {}).get("n"),
        "market": {**(ctx.get("market") or {}), "simple": assistant.simple_market().get("lines")},
        "idx": idx,
        "sectors": [{"sector": s.get("sector"), "etf": s.get("etf"), "rel21": r(s.get("rel21"), 2), "ret21": r(s.get("ret21"), 2),
                     "ret1": r(s.get("ret1"), 2), "score": s.get("score")} for s in (ctx.get("sectors") or [])],
        "signals": opp, "rows": rows, "cats": scanner.CATEGORY_LABELS, "model": model, "stats": stats, "model4": model4_out(),
        "day": {"long": [day_item(c) for c in dtr.get("long", [])], "short": [day_item(c) for c in dtr.get("short", [])],
                "n": dtr.get("n_candidates"), "rules": dtr.get("rules", []), "note": dtr.get("note"), "at": dtr.get("at")},
        "sigStats": signals.stats(), "hist": hist,
        "news": [{"t": n["ticker"], "title": n["title"], "source": n["source"], "at": n["published_at"], "cat": n["category"],
                  "sent": r(n["sentiment"], 2), "url": n["url"]} for n in news],
        "sec": {k: v for k, v in (secdata.status() or {}).items() if isinstance(v, (int, float, str, bool, type(None)))},
        "run": {"id": run.get("run_id"), "finished": run.get("finished_at"), "notes": (run.get("notes") or "")[:1500]},
        "shards": n_shards if n_shards is not None else len(rows),
    }


def live_quotes() -> dict:
    """Τρέχουσες τιμές από τη βάση του υπολογιστή (ίδια μορφή με το data/quotes.json του κινητού)."""
    from .data import service
    from .data.session import NY
    qs = service.all_quotes()
    day = datetime.now(NY).strftime("%Y-%m-%d")
    q = {t: [r(v["price"]), r(v.get("change_pct"), 2)] for t, v in qs.items()
         if v.get("price") is not None and (v.get("as_of") or "")[:10] == day}
    return {"at": db.kv_get("quotes_updated_at") or db.now_iso(), "day": day, "q": q}
