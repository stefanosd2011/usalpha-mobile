"""Ειδήσεις από RSS (δωρεάν, χωρίς key): Yahoo Finance RSS ανά μετοχή + Google News.
Εφεδρεία/συμπλήρωμα του yfinance — αν μία πηγή σταματήσει, οι ειδήσεις συνεχίζουν."""
from __future__ import annotations

import logging
import re
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from urllib.parse import quote_plus

import httpx

from .net import RateLimiter, call_with_retry

log = logging.getLogger("usalpha.rss")
_limiter = RateLimiter(rate=40, per=60)
UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130 Safari/537.36"}
_tag = re.compile(r"<[^>]+>")
_junk = re.compile(r"(stock price|stock quote|news, quote|quote & history|price & news|historical prices|price today|"
                   r"stock forecast|price target & analyst)", re.I)


def _get(url: str, name: str) -> str:
    def _do():
        r = httpx.get(url, headers=UA, timeout=15, follow_redirects=True)
        r.raise_for_status()
        return r.text
    return call_with_retry(name, url.split("?")[0][-60:], _do, retries=2, limiter=_limiter)


def _parse(xml: str, ticker: str | None, default_source: str, max_age_days: int) -> list[dict]:
    out = []
    try:
        root = ET.fromstring(xml)
    except ET.ParseError:
        return out
    cutoff = datetime.now(timezone.utc) - timedelta(days=max_age_days)
    for it in root.iter("item"):
        title = (it.findtext("title") or "").strip()
        if not title:
            continue
        src_el = it.find("source")
        source = (src_el.text or "").strip() if src_el is not None and src_el.text else default_source
        if default_source == "Google News" and " - " in title:
            title, _, s2 = title.rpartition(" - ")
            source = source if source != default_source else s2
        if _junk.search(title):
            continue  # σελίδες τιμών/quotes, όχι ειδήσεις
        pub = it.findtext("pubDate")
        try:
            dt = parsedate_to_datetime(pub) if pub else None
            if dt and dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
        except (TypeError, ValueError):
            dt = None
        if dt and dt < cutoff:
            continue
        out.append({"title": title[:400], "summary": _tag.sub("", it.findtext("description") or "")[:800],
                    "url": it.findtext("link"), "source": source or default_source,
                    "published_at": (dt or datetime.now(timezone.utc)).isoformat(), "ticker": ticker})
    return out


def yahoo_rss(ticker: str, max_age_days: int = 7) -> list[dict]:
    try:
        xml = _get(f"https://feeds.finance.yahoo.com/rss/2.0/headline?s={quote_plus(ticker)}&region=US&lang=en-US",
                   "yahoo_rss")
    except Exception as e:  # noqa: BLE001
        log.debug("yahoo rss %s: %s", ticker, e)
        return []
    return _parse(xml, ticker, "Yahoo Finance", max_age_days)


def google_news(ticker: str, name: str | None = None, max_age_days: int = 5) -> list[dict]:
    q = f'"{ticker}" stock' if not name else f'"{ticker}" OR "{name.split(",")[0].split(" Inc")[0]}" stock'
    try:
        xml = _get(f"https://news.google.com/rss/search?q={quote_plus(q)}+when:{max_age_days}d&hl=en-US&gl=US&ceid=US:en",
                   "google_news")
    except Exception as e:  # noqa: BLE001
        log.debug("google news %s: %s", ticker, e)
        return []
    return _parse(xml, ticker, "Google News", max_age_days)[:15]


def market_news(max_age_days: int = 2) -> list[dict]:
    items = []
    for q in ("stock market today", "Federal Reserve rates", "S&P 500 Nasdaq"):
        try:
            xml = _get(f"https://news.google.com/rss/search?q={quote_plus(q)}+when:{max_age_days}d&hl=en-US&gl=US&ceid=US:en",
                       "google_news")
            items += _parse(xml, None, "Google News", max_age_days)[:10]
        except Exception:  # noqa: BLE001
            pass
    return items
