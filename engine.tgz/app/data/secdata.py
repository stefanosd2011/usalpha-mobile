"""SEC EDGAR — επίσημα, δωρεάν δεδομένα για ΟΛΗ την αγορά:
1. Submissions ανά εταιρεία: κλάδος (SIC), ημερομηνίες ανακοίνωσης αποτελεσμάτων (8-K item 2.02)
   και ημερομηνίες κατάθεσης 10-Q/10-K (για να ξέρουμε ΠΟΤΕ έγινε γνωστό κάθε νούμερο).
2. XBRL frames: έσοδα, κέρδη, περιθώρια, ενεργητικό, ίδια κεφάλαια, μετοχές κ.λπ. για όλες τις εταιρείες
   ανά τρίμηνο — λίγα αιτήματα για όλη την αγορά.
Κάθε οικονομικό στοιχείο αποθηκεύεται με την ημερομηνία που έγινε δημόσιο (filed). Το μοντέλο το «βλέπει»
μόνο από εκείνη τη μέρα και μετά — καμία διαρροή μελλοντικής πληροφορίας."""
from __future__ import annotations

import json
import logging
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import date, datetime, timedelta, timezone

import httpx
import numpy as np
import pandas as pd

from .. import db
from ..config import settings
from .net import RateLimiter, call_with_retry
from .sec import cik_map

log = logging.getLogger("usalpha.secdata")
_limiter = RateLimiter(rate=8, per=1)  # κανόνας SEC: έως 10 αιτήματα/δευτ.
_progress = {"running": False, "step": "", "done": 0, "total": 0}

SCHEMA = """
CREATE TABLE IF NOT EXISTS sec_meta (
    ticker TEXT PRIMARY KEY, cik INTEGER, sic INTEGER, sic_desc TEXT, sector TEXT, name TEXT, updated_at TEXT
);
CREATE TABLE IF NOT EXISTS earnings_events (
    ticker TEXT NOT NULL, date TEXT NOT NULL, accn TEXT, PRIMARY KEY (ticker, date)
);
CREATE TABLE IF NOT EXISTS sec_filed (
    accn TEXT PRIMARY KEY, ticker TEXT, form TEXT, filed TEXT, report_date TEXT
);
CREATE TABLE IF NOT EXISTS fund_facts (
    ticker TEXT NOT NULL, concept TEXT NOT NULL, period_end TEXT NOT NULL, kind TEXT NOT NULL,
    val REAL, filed TEXT, accn TEXT, PRIMARY KEY (ticker, concept, period_end, kind)
);
CREATE INDEX IF NOT EXISTS ix_fund_ticker ON fund_facts(ticker);
CREATE INDEX IF NOT EXISTS ix_earn_ticker ON earnings_events(ticker);
"""

# concept -> λίστα XBRL tags κατά προτεραιότητα, (taxonomy, unit, kind) kind: Q=τρίμηνο, I=στιγμή, A=έτος
CONCEPTS = {
    "revenue": (["Revenues", "RevenueFromContractWithCustomerExcludingAssessedTax", "SalesRevenueNet",
                 "RevenueFromContractWithCustomerIncludingAssessedTax"], "us-gaap", "USD", ("Q", "A")),
    "net_income": (["NetIncomeLoss"], "us-gaap", "USD", ("Q", "A")),
    "op_income": (["OperatingIncomeLoss"], "us-gaap", "USD", ("Q", "A")),
    "gross_profit": (["GrossProfit"], "us-gaap", "USD", ("Q", "A")),
    "eps": (["EarningsPerShareDiluted", "EarningsPerShareBasic"], "us-gaap", "USD-per-shares", ("Q", "A")),
    "assets": (["Assets"], "us-gaap", "USD", ("I",)),
    "equity": (["StockholdersEquity"], "us-gaap", "USD", ("I",)),
    "cash": (["CashAndCashEquivalentsAtCarryingValue"], "us-gaap", "USD", ("I",)),
    "lt_debt": (["LongTermDebtNoncurrent", "LongTermDebt"], "us-gaap", "USD", ("I",)),
    "shares": (["EntityCommonStockSharesOutstanding"], "dei", "shares", ("I",)),
    "cfo": (["NetCashProvidedByUsedInOperatingActivities"], "us-gaap", "USD", ("A",)),
}
FLOW = ("revenue", "net_income", "op_income", "gross_profit", "eps")
INSTANT = ("assets", "equity", "cash", "lt_debt", "shares")
LAG_DAYS = {"Q": 50, "I": 50, "A": 80}  # αν δεν βρεθεί η ακριβής ημερομηνία κατάθεσης: συντηρητική καθυστέρηση


def progress() -> dict:
    return dict(_progress)


def init() -> None:
    with db.tx() as c:
        c.executescript(SCHEMA)


def _headers() -> dict:
    return {"User-Agent": settings.sec_user_agent, "Accept-Encoding": "gzip, deflate"}


def _get_json(url: str, name: str):
    def _do():
        r = httpx.get(url, headers=_headers(), timeout=40)
        if r.status_code == 404:
            return None
        r.raise_for_status()
        return r.json()
    return call_with_retry("sec", name, _do, limiter=_limiter, retries=3, base_delay=2)


# ------------------------------------------------------------------ SIC -> κλάδος
def sic_to_sector(sic: int | None) -> str | None:
    if not sic:
        return None
    s = int(sic)
    if 100 <= s < 1000:
        return "Consumer Defensive"
    if 1000 <= s < 1100 or 1400 <= s < 1500:
        return "Basic Materials"
    if 1200 <= s < 1400:
        return "Energy"
    if 1500 <= s < 1800:
        return "Industrials"
    if 2000 <= s < 2200:
        return "Consumer Defensive"
    if 2200 <= s < 2400 or 2500 <= s < 2600:
        return "Consumer Cyclical"
    if 2400 <= s < 2500 or 2600 <= s < 2700:
        return "Basic Materials"
    if 2700 <= s < 2800:
        return "Communication Services"
    if 2830 <= s < 2840:
        return "Healthcare"
    if 2840 <= s < 2845:
        return "Consumer Defensive"
    if 2800 <= s < 2900:
        return "Basic Materials"
    if 2900 <= s < 3000:
        return "Energy"
    if 3100 <= s < 3200:
        return "Consumer Cyclical"
    if 3000 <= s < 3400:
        return "Basic Materials"
    if 3400 <= s < 3500:
        return "Industrials"
    if 3570 <= s < 3580 or 3600 <= s < 3700:
        return "Technology"
    if 3500 <= s < 3600:
        return "Industrials"
    if 3710 <= s < 3717 or 3750 <= s < 3752:
        return "Consumer Cyclical"
    if 3700 <= s < 3800:
        return "Industrials"
    if 3840 <= s < 3852:
        return "Healthcare"
    if 3800 <= s < 3900:
        return "Technology"
    if 3900 <= s < 4000:
        return "Consumer Cyclical"
    if 4000 <= s < 4800:
        return "Industrials"
    if 4800 <= s < 4900:
        return "Communication Services"
    if 4900 <= s < 5000:
        return "Utilities"
    if s == 5122 or s == 5912:
        return "Healthcare"
    if 5000 <= s < 5200:
        return "Industrials"
    if 5400 <= s < 5500:
        return "Consumer Defensive"
    if 5200 <= s < 6000:
        return "Consumer Cyclical"
    if s == 6798 or 6500 <= s < 6600:
        return "Real Estate"
    if 6000 <= s < 6800:
        return "Financial Services"
    if 7370 <= s < 7380:
        return "Technology"
    if 7800 <= s < 7990:
        return "Communication Services"
    if 7000 <= s < 7300 or 7990 <= s < 8000:
        return "Consumer Cyclical"
    if s == 8731 or 8000 <= s < 8100:
        return "Healthcare"
    return "Industrials"


# ------------------------------------------------------------------ 1. submissions
def parse_submissions(ticker: str, d: dict) -> tuple[dict, list[tuple], list[tuple]]:
    """Επιστρέφει (meta, earnings_rows, filed_rows)."""
    sic = d.get("sic")
    try:
        sic = int(sic) if sic not in (None, "") else None
    except (TypeError, ValueError):
        sic = None
    meta = {"ticker": ticker, "cik": int(d.get("cik") or 0), "sic": sic, "sic_desc": d.get("sicDescription"),
            "sector": sic_to_sector(sic), "name": d.get("name")}
    rec = (d.get("filings") or {}).get("recent") or {}
    forms = rec.get("form") or []
    earn, filed = [], []
    for i, form in enumerate(forms):
        accn = rec["accessionNumber"][i]
        fdate = rec["filingDate"][i]
        items = (rec.get("items") or [""] * len(forms))[i] or ""
        if form in ("8-K", "8-K/A") and "2.02" in items:
            earn.append((ticker, fdate, accn))
        if form in ("10-Q", "10-K", "10-Q/A", "10-K/A", "20-F", "40-F", "6-K"):
            filed.append((accn, ticker, form, fdate, (rec.get("reportDate") or [""] * len(forms))[i] or None))
    return meta, earn, filed


def sync_submissions(tickers: list[str], max_age_days: int = 7, workers: int = 4) -> dict:
    init()
    cmap = cik_map()
    fresh = {r["ticker"] for r in db.q("SELECT ticker FROM sec_meta WHERE updated_at>=?",
                                       ((datetime.now(timezone.utc) - timedelta(days=max_age_days)).isoformat(),))}
    todo = [t for t in tickers if t not in fresh and cmap.get(t.replace(".", "-"))]
    _progress.update(running=True, step="SEC: κλάδοι & ημερομηνίες αποτελεσμάτων", done=0, total=len(todo))
    ok = 0

    def one(t):
        cik = cmap.get(t.replace(".", "-"))
        try:
            d = _get_json(f"https://data.sec.gov/submissions/CIK{cik:010d}.json", "submissions")
        except Exception as e:  # noqa: BLE001
            log.debug("submissions %s: %s", t, e)
            return None
        return t, d

    try:
        with ThreadPoolExecutor(max_workers=workers) as ex:
            for res in ex.map(one, todo):
                _progress["done"] += 1
                if not res or not res[1]:
                    continue
                t, d = res
                meta, earn, filed = parse_submissions(t, d)
                db.execute("INSERT INTO sec_meta(ticker,cik,sic,sic_desc,sector,name,updated_at) VALUES(?,?,?,?,?,?,?) "
                           "ON CONFLICT(ticker) DO UPDATE SET cik=excluded.cik, sic=excluded.sic, sic_desc=excluded.sic_desc, "
                           "sector=excluded.sector, name=excluded.name, updated_at=excluded.updated_at",
                           (t, meta["cik"], meta["sic"], meta["sic_desc"], meta["sector"], meta["name"], db.now_iso()))
                db.executemany("INSERT OR IGNORE INTO earnings_events(ticker,date,accn) VALUES(?,?,?)", earn)
                db.executemany("INSERT OR IGNORE INTO sec_filed(accn,ticker,form,filed,report_date) VALUES(?,?,?,?,?)", filed)
                ok += 1
    finally:
        _progress.update(running=False, step="SEC submissions: ολοκληρώθηκε")
    db.kv_set("sec_submissions_at", db.now_iso())
    return {"updated": ok, "todo": len(todo)}


# ------------------------------------------------------------------ 2. XBRL frames
def _periods(start_year: int) -> list[tuple[str, str]]:
    """[(frame_code, kind)] από start_year μέχρι το τελευταίο ολοκληρωμένο τρίμηνο."""
    today = date.today()
    out = []
    for y in range(start_year, today.year + 1):
        for q in range(1, 5):
            q_end = date(y, 3 * q, 28)
            if q_end + timedelta(days=20) > today:
                continue
            out.append((f"CY{y}Q{q}", "Q"))
            out.append((f"CY{y}Q{q}I", "I"))
        if date(y, 12, 31) + timedelta(days=75) <= today:
            out.append((f"CY{y}", "A"))
    return out


def parse_frame(d: dict, concept: str, kind: str, ciks: dict[int, str], filed_map: dict[str, str]) -> list[tuple]:
    rows = []
    for e in d.get("data") or []:
        t = ciks.get(int(e.get("cik", 0)))
        if not t or e.get("val") is None:
            continue
        end = e.get("end")
        accn = e.get("accn")
        filed = filed_map.get(accn)
        if not filed and end:
            filed = (pd.Timestamp(end) + pd.Timedelta(days=LAG_DAYS[kind])).strftime("%Y-%m-%d")
        rows.append((t, concept, end, kind, float(e["val"]), filed, accn))
    return rows


def sync_frames(start_year: int | None = None) -> dict:
    """Κατεβάζει τα frames που λείπουν (και ξανά τα 2 πιο πρόσφατα τρίμηνα, γιατί καταθέτουν κι άλλοι)."""
    init()
    start_year = start_year or (date.today().year - settings.history_years)
    universe = {r["ticker"] for r in db.q("SELECT ticker FROM universe WHERE active=1")}
    ciks = {cik: t for t, cik in cik_map().items() if t in universe or t.replace("-", ".") in universe}
    filed_map = {r["accn"]: r["filed"] for r in db.q("SELECT accn, filed FROM sec_filed")}
    done_set = set(db.kv_get("sec_frames_done", []) or [])
    periods = _periods(start_year)
    recent = {p for p, _ in periods[-6:]}
    jobs = []
    for concept, (tags, tax, unit, kinds) in CONCEPTS.items():
        for code, kind in periods:
            if kind not in kinds:
                continue
            key = f"{concept}:{code}"
            if key in done_set and code not in recent:
                continue
            jobs.append((concept, tags, tax, unit, code, kind, key))
    _progress.update(running=True, step="SEC: οικονομικά στοιχεία όλης της αγοράς", done=0, total=len(jobs))
    n_rows = 0
    try:
        for concept, tags, tax, unit, code, kind, key in jobs:
            _progress["done"] += 1
            got: dict[str, tuple] = {}
            for tag in reversed(tags):  # το πρώτο tag της λίστας έχει προτεραιότητα (γράφεται τελευταίο)
                try:
                    d = _get_json(f"https://data.sec.gov/api/xbrl/frames/{tax}/{tag}/{unit}/{code}.json", f"frames:{tag}")
                except Exception as e:  # noqa: BLE001
                    log.debug("frame %s %s: %s", tag, code, e)
                    continue
                if not d:
                    continue
                for r in parse_frame(d, concept, kind, ciks, filed_map):
                    got[r[0]] = r
            if got:
                db.executemany("INSERT INTO fund_facts(ticker,concept,period_end,kind,val,filed,accn) VALUES(?,?,?,?,?,?,?) "
                               "ON CONFLICT(ticker,concept,period_end,kind) DO UPDATE SET val=excluded.val, "
                               "filed=excluded.filed, accn=excluded.accn", list(got.values()))
                n_rows += len(got)
            done_set.add(key)
            if _progress["done"] % 20 == 0:
                db.kv_set("sec_frames_done", sorted(done_set))
    finally:
        db.kv_set("sec_frames_done", sorted(done_set))
        _progress.update(running=False, step="SEC frames: ολοκληρώθηκε")
    db.kv_set("sec_frames_at", db.now_iso())
    return {"requests": len(jobs), "rows": n_rows}


def sync_all(tickers: list[str]) -> dict:
    a = sync_submissions(tickers)
    b = sync_frames()
    return {"submissions": a, "frames": b}


# ------------------------------------------------------------------ point-in-time πίνακες για το μοντέλο
def _dedupe_latest(pe: np.ndarray, fl: np.ndarray, v: np.ndarray, asof: np.int64):
    """Στοιχεία γνωστά έως asof, ένα ανά period_end (το πιο πρόσφατα κατατεθειμένο). Είσοδοι ταξινομημένοι (pe, fl)."""
    m = fl <= asof
    pe, v = pe[m], v[m]
    if len(pe) == 0:
        return pe, v
    keep = np.r_[pe[1:] != pe[:-1], True]
    return pe[keep], v[keep]


DAY = np.int64(86_400_000_000_000)


def _add_synthetic_q4(q: pd.DataFrame, a: pd.DataFrame) -> pd.DataFrame:
    """Q4 = ετήσιο − (Q1+Q2+Q3), όταν η εταιρεία δεν δηλώνει χωριστά το 4ο τρίμηνο."""
    if a.empty:
        return q
    extra = []
    qe = q["period_end"].to_numpy()
    for _, r in a.iterrows():
        ea = r["period_end"]
        if len(qe) and (np.abs(qe - np.datetime64(ea)) <= np.timedelta64(20, "D")).any():
            continue
        win = q[(q["period_end"] > ea - pd.Timedelta(days=300)) & (q["period_end"] <= ea - pd.Timedelta(days=60))]
        win = win.drop_duplicates("period_end", keep="last")
        if len(win) == 3:
            extra.append({"period_end": ea, "val": r["val"] - win["val"].sum(),
                          "filed": max(r["filed"], win["filed"].max())})
    if extra:
        q = pd.concat([q, pd.DataFrame(extra)], ignore_index=True)
    return q


def fundamentals_pit() -> pd.DataFrame:
    """Ένα στιγμιότυπο ανά (ticker, ημερομηνία δημοσιοποίησης): TTM έσοδα/κέρδη, ρυθμοί ανάπτυξης,
    τελευταία στοιχεία ισολογισμού, μετοχές πριν 1 έτος. Μόνο στοιχεία με filed <= εκείνη την ημερομηνία."""
    init()
    df = pd.read_sql_query("SELECT ticker, concept, period_end, kind, val, filed FROM fund_facts", db.conn())
    if df.empty:
        return pd.DataFrame()
    df["period_end"] = pd.to_datetime(df["period_end"], errors="coerce")
    df["filed"] = pd.to_datetime(df["filed"], errors="coerce")
    df = df.dropna(subset=["period_end", "filed", "val"])
    out = []
    for t, g in df.groupby("ticker", sort=False):
        arrs = {}
        for c in FLOW:
            q = g[(g["concept"] == c) & (g["kind"] == "Q")][["period_end", "val", "filed"]]
            a = g[(g["concept"] == c) & (g["kind"] == "A")][["period_end", "val", "filed"]]
            q = _add_synthetic_q4(q, a).sort_values(["period_end", "filed"])
            arrs[c] = (q["period_end"].to_numpy("datetime64[ns]").astype(np.int64),
                       q["filed"].to_numpy("datetime64[ns]").astype(np.int64), q["val"].to_numpy(float))
        for c in INSTANT + ("cfo",):
            x = g[g["concept"] == c].sort_values(["period_end", "filed"])
            arrs[c] = (x["period_end"].to_numpy("datetime64[ns]").astype(np.int64),
                       x["filed"].to_numpy("datetime64[ns]").astype(np.int64), x["val"].to_numpy(float))
        events = np.unique(np.concatenate([v[1] for v in arrs.values()]))
        for ev in events:
            s = {"ticker": t, "avail": ev}
            for c in FLOW:
                pe, v = _dedupe_latest(*arrs[c], ev)
                n = len(v)
                if n >= 4 and pe[-1] - pe[-4] < 300 * DAY:
                    s[f"{c}_ttm"] = v[-4:].sum()
                    if n >= 8 and pe[-5] - pe[-8] < 300 * DAY and pe[-4] - pe[-5] < 120 * DAY:
                        s[f"{c}_ttm_prev"] = v[-8:-4].sum()
                if n >= 5 and v[-5] > 0 and pe[-1] - pe[-5] < 400 * DAY:
                    s[f"{c}_q_yoy"] = v[-1] / v[-5] - 1
                if n >= 6 and v[-6] > 0 and pe[-2] - pe[-6] < 400 * DAY:
                    s[f"{c}_q_yoy_prev"] = v[-2] / v[-6] - 1
            for c in INSTANT:
                pe, v = _dedupe_latest(*arrs[c], ev)
                if len(v):
                    s[c] = v[-1]
                    old = v[pe <= pe[-1] - 330 * DAY]
                    if len(old):
                        s[f"{c}_1y"] = old[-1]
            pe, v = _dedupe_latest(*arrs["cfo"], ev)
            if len(v):
                s["cfo_annual"] = v[-1]
            out.append(s)
    P = pd.DataFrame(out)
    if P.empty:
        return P
    P["avail"] = pd.to_datetime(P["avail"])
    return P.sort_values(["ticker", "avail"]).reset_index(drop=True)


def fundamental_features(pit: pd.DataFrame) -> pd.DataFrame:
    """Από τα στιγμιότυπα -> features (χωρίς τιμή μετοχής· οι αποτιμήσεις υπολογίζονται στο panel)."""
    if pit is None or pit.empty:
        return pd.DataFrame()
    f = pd.DataFrame({"ticker": pit["ticker"], "avail": pit["avail"]})

    def g(c):
        return pit[c] if c in pit else pd.Series(np.nan, index=pit.index)

    def div(a, b):
        b = b.where(b.abs() > 0)
        return a / b

    f["f_rev_growth"] = div(g("revenue_ttm"), g("revenue_ttm_prev")) - 1
    f["f_rev_q_yoy"] = g("revenue_q_yoy")
    f["f_rev_accel"] = g("revenue_q_yoy") - g("revenue_q_yoy_prev")
    f["f_eps_growth"] = div(g("eps_ttm") - g("eps_ttm_prev"), g("eps_ttm_prev").abs())
    f["f_ni_growth"] = div(g("net_income_ttm") - g("net_income_ttm_prev"), g("net_income_ttm_prev").abs())
    f["f_gross_margin"] = div(g("gross_profit_ttm"), g("revenue_ttm"))
    f["f_op_margin"] = div(g("op_income_ttm"), g("revenue_ttm"))
    f["f_net_margin"] = div(g("net_income_ttm"), g("revenue_ttm"))
    f["f_roa"] = div(g("net_income_ttm"), g("assets"))
    f["f_roe"] = div(g("net_income_ttm"), g("equity").where(g("equity") > 0))
    f["f_accruals"] = div(g("net_income_ttm") - g("cfo_annual"), g("assets"))
    f["f_cfo_assets"] = div(g("cfo_annual"), g("assets"))
    f["f_asset_growth"] = div(g("assets"), g("assets_1y")) - 1
    f["f_shares_growth"] = div(g("shares"), g("shares_1y")) - 1
    f["f_leverage"] = div(g("lt_debt"), g("assets"))
    f["f_cash_assets"] = div(g("cash"), g("assets"))
    f["f_loss"] = (g("net_income_ttm") < 0).astype(float).where(g("net_income_ttm").notna())
    # βοηθητικά για αποτιμήσεις (θα διαιρεθούν με την κεφαλαιοποίηση της ημέρας)
    f["_ni_ttm"] = g("net_income_ttm")
    f["_rev_ttm"] = g("revenue_ttm")
    f["_equity"] = g("equity")
    f["_cfo"] = g("cfo_annual")
    f["_shares"] = g("shares")
    for c in f.columns:
        if c not in ("ticker", "avail"):
            f[c] = f[c].replace([np.inf, -np.inf], np.nan).clip(-50, 50).astype(np.float32)
    return f


def earnings_events() -> dict[str, np.ndarray]:
    init()
    rows = db.q("SELECT ticker, date FROM earnings_events ORDER BY ticker, date")
    out: dict[str, list] = {}
    for r in rows:
        out.setdefault(r["ticker"], []).append(r["date"])
    return {t: pd.to_datetime(pd.Series(v)).to_numpy() for t, v in out.items()}


def sector_map() -> dict[str, str]:
    init()
    return {r["ticker"]: r["sector"] for r in db.q("SELECT ticker, sector FROM sec_meta WHERE sector IS NOT NULL")}


def status() -> dict:
    init()
    return {
        "companies": (db.q1("SELECT COUNT(*) n FROM sec_meta") or {}).get("n"),
        "earnings_events": (db.q1("SELECT COUNT(*) n FROM earnings_events") or {}).get("n"),
        "fund_facts": (db.q1("SELECT COUNT(*) n FROM fund_facts") or {}).get("n"),
        "fund_companies": (db.q1("SELECT COUNT(DISTINCT ticker) n FROM fund_facts") or {}).get("n"),
        "submissions_at": db.kv_get("sec_submissions_at"), "frames_at": db.kv_get("sec_frames_at"),
        "progress": progress(),
    }
