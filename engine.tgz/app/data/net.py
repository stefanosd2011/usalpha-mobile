"""Κοινά εργαλεία δικτύου: rate limiting, retries με backoff, TTL cache, καταγραφή κλήσεων."""
from __future__ import annotations

import functools
import logging
import threading
import time
from typing import Any, Callable

from ..db import log_api

log = logging.getLogger("usalpha.net")


class RateLimiter:
    """Token bucket: max `rate` κλήσεις ανά `per` δευτερόλεπτα."""

    def __init__(self, rate: int, per: float = 60.0):
        self.rate, self.per = rate, per
        self.allowance = float(rate)
        self.last = time.monotonic()
        self.lock = threading.Lock()

    def wait(self) -> None:
        while True:
            with self.lock:
                now = time.monotonic()
                self.allowance = min(self.rate, self.allowance + (now - self.last) * self.rate / self.per)
                self.last = now
                if self.allowance >= 1:
                    self.allowance -= 1
                    return
                need = (1 - self.allowance) * self.per / self.rate
            time.sleep(min(need, 5))


class ProviderError(Exception):
    pass


def call_with_retry(provider: str, endpoint: str, fn: Callable[[], Any], retries: int = 3,
                    base_delay: float = 1.5, limiter: RateLimiter | None = None) -> Any:
    last_err: Exception | None = None
    for attempt in range(retries):
        if limiter:
            limiter.wait()
        t0 = time.perf_counter()
        try:
            out = fn()
            log_api(provider, endpoint, True, (time.perf_counter() - t0) * 1000)
            return out
        except Exception as e:  # noqa: BLE001
            last_err = e
            log_api(provider, endpoint, False, (time.perf_counter() - t0) * 1000, repr(e))
            msg = str(e).lower()
            if "401" in msg or "403" in msg or "invalid api key" in msg:
                break
            time.sleep(base_delay * (2 ** attempt))
    raise ProviderError(f"{provider}:{endpoint} απέτυχε: {last_err}")


class TTLCache:
    def __init__(self):
        self._d: dict = {}
        self._lock = threading.Lock()

    def get(self, key):
        with self._lock:
            v = self._d.get(key)
            if not v:
                return None
            exp, val = v
            if exp < time.time():
                self._d.pop(key, None)
                return None
            return val

    def set(self, key, val, ttl: float):
        with self._lock:
            self._d[key] = (time.time() + ttl, val)


_cache = TTLCache()


def cached(ttl: float):
    def deco(fn):
        @functools.wraps(fn)
        def wrap(*a, **kw):
            key = (fn.__qualname__, a, tuple(sorted(kw.items())))
            v = _cache.get(key)
            if v is not None:
                return v
            v = fn(*a, **kw)
            if v is not None:
                _cache.set(key, v, ttl)
            return v
        return wrap
    return deco
