"""Finnhub (προαιρετικό, δωρεάν key στο finnhub.io). Δίνει real-time τιμές ΗΠΑ,
εταιρικές ειδήσεις, ημερολόγιο earnings. Αν δεν υπάρχει key, απλώς δεν χρησιμοποιείται."""
from __future__ import annotations

from datetime import date, datetime, timedelta, timezone

import httpx

from ..config import settings
from .net import RateLimiter, call_with_retry

PROVIDER = "finnhub"
BASE = "https://finnhub.io/api/v1"
_limiter = RateLimiter(rate=55, per=60)  # free tier: 60/min


def enabled() -> bool:
    return settings.has("FINNHUB_API_KEY")


def _get(path: str, params: dict) -> dict | list:
    key = settings.secret("FINNHUB_API_KEY")

    def _do():
        r = httpx.get(f"{BASE}{path}", params={**params, "token": key}, timeout=15)
        r.raise_for_status()
        return r.json()

    return call_with_retry(PROVIDER, path, _do, limiter=_limiter, retries=2)


def quote(ticker: str) -> dict | None:
    if not enabled():
        return None
    d = _get("/quote", {"symbol": ticker})
    if not isinstance(d, dict) or not d.get("c"):
        return None
    ts = d.get("t")
    return {
        "price": d.get("c"), "prev_close": d.get("pc"), "day_high": d.get("h"), "day_low": d.get("l"),
        "as_of": datetime.fromtimestamp(ts, tz=timezone.utc).isoformat() if ts else None,
        "source": PROVIDER,
    }


def company_news(ticker: str, days: int = 5) -> list[dict]:
    if not enabled():
        return []
    to = date.today()
    fr = to - timedelta(days=days)
    items = _get("/company-news", {"symbol": ticker, "from": fr.isoformat(), "to": to.isoformat()})
    out = []
    for it in items if isinstance(items, list) else []:
        if not it.get("headline"):
            continue
        out.append({
            "title": it["headline"], "summary": it.get("summary", ""), "url": it.get("url"),
            "source": it.get("source") or "Finnhub", "ticker": ticker,
            "published_at": datetime.fromtimestamp(it.get("datetime", 0), tz=timezone.utc).isoformat(),
        })
    return out


def market_news() -> list[dict]:
    if not enabled():
        return []
    items = _get("/news", {"category": "general"})
    out = []
    for it in items if isinstance(items, list) else []:
        if not it.get("headline"):
            continue
        out.append({
            "title": it["headline"], "summary": it.get("summary", ""), "url": it.get("url"),
            "source": it.get("source") or "Finnhub", "ticker": None,
            "published_at": datetime.fromtimestamp(it.get("datetime", 0), tz=timezone.utc).isoformat(),
        })
    return out


def earnings_calendar(days: int = 14) -> list[dict]:
    if not enabled():
        return []
    fr = date.today()
    d = _get("/calendar/earnings", {"from": fr.isoformat(), "to": (fr + timedelta(days=days)).isoformat()})
    rows = d.get("earningsCalendar", []) if isinstance(d, dict) else []
    return [{"ticker": r.get("symbol"), "date": r.get("date"), "hour": r.get("hour"),
             "eps_est": r.get("epsEstimate"), "rev_est": r.get("revenueEstimate")} for r in rows]
