"""ΟΛΗ η αμερικανική αγορά. Το σύμπαν χτίζεται από:
  1. Yahoo screener (κύρια πηγή): όλες οι μετοχές NASDAQ / NYSE / AMEX / Cboe με τιμή, κεφαλαιοποίηση
     και μέσο όγκο — σε ~20 αιτήματα.
  2. Nasdaq Trader (επίσημες λίστες όλων των εισηγμένων) + φίλτρο ρευστότητας από 1 μήνα τιμών.
  3. SEC company_tickers_exchange.json.
  4. Ενσωματωμένη λίστα (τελευταία εφεδρεία).
Κρατούνται όσες περνούν το φίλτρο τιμής και ημερήσιου τζίρου (ρυθμίσεις MIN_PRICE,
UNIVERSE_MIN_DOLLAR_VOL). Watchlist και βασική λίστα (AEHR κ.λπ.) μπαίνουν πάντα."""
from __future__ import annotations

import json
import logging
import re
import time
from datetime import datetime, timedelta, timezone

import httpx

from .. import db
from ..config import settings
from . import universe as builtin
from .net import call_with_retry

log = logging.getLogger("usalpha.listings")

YAHOO_EXCHANGES = ["NMS", "NGM", "NCM", "NYQ", "ASE", "BTS"]
EXCLUDE_NAME = re.compile(r"(warrant|\bunits?\b|\brights?\b|preferred|\bnotes?\b|debenture|%|\bbaby bond|"
                          r"trust preferred|depositary shares, each representing)", re.I)
_progress = {"step": "", "count": 0}


def progress() -> dict:
    return dict(_progress)


def yahoo_symbol(sym: str) -> str | None:
    """Μετατροπή συμβόλου χρηματιστηρίου σε σύμβολο Yahoo (BRK.B -> BRK-B). None για μη κοινές μετοχές."""
    s = sym.strip().upper()
    if not s or any(ch in s for ch in "$^+=~ "):
        return None
    if "." in s:
        base, _, suf = s.partition(".")
        if len(suf) == 1 and suf.isalpha():
            return f"{base}-{suf}"
        return None
    return s


# ------------------------------------------------------------------ 1. Yahoo screener
def fetch_yahoo_screener(min_price: float, min_avg_vol: float = 20_000, max_pages: int = 40) -> list[dict]:
    import yfinance as yf
    from yfinance import EquityQuery as Q

    q = Q("and", [Q("eq", ["region", "us"]), Q("is-in", ["exchange", *YAHOO_EXCHANGES]),
                  Q("gte", ["intradayprice", min_price]), Q("gte", ["avgdailyvol3m", min_avg_vol])])
    out, offset, total = [], 0, None
    for _ in range(max_pages):
        res = call_with_retry("yahoo", "screener", lambda: yf.screen(q, offset=offset, size=250,
                                                                     sortField="intradaymarketcap", sortAsc=False),
                              retries=3, base_delay=3)
        quotes = (res or {}).get("quotes") or []
        total = (res or {}).get("total", total)
        if not quotes:
            break
        out.extend(quotes)
        offset += len(quotes)
        _progress.update(step=f"Yahoo screener: {offset}/{total or '?'}", count=offset)
        if total and offset >= total:
            break
        time.sleep(0.6)
    rows = []
    for qd in out:
        sym = yahoo_symbol(str(qd.get("symbol", "")))
        if not sym or qd.get("quoteType", "EQUITY") != "EQUITY":
            continue
        name = qd.get("longName") or qd.get("shortName") or ""
        if EXCLUDE_NAME.search(name):
            continue
        price = qd.get("regularMarketPrice")
        avgv = qd.get("averageDailyVolume3Month") or qd.get("averageDailyVolume10Day")
        rows.append({"ticker": sym, "name": name, "exchange": qd.get("exchange"), "market_cap": qd.get("marketCap"),
                     "price": price, "avg_volume": avgv,
                     "dollar_volume": (price or 0) * (avgv or 0), "source": "yahoo_screener", "snapshot": qd})
    return rows


# ------------------------------------------------------------------ 2. Nasdaq Trader
NASDAQ_URLS = ["https://www.nasdaqtrader.com/dynamic/SymDir/nasdaqlisted.txt",
               "https://www.nasdaqtrader.com/dynamic/SymDir/otherlisted.txt"]


def parse_nasdaqtrader(text: str, other: bool) -> list[dict]:
    lines = [ln for ln in text.splitlines() if ln and not ln.startswith("File Creation Time")]
    if not lines:
        return []
    head = lines[0].split("|")
    idx = {h.strip(): i for i, h in enumerate(head)}
    out = []
    for ln in lines[1:]:
        p = ln.split("|")
        if len(p) < len(head):
            continue
        sym = p[idx["ACT Symbol"]] if other else p[idx["Symbol"]]
        name = p[idx["Security Name"]]
        if p[idx["ETF"]].strip() == "Y" or p[idx["Test Issue"]].strip() == "Y":
            continue
        if EXCLUDE_NAME.search(name):
            continue
        ys = yahoo_symbol(sym)
        if not ys:
            continue
        exch = p[idx["Exchange"]] if other else "NASDAQ"
        if other and exch.strip() not in ("N", "A", "Z", "P"):
            continue
        out.append({"ticker": ys, "name": name.split(" - ")[0][:80], "exchange": exch, "source": "nasdaqtrader"})
    return out


def fetch_nasdaqtrader() -> list[dict]:
    rows = []
    for i, url in enumerate(NASDAQ_URLS):
        def _do(u=url):
            r = httpx.get(u, timeout=30, headers={"User-Agent": "Mozilla/5.0"})
            r.raise_for_status()
            return r.text
        txt = call_with_retry("nasdaqtrader", url.rsplit("/", 1)[-1], _do, retries=2)
        rows += parse_nasdaqtrader(txt, other=(i == 1))
    return rows


# ------------------------------------------------------------------ 3. SEC
def fetch_sec() -> list[dict]:
    def _do():
        r = httpx.get("https://www.sec.gov/files/company_tickers_exchange.json", timeout=30,
                      headers={"User-Agent": settings.sec_user_agent})
        r.raise_for_status()
        return r.json()
    d = call_with_retry("sec", "company_tickers_exchange", _do, retries=2)
    fields = d.get("fields", [])
    fi = {f: i for i, f in enumerate(fields)}
    out = []
    for row in d.get("data", []):
        exch = row[fi["exchange"]]
        if exch not in ("Nasdaq", "NYSE", "CBOE"):
            continue
        ys = yahoo_symbol(str(row[fi["ticker"]]).replace("-", "."))
        name = str(row[fi["name"]])
        if ys and not EXCLUDE_NAME.search(name):
            out.append({"ticker": ys, "name": name[:80], "exchange": exch, "source": "sec"})
    return out


# ------------------------------------------------------------------ liquidity prefilter (για πηγές 2-3)
def prefilter_liquidity(cands: list[dict]) -> list[dict]:
    from . import yahoo
    tick = [c["ticker"] for c in cands]
    by = {c["ticker"]: c for c in cands}
    out = []
    for i in range(0, len(tick), 200):
        part = tick[i:i + 200]
        _progress.update(step=f"Φίλτρο ρευστότητας {i}/{len(tick)}", count=i)
        data = yahoo.history(part, period="1mo", chunk=200, pause=0.5)
        for t, df in data.items():
            df = df.dropna(subset=["Close"])
            if len(df) < 5:
                continue
            price = float(df["Close"].iloc[-1])
            avgv = float(df["Volume"].tail(20).mean())
            c = by[t]
            c.update(price=price, avg_volume=avgv, dollar_volume=price * avgv)
            out.append(c)
    return out


# ------------------------------------------------------------------ build
def build_universe(force: bool = False) -> dict:
    last = db.kv_get("universe_built_at")
    if not force and last:
        age = datetime.now(timezone.utc) - datetime.fromisoformat(last)
        if age < timedelta(days=settings.universe_refresh_days) and universe_tickers():
            return {"status": "fresh", "n": len(universe_tickers())}
    rows, source, errors = [], None, []
    try:
        rows = fetch_yahoo_screener(settings.min_price)
        source = "Yahoo screener"
    except Exception as e:  # noqa: BLE001
        errors.append(f"Yahoo screener: {e}")
        log.warning("yahoo screener failed: %s", e)
    if len(rows) < 500:
        for name, fn in (("Nasdaq Trader", fetch_nasdaqtrader), ("SEC", fetch_sec)):
            try:
                cands = fn()
                if len(cands) > 1000:
                    rows = prefilter_liquidity(cands)
                    source = name
                    break
            except Exception as e:  # noqa: BLE001
                errors.append(f"{name}: {e}")
                log.warning("%s failed: %s", name, e)
    if len(rows) < 200:
        db.kv_set("universe_errors", errors)
        if universe_tickers():
            return {"status": "kept_previous", "errors": errors, "n": len(universe_tickers())}
        rows = [{"ticker": t, "name": None, "exchange": None, "source": "builtin", "dollar_volume": None}
                for t in builtin.base_universe()]
        source = "Ενσωματωμένη λίστα (οι online πηγές απέτυχαν)"

    keep = [r for r in rows if r.get("dollar_volume") is None or
            ((r.get("price") or 0) >= settings.min_price and r["dollar_volume"] >= settings.universe_min_dollar_vol)]
    keep.sort(key=lambda r: -(r.get("dollar_volume") or 0))
    keep = keep[: settings.max_universe]
    now = db.now_iso()
    db.execute("UPDATE universe SET active=0")
    db.executemany(
        "INSERT INTO universe(ticker,name,exchange,market_cap,price,avg_volume,dollar_volume,source,updated_at,active) "
        "VALUES(?,?,?,?,?,?,?,?,?,1) ON CONFLICT(ticker) DO UPDATE SET name=COALESCE(excluded.name,name), "
        "exchange=COALESCE(excluded.exchange,exchange), market_cap=excluded.market_cap, price=excluded.price, "
        "avg_volume=excluded.avg_volume, dollar_volume=excluded.dollar_volume, source=excluded.source, "
        "updated_at=excluded.updated_at, active=1",
        [(r["ticker"], r.get("name"), r.get("exchange"), r.get("market_cap"), r.get("price"), r.get("avg_volume"),
          r.get("dollar_volume"), r.get("source"), now) for r in keep])
    # η βασική λίστα (AEHR κ.λπ.) μπαίνει πάντα — αν λείπει, προστίθεται
    have = set(universe_tickers())
    extra = [t for t in builtin.base_universe() if t not in have]
    db.executemany("INSERT INTO universe(ticker,source,updated_at,active) VALUES(?,?,?,1) "
                   "ON CONFLICT(ticker) DO UPDATE SET active=1", [(t, "core", now) for t in extra])
    snaps = [(r["ticker"], json.dumps(r["snapshot"], default=str), now) for r in keep if r.get("snapshot")]
    if snaps:
        save_snapshots(snaps)
    db.kv_set("universe_built_at", now)
    db.kv_set("universe_source", source)
    db.kv_set("universe_errors", errors)
    _progress.update(step=f"Σύμπαν: {len(keep)} μετοχές ({source})", count=len(keep))
    return {"status": "ok", "source": source, "n": len(keep) + len(extra), "candidates": len(rows), "errors": errors}


def save_snapshots(rows: list[tuple]) -> None:
    db.executemany("INSERT INTO snapshot(ticker,data_json,as_of) VALUES(?,?,?) ON CONFLICT(ticker) DO UPDATE SET "
                   "data_json=excluded.data_json, as_of=excluded.as_of", rows)


def refresh_snapshots() -> int:
    """Ημερήσιο φρεσκάρισμα θεμελιωδών (κεφαλαιοποίηση, P/E, EPS, earnings, 52w) για ΟΛΗ την αγορά σε ~20 κλήσεις."""
    try:
        rows = fetch_yahoo_screener(settings.min_price)
    except Exception as e:  # noqa: BLE001
        log.warning("snapshot refresh failed: %s", e)
        return 0
    now = db.now_iso()
    save_snapshots([(r["ticker"], json.dumps(r["snapshot"], default=str), now) for r in rows])
    db.executemany("UPDATE universe SET price=?, market_cap=?, avg_volume=?, dollar_volume=? WHERE ticker=?",
                   [(r.get("price"), r.get("market_cap"), r.get("avg_volume"), r.get("dollar_volume"), r["ticker"])
                    for r in rows])
    return len(rows)


def universe_tickers(limit: int | None = None) -> list[str]:
    sql = "SELECT ticker FROM universe WHERE active=1 AND fail_count<3 ORDER BY COALESCE(dollar_volume,0) DESC"
    if limit:
        sql += f" LIMIT {int(limit)}"
    return [r["ticker"] for r in db.q(sql)]


def snapshot_info(ticker: str) -> dict:
    """Μετατρέπει το snapshot του screener στη μορφή που περιμένει η θεμελιώδης ανάλυση."""
    r = db.q1("SELECT data_json, as_of FROM snapshot WHERE ticker=?", (ticker,))
    if not r:
        return {}
    s = json.loads(r["data_json"])
    ed = None
    ts = s.get("earningsTimestampStart") or s.get("earningsTimestamp")
    if ts:
        try:
            ed = datetime.fromtimestamp(int(ts), tz=timezone.utc).strftime("%Y-%m-%d")
        except (TypeError, ValueError, OSError):
            ed = None
    m = {
        "longName": s.get("longName") or s.get("shortName"), "marketCap": s.get("marketCap"),
        "sharesOutstanding": s.get("sharesOutstanding"), "trailingPE": s.get("trailingPE"),
        "forwardPE": s.get("forwardPE"), "trailingEps": s.get("epsTrailingTwelveMonths"),
        "forwardEps": s.get("epsForward"), "priceToBook": s.get("priceToBook"),
        "fiftyTwoWeekHigh": s.get("fiftyTwoWeekHigh"), "fiftyTwoWeekLow": s.get("fiftyTwoWeekLow"),
        "averageVolume": s.get("averageDailyVolume3Month"), "bid": s.get("bid"), "ask": s.get("ask"),
        "earnings_date": ed, "exchange": s.get("fullExchangeName") or s.get("exchange"),
        "_snapshot_as_of": r["as_of"], "_source": "snapshot",
    }
    return {k: v for k, v in m.items() if v is not None}


def mark_failed(tickers: list[str]) -> None:
    db.executemany("UPDATE universe SET fail_count=fail_count+1 WHERE ticker=?", [(t,) for t in tickers])


def mark_ok(tickers: list[str]) -> None:
    db.executemany("UPDATE universe SET fail_count=0 WHERE ticker=? AND fail_count>0", [(t,) for t in tickers])
