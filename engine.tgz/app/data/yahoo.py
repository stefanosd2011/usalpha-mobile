"""Yahoo Finance μέσω yfinance (δωρεάν). Ποιότητα: καθυστερημένα / μη εγγυημένα δεδομένα.
Κάθε τιμή που επιστρέφεται συνοδεύεται από πηγή και χρονοσφραγίδα."""
from __future__ import annotations

import logging
import math
import time
from datetime import datetime, timedelta, timezone
from typing import Any

import pandas as pd

from .net import RateLimiter, call_with_retry

log = logging.getLogger("usalpha.yahoo")
_limiter = RateLimiter(rate=90, per=60)
PROVIDER = "yahoo"


def _yf():
    import yfinance as yf  # lazy import
    return yf


def _num(v: Any) -> float | None:
    try:
        f = float(v)
        return None if math.isnan(f) or math.isinf(f) else f
    except (TypeError, ValueError):
        return None


def _split_download(df: pd.DataFrame, tickers: list[str]) -> dict[str, pd.DataFrame]:
    out: dict[str, pd.DataFrame] = {}
    if df is None or df.empty:
        return out
    if isinstance(df.columns, pd.MultiIndex):
        lvl0 = set(df.columns.get_level_values(0))
        for t in tickers:
            if t in lvl0:
                sub = df[t].dropna(how="all")
                if not sub.empty:
                    out[t] = sub
    else:
        out[tickers[0]] = df.dropna(how="all")
    return out


def history(tickers: list[str], start: str | None = None, period: str | None = None,
            interval: str = "1d", prepost: bool = False, chunk: int = 100, pause: float = 1.0,
            progress_cb=None, end: str | None = None) -> dict[str, pd.DataFrame]:
    """Ιστορικές τιμές OHLCV. Το 'Close' του Yahoo είναι προσαρμοσμένο για splits (όχι για μερίσματα)."""
    yf = _yf()
    res: dict[str, pd.DataFrame] = {}
    for i in range(0, len(tickers), chunk):
        part = tickers[i:i + chunk]
        if i and pause:
            time.sleep(pause)
        if progress_cb:
            progress_cb(i, len(tickers))

        def _dl():
            kw = dict(interval=interval, group_by="ticker", auto_adjust=False, threads=True,
                      progress=False, prepost=prepost, multi_level_index=True)
            if start:
                kw["start"] = start
                if end:
                    kw["end"] = end
            else:
                kw["period"] = period or "1y"
            return yf.download(part, **kw)

        try:
            df = call_with_retry(PROVIDER, f"history:{interval}", _dl, limiter=_limiter)
            res.update(_split_download(df, part))
        except Exception as e:  # noqa: BLE001
            log.warning("history chunk failed: %s", e)
    return res


def intraday_quotes(tickers: list[str]) -> dict[str, dict]:
    """Τελευταία τιμή από 1m bars (με pre/after-hours). Επιστρέφει και την ώρα του τελευταίου bar,
    ώστε το UI να δείχνει την πραγματική καθυστέρηση."""
    bars = history(tickers, period="2d", interval="1m", prepost=True, chunk=40)
    out = {}
    import zoneinfo
    ny = zoneinfo.ZoneInfo("America/New_York")
    for t, df in bars.items():
        df = df.dropna(subset=["Close"])
        if df.empty:
            continue
        idx = df.index.tz_convert(ny) if df.index.tz is not None else df.index.tz_localize("UTC").tz_convert(ny)
        df = df.set_axis(idx)
        last_ts = idx[-1]
        today = last_ts.date()
        day = df[df.index.date == today]
        reg = day.between_time("09:30", "15:59")
        pre = day.between_time("04:00", "09:29")
        post = day.between_time("16:00", "19:59")
        out[t] = {
            "price": _num(df["Close"].iloc[-1]),
            "volume": _num(reg["Volume"].sum()) if not reg.empty else None,
            "day_high": _num(reg["High"].max()) if not reg.empty else None,
            "day_low": _num(reg["Low"].min()) if not reg.empty else None,
            "day_open": _num(reg["Open"].iloc[0]) if not reg.empty else None,
            "pre_price": _num(pre["Close"].iloc[-1]) if not pre.empty else None,
            "post_price": _num(post["Close"].iloc[-1]) if not post.empty else None,
            "regular_close": _num(reg["Close"].iloc[-1]) if not reg.empty else None,
            "as_of": last_ts.astimezone(timezone.utc).isoformat(),
            "source": PROVIDER,
        }
    return out


def intraday_bars(ticker: str, interval: str = "5m", period: str = "5d") -> pd.DataFrame:
    d = history([ticker], period=period, interval=interval, prepost=False, chunk=1)
    return d.get(ticker, pd.DataFrame())


def company_info(ticker: str) -> dict:
    yf = _yf()
    t = yf.Ticker(ticker)
    info = call_with_retry(PROVIDER, "info", lambda: t.get_info(), limiter=_limiter) or {}
    keep = [
        "longName", "shortName", "sector", "industry", "marketCap", "sharesOutstanding", "floatShares",
        "averageVolume", "averageVolume10days", "fiftyTwoWeekHigh", "fiftyTwoWeekLow", "trailingPE",
        "forwardPE", "pegRatio", "priceToSalesTrailing12Months", "priceToBook", "trailingEps", "forwardEps",
        "revenueGrowth", "earningsGrowth", "earningsQuarterlyGrowth", "grossMargins", "operatingMargins",
        "profitMargins", "returnOnEquity", "debtToEquity", "currentRatio", "totalCash", "totalDebt",
        "freeCashflow", "operatingCashflow", "totalRevenue", "heldPercentInsiders", "heldPercentInstitutions",
        "shortPercentOfFloat", "shortRatio", "sharesShort", "sharesShortPriorMonth", "beta", "bid", "ask",
        "bidSize", "askSize", "targetMeanPrice", "targetHighPrice", "targetLowPrice", "recommendationKey",
        "numberOfAnalystOpinions", "exchange", "quoteType", "country", "website", "longBusinessSummary",
        "preMarketPrice", "postMarketPrice", "regularMarketPrice", "regularMarketPreviousClose",
    ]
    out = {k: info.get(k) for k in keep if info.get(k) is not None}
    if "longBusinessSummary" in out:
        out["longBusinessSummary"] = str(out["longBusinessSummary"])[:1200]
    return out


def earnings_date(ticker: str) -> str | None:
    yf = _yf()
    try:
        cal = call_with_retry(PROVIDER, "calendar", lambda: yf.Ticker(ticker).get_calendar(),
                              limiter=_limiter, retries=2)
    except Exception:
        return None
    if isinstance(cal, dict):
        v = cal.get("Earnings Date")
        if isinstance(v, (list, tuple)) and v:
            v = v[0]
        if v is not None:
            try:
                return pd.Timestamp(v).strftime("%Y-%m-%d")
            except Exception:
                return None
    return None


def insider_transactions(ticker: str, days: int = 180) -> list[dict]:
    yf = _yf()
    try:
        df = call_with_retry(PROVIDER, "insider", lambda: yf.Ticker(ticker).get_insider_transactions(),
                             limiter=_limiter, retries=2)
    except Exception:
        return []
    if df is None or len(df) == 0:
        return []
    out = []
    cutoff = pd.Timestamp.utcnow().tz_localize(None) - pd.Timedelta(days=days)
    for _, r in df.iterrows():
        d = pd.to_datetime(r.get("Start Date"), errors="coerce")
        if pd.isna(d) or d < cutoff:
            continue
        text = str(r.get("Text") or r.get("Transaction") or "")
        kind = "buy" if "purchase" in text.lower() or "buy" in text.lower() else (
            "sell" if "sale" in text.lower() or "sell" in text.lower() else "other")
        out.append({"date": d.strftime("%Y-%m-%d"), "insider": str(r.get("Insider", "")),
                    "position": str(r.get("Position", "")), "kind": kind, "text": text[:160],
                    "shares": _num(r.get("Shares")), "value": _num(r.get("Value"))})
    return out


def analyst_actions(ticker: str, days: int = 30) -> list[dict]:
    yf = _yf()
    try:
        df = call_with_retry(PROVIDER, "upgrades", lambda: yf.Ticker(ticker).get_upgrades_downgrades(),
                             limiter=_limiter, retries=2)
    except Exception:
        return []
    if df is None or len(df) == 0:
        return []
    df = df.reset_index()
    datecol = next((c for c in df.columns if "date" in str(c).lower()), None)
    if not datecol:
        return []
    cutoff = pd.Timestamp.utcnow().tz_localize(None) - pd.Timedelta(days=days)
    out = []
    for _, r in df.iterrows():
        d = pd.to_datetime(r[datecol], errors="coerce")
        if pd.isna(d):
            continue
        d = d.tz_localize(None) if d.tzinfo else d
        if d < cutoff:
            continue
        out.append({"date": d.strftime("%Y-%m-%d"), "firm": str(r.get("Firm", "")),
                    "to": str(r.get("ToGrade", "")), "from": str(r.get("FromGrade", "")),
                    "action": str(r.get("Action", ""))})
    return out


def news(ticker: str) -> list[dict]:
    yf = _yf()
    try:
        items = call_with_retry(PROVIDER, "news", lambda: yf.Ticker(ticker).get_news(count=20),
                                limiter=_limiter, retries=2)
    except Exception:
        return []
    out = []
    for it in items or []:
        c = it.get("content", it) if isinstance(it, dict) else {}
        title = c.get("title")
        if not title:
            continue
        pub = c.get("pubDate") or c.get("displayTime")
        if not pub and c.get("providerPublishTime"):
            pub = datetime.fromtimestamp(int(c["providerPublishTime"]), tz=timezone.utc).isoformat()
        prov = c.get("provider") or {}
        source = prov.get("displayName") if isinstance(prov, dict) else c.get("publisher")
        url = None
        for k in ("canonicalUrl", "clickThroughUrl"):
            v = c.get(k)
            if isinstance(v, dict) and v.get("url"):
                url = v["url"]
                break
        url = url or c.get("link")
        out.append({"title": title, "summary": c.get("summary") or c.get("description") or "",
                    "url": url, "source": source or c.get("publisher") or "Yahoo",
                    "published_at": pub, "ticker": ticker})
    return out


def is_stale(as_of_iso: str | None, minutes: int) -> bool:
    if not as_of_iso:
        return True
    try:
        t = datetime.fromisoformat(as_of_iso.replace("Z", "+00:00"))
    except ValueError:
        return True
    return datetime.now(timezone.utc) - t > timedelta(minutes=minutes)
