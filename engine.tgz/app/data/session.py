"""Ωράριο αγοράς ΗΠΑ (NYSE/Nasdaq), αργίες, συνεδρία (pre / regular / post / closed)."""
from __future__ import annotations

from datetime import date, datetime, time
from zoneinfo import ZoneInfo

NY = ZoneInfo("America/New_York")
ATHENS = ZoneInfo("Europe/Athens")

HOLIDAYS = {
    "2026-01-01", "2026-01-19", "2026-02-16", "2026-04-03", "2026-05-25", "2026-06-19",
    "2026-07-03", "2026-09-07", "2026-11-26", "2026-12-25",
    "2027-01-01", "2027-01-18", "2027-02-15", "2027-03-26", "2027-05-31", "2027-06-18",
    "2027-07-05", "2027-09-06", "2027-11-25", "2027-12-24",
}
EARLY_CLOSE = {"2026-11-27", "2026-12-24", "2027-11-26"}


def now_ny() -> datetime:
    return datetime.now(NY)


def is_trading_day(d: date) -> bool:
    return d.weekday() < 5 and d.isoformat() not in HOLIDAYS


def session(dt: datetime | None = None) -> str:
    dt = (dt or now_ny()).astimezone(NY)
    if not is_trading_day(dt.date()):
        return "closed"
    t = dt.time()
    close = time(13, 0) if dt.date().isoformat() in EARLY_CLOSE else time(16, 0)
    if time(4, 0) <= t < time(9, 30):
        return "pre"
    if time(9, 30) <= t < close:
        return "regular"
    if close <= t < time(20, 0):
        return "post"
    return "closed"


def session_label(s: str) -> str:
    return {"pre": "Premarket", "regular": "Κανονική συνεδρίαση", "post": "After-hours",
            "closed": "Κλειστή αγορά"}.get(s, s)


def last_trading_day(d: date | None = None) -> date:
    from datetime import timedelta
    d = d or now_ny().date()
    while not is_trading_day(d):
        d -= timedelta(days=1)
    return d


def session_info(dt: datetime | None = None) -> dict:
    """Ώρες της συνεδρίασης που αφορά τον χρήστη τώρα (σήμερα αν δεν έχει τελειώσει, αλλιώς η επόμενη),
    ως ISO με ζώνη ώρας ώστε ο browser να τις δείξει σε ώρα Ελλάδας. Λαμβάνει υπόψη αργίες και μισές μέρες."""
    from datetime import timedelta
    dt = (dt or now_ny()).astimezone(NY)
    day = dt.date()
    if not is_trading_day(day) or dt.time() >= time(20, 0):
        day += timedelta(days=1)
        while not is_trading_day(day):
            day += timedelta(days=1)
    close = time(13, 0) if day.isoformat() in EARLY_CLOSE else time(16, 0)
    mk = lambda t: datetime.combine(day, t, NY).isoformat()  # noqa: E731
    return {"day": day.isoformat(), "pre": mk(time(4, 0)), "open": mk(time(9, 30)), "close": mk(close),
            "post_end": mk(time(20, 0)), "early_close": day.isoformat() in EARLY_CLOSE, "now": dt.isoformat()}
