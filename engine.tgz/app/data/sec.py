"""SEC EDGAR (δωρεάν, επίσημο). Παρακολουθεί 8-K (γεγονότα), S-1/S-3/424B (πιθανές αυξήσεις
κεφαλαίου = κίνδυνος dilution), Form 4 (insider), 10-Q/10-K. Απαιτεί SEC_USER_AGENT με email."""
from __future__ import annotations

from datetime import date, timedelta

import httpx

from ..config import settings
from .net import RateLimiter, cached, call_with_retry

PROVIDER = "sec"
_limiter = RateLimiter(rate=8, per=1)  # SEC: max 10 req/s

FORM_INFO = {
    "8-K": ("Σημαντικό εταιρικό γεγονός", "event"),
    "S-1": ("Εγγραφή νέων μετοχών (πιθανό dilution)", "dilution"),
    "S-3": ("Shelf registration (πιθανή αύξηση κεφαλαίου)", "dilution"),
    "S-3ASR": ("Shelf registration (πιθανή αύξηση κεφαλαίου)", "dilution"),
    "424B5": ("Prospectus διάθεσης μετοχών (dilution)", "dilution"),
    "424B3": ("Prospectus διάθεσης μετοχών", "dilution"),
    "424B4": ("Prospectus διάθεσης μετοχών", "dilution"),
    "4": ("Συναλλαγή insider (Form 4)", "insider"),
    "10-Q": ("Τριμηνιαία οικονομικά", "financials"),
    "10-K": ("Ετήσια οικονομικά", "financials"),
    "SC 13D": ("Μεγάλος μέτοχος >5% (ενεργός)", "ownership"),
    "SC 13G": ("Μεγάλος μέτοχος >5% (παθητικός)", "ownership"),
}


def _headers() -> dict:
    return {"User-Agent": settings.sec_user_agent, "Accept-Encoding": "gzip, deflate"}


@cached(ttl=24 * 3600)
def cik_map() -> dict:
    def _do():
        r = httpx.get("https://www.sec.gov/files/company_tickers.json", headers=_headers(), timeout=20)
        r.raise_for_status()
        return r.json()

    try:
        data = call_with_retry(PROVIDER, "company_tickers", _do, limiter=_limiter)
        return {v["ticker"].upper(): int(v["cik_str"]) for v in data.values()}
    except Exception:
        m = saved_cik_map()  # www.sec.gov μπλοκαρισμένο (π.χ. από cloud): ο χάρτης που φτιάχτηκε από το data.sec.gov
        if m:
            return m
        raise


def saved_cik_map() -> dict:
    from .. import db
    try:
        m = db.kv_get("sec_cik_map") or {}
        return {k: int(v) for k, v in (m.get("map") or {}).items()}
    except Exception:  # noqa: BLE001
        return {}


def data_host_ok() -> int:
    """HTTP status του data.sec.gov (άλλος server από το www.sec.gov — συχνά δουλεύει όταν το www μπλοκάρει)."""
    try:
        r = httpx.get("https://data.sec.gov/submissions/CIK0000320193.json", headers=_headers(), timeout=20)
        return r.status_code
    except Exception:  # noqa: BLE001
        return 0


def build_cik_map_from_data(max_minutes: float = 25.0, workers: int = 6) -> dict:
    """Χάρτης ticker -> CIK ΧΩΡΙΣ το www.sec.gov: οι εταιρείες (CIK) από τα XBRL frames του data.sec.gov και τα
    tickers τους από τα submissions. Κρατιέται στη βάση· τις επόμενες φορές ζητούνται μόνο οι νέες εταιρείες."""
    import time
    from concurrent.futures import ThreadPoolExecutor

    from .. import db
    saved = db.kv_get("sec_cik_map") or {}
    tmap: dict[str, int] = {k: int(v) for k, v in (saved.get("map") or {}).items()}
    seen: set[int] = set(int(c) for c in (saved.get("seen") or []))
    ciks: set[int] = set()
    today = date.today()
    qs = []
    for back in range(1, 4):  # τα 3 τελευταία ολοκληρωμένα τρίμηνα
        y, q = today.year, (today.month - 1) // 3 + 1 - back
        while q <= 0:
            y, q = y - 1, q + 4
        qs.append(f"CY{y}Q{q}I")
    for code in qs:
        _limiter.wait()
        try:
            r = httpx.get(f"https://data.sec.gov/api/xbrl/frames/dei/EntityCommonStockSharesOutstanding/shares/{code}.json",
                          headers=_headers(), timeout=60)
            if r.status_code == 200:
                ciks |= {int(e["cik"]) for e in r.json().get("data") or [] if e.get("cik")}
        except Exception:  # noqa: BLE001
            continue
    todo = sorted(ciks - seen)
    t_end = time.time() + max_minutes * 60

    def one(cik: int):
        if time.time() > t_end:
            return cik, None
        _limiter.wait()
        try:
            r = httpx.get(f"https://data.sec.gov/submissions/CIK{cik:010d}.json", headers=_headers(), timeout=20)
            if r.status_code != 200:
                return cik, None
            return cik, [str(t).upper() for t in (r.json().get("tickers") or [])]
        except Exception:  # noqa: BLE001
            return cik, None

    with ThreadPoolExecutor(max_workers=workers) as ex:
        for cik, tick in ex.map(one, todo):
            if tick is None:
                continue
            seen.add(cik)
            for t in tick:
                tmap[t] = cik
    db.kv_set("sec_cik_map", {"map": tmap, "seen": sorted(seen), "at": db.now_iso()})
    try:
        from .net import _cache as _nc
        _nc.set(("cik_map", (), ()), tmap, 24 * 3600)  # ο νέος χάρτης ισχύει αμέσως
    except Exception:  # noqa: BLE001
        pass
    return {"tickers": len(tmap), "companies": len(seen), "new": len(todo), "frames": len(ciks)}


@cached(ttl=1800)
def recent_filings(ticker: str, days: int = 60) -> list[dict]:
    cik = cik_map().get(ticker.upper().replace(".", "-"))
    if not cik:
        return []

    def _do():
        r = httpx.get(f"https://data.sec.gov/submissions/CIK{cik:010d}.json", headers=_headers(), timeout=20)
        r.raise_for_status()
        return r.json()

    data = call_with_retry(PROVIDER, "submissions", _do, limiter=_limiter)
    rec = data.get("filings", {}).get("recent", {})
    cutoff = (date.today() - timedelta(days=days)).isoformat()
    out = []
    for i, form in enumerate(rec.get("form", [])):
        filed = rec["filingDate"][i]
        if filed < cutoff:
            break
        acc = rec["accessionNumber"][i]
        doc = rec.get("primaryDocument", [""] * (i + 1))[i]
        url = f"https://www.sec.gov/Archives/edgar/data/{cik}/{acc.replace('-', '')}/{doc}"
        label, kind = FORM_INFO.get(form, (form, "other"))
        out.append({"accession": acc, "ticker": ticker, "form": form, "filed_at": filed, "url": url,
                    "description": label, "kind": kind,
                    "items": (rec.get("items", [""] * (i + 1))[i] or "")})
    return out


def dilution_flags(filings: list[dict]) -> list[str]:
    return [f"{f['form']} στις {f['filed_at']}" for f in filings if f.get("kind") == "dilution"]
