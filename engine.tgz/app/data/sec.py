"""SEC EDGAR (δωρεάν, επίσημο). Παρακολουθεί 8-K (γεγονότα), S-1/S-3/424B (πιθανές αυξήσεις
κεφαλαίου = κίνδυνος dilution), Form 4 (insider), 10-Q/10-K. Απαιτεί SEC_USER_AGENT με email."""
from __future__ import annotations

from datetime import date, timedelta

import httpx

from ..config import settings
from .net import RateLimiter, cached, call_with_retry

PROVIDER = "sec"
_limiter = RateLimiter(rate=8, per=1)  # SEC: max 10 req/s

FORM_INFO = {
    "8-K": ("Σημαντικό εταιρικό γεγονός", "event"),
    "S-1": ("Εγγραφή νέων μετοχών (πιθανό dilution)", "dilution"),
    "S-3": ("Shelf registration (πιθανή αύξηση κεφαλαίου)", "dilution"),
    "S-3ASR": ("Shelf registration (πιθανή αύξηση κεφαλαίου)", "dilution"),
    "424B5": ("Prospectus διάθεσης μετοχών (dilution)", "dilution"),
    "424B3": ("Prospectus διάθεσης μετοχών", "dilution"),
    "424B4": ("Prospectus διάθεσης μετοχών", "dilution"),
    "4": ("Συναλλαγή insider (Form 4)", "insider"),
    "10-Q": ("Τριμηνιαία οικονομικά", "financials"),
    "10-K": ("Ετήσια οικονομικά", "financials"),
    "SC 13D": ("Μεγάλος μέτοχος >5% (ενεργός)", "ownership"),
    "SC 13G": ("Μεγάλος μέτοχος >5% (παθητικός)", "ownership"),
}


def _headers() -> dict:
    return {"User-Agent": settings.sec_user_agent, "Accept-Encoding": "gzip, deflate"}


@cached(ttl=24 * 3600)
def cik_map() -> dict:
    def _do():
        r = httpx.get("https://www.sec.gov/files/company_tickers.json", headers=_headers(), timeout=20)
        r.raise_for_status()
        return r.json()

    data = call_with_retry(PROVIDER, "company_tickers", _do, limiter=_limiter)
    return {v["ticker"].upper(): int(v["cik_str"]) for v in data.values()}


@cached(ttl=1800)
def recent_filings(ticker: str, days: int = 60) -> list[dict]:
    cik = cik_map().get(ticker.upper().replace(".", "-"))
    if not cik:
        return []

    def _do():
        r = httpx.get(f"https://data.sec.gov/submissions/CIK{cik:010d}.json", headers=_headers(), timeout=20)
        r.raise_for_status()
        return r.json()

    data = call_with_retry(PROVIDER, "submissions", _do, limiter=_limiter)
    rec = data.get("filings", {}).get("recent", {})
    cutoff = (date.today() - timedelta(days=days)).isoformat()
    out = []
    for i, form in enumerate(rec.get("form", [])):
        filed = rec["filingDate"][i]
        if filed < cutoff:
            break
        acc = rec["accessionNumber"][i]
        doc = rec.get("primaryDocument", [""] * (i + 1))[i]
        url = f"https://www.sec.gov/Archives/edgar/data/{cik}/{acc.replace('-', '')}/{doc}"
        label, kind = FORM_INFO.get(form, (form, "other"))
        out.append({"accession": acc, "ticker": ticker, "form": form, "filed_at": filed, "url": url,
                    "description": label, "kind": kind,
                    "items": (rec.get("items", [""] * (i + 1))[i] or "")})
    return out


def dilution_flags(filings: list[dict]) -> list[str]:
    return [f"{f['form']} στις {f['filed_at']}" for f in filings if f.get("kind") == "dilution"]
