"""Ενορχήστρωση δεδομένων: incremental ιστορικό, quotes με ετικέτα ποιότητας, company intelligence
με cache στη βάση. Κανόνας: αν μια πηγή αποτύχει επιστρέφουμε None — ποτέ κατασκευασμένα νούμερα."""
from __future__ import annotations

import json
import logging
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone

import pandas as pd

from .. import db
from ..config import settings
from . import finnhub, sec, yahoo
from .session import NY, now_ny, session

log = logging.getLogger("usalpha.data")

# Ετικέτες ποιότητας δεδομένων (εμφανίζονται παντού στο UI)
REALTIME, DELAYED, CACHED, STALE, EOD, NONE = "REALTIME", "DELAYED", "CACHED", "STALE", "EOD", "NO_DATA"


# ------------------------------------------------------------------ history
SPLIT_TOL = 0.03  # >3% διαφορά σε ήδη αποθηκευμένο κλείσιμο => split/αναπροσαρμογή => πλήρες ξανακατέβασμα


def _last_dates() -> dict[str, str]:
    return {r["ticker"]: r["d"] for r in db.q("SELECT ticker, MAX(date) d FROM prices_daily GROUP BY ticker")}


def _needs_full_refetch(ticker: str, new: pd.DataFrame) -> bool:
    """Συγκρίνει τα επικαλυπτόμενα κλεισίματα. Αν η εταιρεία έκανε split, το Yahoo αναπροσαρμόζει
    όλο το ιστορικό και τα παλιά μας δεδομένα δεν ταιριάζουν πια — πρέπει να ξανακατέβουν."""
    if new is None or new.empty:
        return False
    dates = [pd.Timestamp(i).strftime("%Y-%m-%d") for i in new.index]
    old = {r["date"]: r["close"] for r in db.q(
        f"SELECT date, close FROM prices_daily WHERE ticker=? AND date IN ({','.join('?' * len(dates))})",
        [ticker, *dates])}
    for d, (_, row) in zip(dates, new.iterrows()):
        o = old.get(d)
        c = row.get("Close")
        if o and c and not pd.isna(c) and abs(float(c) / o - 1) > SPLIT_TOL:
            return True
    return False


def update_history(tickers: list[str], years: int | None = None, progress_cb=None) -> dict:
    """Incremental ενημέρωση. Ομαδοποιεί ανά ημερομηνία τελευταίας εγγραφής ώστε μια παλιά μετοχή
    να μην αναγκάζει όλες να ξανακατεβάσουν μήνες δεδομένων."""
    years = years or settings.history_years
    last = _last_dates()
    today = datetime.now().date()
    full_start = (today - timedelta(days=int(365.25 * years))).isoformat()
    groups: dict[str, list[str]] = {}
    for t in dict.fromkeys(tickers):
        ld = last.get(t)
        if not ld:
            groups.setdefault(full_start, []).append(t)
        else:
            # κάδοι 7 ημερών, ξεκινώντας 5 μέρες πριν (για διορθώσεις & έλεγχο split)
            d = pd.Timestamp(ld) - pd.Timedelta(days=5)
            d = d - pd.Timedelta(days=d.dayofweek)  # Δευτέρα της εβδομάδας
            groups.setdefault(d.strftime("%Y-%m-%d"), []).append(t)
    saved, failed, refetch = 0, [], []
    total = sum(len(g) for g in groups.values())
    done = 0
    CH = 100  # αποθήκευση ανά 100 μετοχές: αν διακοπεί, η πρόοδος δεν χάνεται
    for start, tick in sorted(groups.items()):
        is_full = start == full_start
        for i in range(0, len(tick), CH):
            part = tick[i:i + CH]
            if progress_cb:
                progress_cb(done, total)
            data = yahoo.history(part, start=start, chunk=CH)
            for t in part:
                df = data.get(t)
                if df is None or df.dropna(subset=["Close"]).empty:
                    failed.append(t)
                    continue
                if not is_full and _needs_full_refetch(t, df):
                    refetch.append(t)
                    continue
                saved += db.save_prices(t, df)
            done += len(part)
            time.sleep(0.5)
    # backfill: μετοχές που έχουν λιγότερα χρόνια από το ζητούμενο (π.χ. αύξηση από 6 σε 10 έτη)
    backfilled = 0
    tried = set(db.kv_get("backfill_tried", []) or [])
    firsts = {r["ticker"]: r["d"] for r in db.q("SELECT ticker, MIN(date) d FROM prices_daily GROUP BY ticker")}
    need = [t for t in dict.fromkeys(tickers) if t in firsts and t not in tried
            and firsts[t] > (pd.Timestamp(full_start) + pd.Timedelta(days=45)).strftime("%Y-%m-%d")]
    for i in range(0, len(need), CH):
        part = need[i:i + CH]
        if progress_cb:
            progress_cb(i, len(need))
        end = max(firsts[t] for t in part)
        data = yahoo.history(part, start=full_start, chunk=CH, end=(pd.Timestamp(end) + pd.Timedelta(days=1)).strftime("%Y-%m-%d"))
        for t in part:
            df = data.get(t)
            if df is not None and not df.empty:
                old = df[df.index < pd.Timestamp(firsts[t])]
                if not old.empty:
                    saved += db.save_prices(t, old)
                    backfilled += 1
        tried.update(part)
        db.kv_set("backfill_tried", sorted(tried))
        time.sleep(0.5)
    if refetch:
        log.info("split/adjustment detected, full refetch: %s", refetch[:20])
        db.executemany("DELETE FROM prices_daily WHERE ticker=?", [(t,) for t in refetch])
        db.kv_set("backfill_tried", sorted(set(db.kv_get("backfill_tried", []) or []) - set(refetch)))
        data = yahoo.history(refetch, start=full_start)
        for t in refetch:
            if t in data:
                saved += db.save_prices(t, data[t])
            else:
                failed.append(t)
    try:
        from .listings import mark_failed, mark_ok
        mark_failed(failed)
        mark_ok([t for t in tickers if t not in set(failed)])
    except Exception:  # noqa: BLE001
        pass
    db.kv_set("history_updated_at", db.now_iso())
    return {"rows": saved, "failed": failed, "split_refetch": refetch, "backfilled": backfilled}


# ------------------------------------------------------------------ quotes
def _prev_close(ticker: str, today_ny: str) -> float | None:
    r = db.q1("SELECT close FROM prices_daily WHERE ticker=? AND date<? ORDER BY date DESC LIMIT 1",
              (ticker, today_ny))
    return r["close"] if r else None


def refresh_quotes(tickers: list[str]) -> int:
    if not tickers:
        return 0
    sess = session()
    yq = yahoo.intraday_quotes(tickers)
    fq: dict[str, dict] = {}
    if finnhub.enabled() and sess == "regular":
        for t in tickers[:50]:
            try:
                r = finnhub.quote(t)
                if r:
                    fq[t] = r
            except Exception as e:  # noqa: BLE001
                log.debug("finnhub quote %s: %s", t, e)
    today_ny = now_ny().date().isoformat()
    rows = []
    for t in tickers:
        y, f = yq.get(t), fq.get(t)
        if not y and not f:
            continue
        base = dict(y or {})
        quality = DELAYED
        if f and f.get("price"):
            base.update({k: v for k, v in f.items() if v is not None})
            quality = REALTIME
        prev = (f or {}).get("prev_close") or _prev_close(t, today_ny)
        price = base.get("regular_close") if sess in ("pre", "post", "closed") and base.get("regular_close") else base.get("price")
        last_any = base.get("price")
        chg = (price / prev - 1) * 100 if price and prev else None
        company = db.q1("SELECT data_json FROM company WHERE ticker=?", (t,))
        info = json.loads(company["data_json"]) if company else {}
        rows.append((t, last_any, prev, chg, base.get("volume"), info.get("bid"), info.get("ask"),
                     base.get("pre_price"), base.get("post_price"), base.get("day_high"), base.get("day_low"),
                     base.get("day_open"), base.get("source"), quality, base.get("as_of"), db.now_iso()))
    db.executemany(
        "INSERT INTO quotes(ticker,price,prev_close,change_pct,volume,bid,ask,pre_price,post_price,day_high,"
        "day_low,day_open,source,quality,as_of,fetched_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) "
        "ON CONFLICT(ticker) DO UPDATE SET price=excluded.price, prev_close=excluded.prev_close, "
        "change_pct=excluded.change_pct, volume=excluded.volume, bid=excluded.bid, ask=excluded.ask, "
        "pre_price=excluded.pre_price, post_price=excluded.post_price, day_high=excluded.day_high, "
        "day_low=excluded.day_low, day_open=excluded.day_open, source=excluded.source, quality=excluded.quality, as_of=excluded.as_of, "
        "fetched_at=excluded.fetched_at", rows)
    db.kv_set("quotes_updated_at", db.now_iso())
    return len(rows)


def effective_quality(row: dict | None) -> str:
    """Ποιότητα τη στιγμή της ανάγνωσης: ένα παλιό quote δεν παρουσιάζεται ως φρέσκο."""
    if not row or row.get("price") is None:
        return NONE
    sess = session()
    if sess == "closed":
        return EOD
    if yahoo.is_stale(row.get("as_of"), settings.stale_quote_min):
        return STALE
    if yahoo.is_stale(row.get("fetched_at"), max(2, settings.quote_refresh_sec * 3 // 60)):
        return CACHED
    return row.get("quality") or DELAYED


def get_quote(ticker: str) -> dict | None:
    r = db.q1("SELECT * FROM quotes WHERE ticker=?", (ticker,))
    if r:
        r["quality"] = effective_quality(r)
        r["delay_min"] = _delay_minutes(r.get("as_of"))
        return r
    # fallback: τελευταίο κλείσιμο από τη βάση, με σαφή ετικέτα EOD
    df = db.load_prices(ticker)
    if df.empty:
        return None
    last, prev = df.iloc[-1], (df.iloc[-2] if len(df) > 1 else None)
    return {"ticker": ticker, "price": float(last["close"]),
            "prev_close": float(prev["close"]) if prev is not None else None,
            "change_pct": (float(last["close"]) / float(prev["close"]) - 1) * 100 if prev is not None else None,
            "volume": float(last["volume"] or 0), "quality": EOD, "source": "db",
            "as_of": df.index[-1].strftime("%Y-%m-%d"), "delay_min": None}


def _delay_minutes(as_of: str | None) -> float | None:
    if not as_of:
        return None
    try:
        t = datetime.fromisoformat(as_of.replace("Z", "+00:00"))
        if t.tzinfo is None:
            return None
        return round((datetime.now(timezone.utc) - t).total_seconds() / 60, 1)
    except ValueError:
        return None


def all_quotes() -> dict[str, dict]:
    out = {}
    for r in db.q("SELECT * FROM quotes"):
        r["quality"] = effective_quality(r)
        r["delay_min"] = _delay_minutes(r.get("as_of"))
        out[r["ticker"]] = r
    return out


# ------------------------------------------------------------------ company intelligence
def get_company(ticker: str, max_age_hours: float = 24, fetch: bool = True) -> dict:
    row = db.q1("SELECT * FROM company WHERE ticker=?", (ticker,))
    if row:
        age = datetime.now(timezone.utc) - datetime.fromisoformat(row["fetched_at"])
        if age < timedelta(hours=max_age_hours) or not fetch:
            d = json.loads(row["data_json"])
            d["_fetched_at"] = row["fetched_at"]
            return d
    from .listings import snapshot_info
    if not fetch:
        return snapshot_info(ticker)  # ελαφριά θεμελιώδη για ΟΛΗ την αγορά (από τον screener)
    try:
        info = yahoo.company_info(ticker)
    except Exception as e:  # noqa: BLE001
        log.warning("company_info %s: %s", ticker, e)
        if row:
            d = json.loads(row["data_json"])
            d["_fetched_at"] = row["fetched_at"]
            d["_stale"] = True
            return d
        return snapshot_info(ticker)
    info["earnings_date"] = yahoo.earnings_date(ticker) or snapshot_info(ticker).get("earnings_date")
    info["insiders"] = yahoo.insider_transactions(ticker)
    info["analyst_actions"] = yahoo.analyst_actions(ticker)
    try:
        filings = sec.recent_filings(ticker)
        save_filings(filings)
        info["filings"] = filings[:25]
    except Exception as e:  # noqa: BLE001
        log.info("sec %s: %s", ticker, e)
        info["filings"] = []
    now = db.now_iso()
    db.execute(
        "INSERT INTO company(ticker,name,sector,industry,data_json,fetched_at) VALUES(?,?,?,?,?,?) "
        "ON CONFLICT(ticker) DO UPDATE SET name=excluded.name, sector=excluded.sector, "
        "industry=excluded.industry, data_json=excluded.data_json, fetched_at=excluded.fetched_at",
        (ticker, info.get("longName") or info.get("shortName"), info.get("sector"), info.get("industry"),
         json.dumps(info, default=str), now))
    info["_fetched_at"] = now
    return info


def refresh_companies(tickers: list[str], max_age_hours: float = 24, workers: int = 4) -> int:
    def one(t):
        try:
            return bool(get_company(t, max_age_hours=max_age_hours))
        except Exception:  # noqa: BLE001
            return False
    with ThreadPoolExecutor(max_workers=workers) as ex:
        return sum(ex.map(one, tickers))


def save_filings(filings: list[dict]) -> None:
    db.executemany(
        "INSERT OR IGNORE INTO filings(accession,ticker,form,filed_at,url,description) VALUES(?,?,?,?,?,?)",
        [(f["accession"], f["ticker"], f["form"], f["filed_at"], f["url"], f["description"]) for f in filings])


def sector_map() -> dict[str, str]:
    return {r["ticker"]: r["sector"] for r in db.q("SELECT ticker, sector FROM company WHERE sector IS NOT NULL")}


def sector_of(ticker: str) -> str | None:
    r = db.q1("SELECT sector FROM company WHERE ticker=?", (ticker,))
    if r and r["sector"]:
        return r["sector"]
    try:
        r = db.q1("SELECT sector FROM sec_meta WHERE ticker=?", (ticker,))
    except Exception:  # noqa: BLE001
        return None
    return r["sector"] if r else None


def watchlist() -> list[str]:
    return [r["ticker"] for r in db.q("SELECT ticker FROM watchlist ORDER BY added_at")]


def today_ny_str() -> str:
    return datetime.now(NY).date().isoformat()
