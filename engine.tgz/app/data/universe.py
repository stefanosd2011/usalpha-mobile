"""Σύμπαν μετοχών ΗΠΑ. Επεκτείνεται από config/universe_extra.txt (ένα ticker ανά γραμμή)
και από τη watchlist."""
from __future__ import annotations

from ..config import CONFIG_DIR

BENCHMARK = "SPY"
MARKET_SYMBOLS = {
    "SPY": "S&P 500 (SPY)", "QQQ": "Nasdaq 100 (QQQ)", "DIA": "Dow 30 (DIA)",
    "IWM": "Russell 2000 (IWM)", "^VIX": "VIX", "^TNX": "10Y Yield", "CL=F": "WTI Oil",
    "DX-Y.NYB": "Dollar Index",
}

# Yahoo sector name -> sector ETF
SECTOR_ETF = {
    "Technology": "XLK", "Financial Services": "XLF", "Energy": "XLE", "Healthcare": "XLV",
    "Industrials": "XLI", "Consumer Cyclical": "XLY", "Consumer Defensive": "XLP",
    "Utilities": "XLU", "Basic Materials": "XLB", "Real Estate": "XLRE",
    "Communication Services": "XLC",
}
THEME_ETF = {"Semiconductors": "SMH", "Biotech": "XBI", "Innovation": "ARKK", "Crypto": "BITO"}

LARGE_LIQUID = """
AAPL MSFT NVDA AMZN GOOGL META TSLA AVGO AMD NFLX ORCL CRM ADBE INTC QCOM TXN MU AMAT LRCX KLAC
INTU NOW PANW CRWD SNOW PLTR UBER ABNB SHOP XYZ PYPL COIN MRVL ANET SMCI DELL ARM TSM ASML DDOG
NET ZS MDB TEAM WDAY FTNT OKTA TTD APP RBLX U SNAP PINS SPOT ROKU DASH HOOD SOFI AFRM UPST
JPM BAC WFC C GS MS SCHW BLK AXP V MA COF
UNH JNJ LLY PFE MRK ABBV TMO ABT AMGN GILD VRTX REGN BIIB MRNA ISRG
WMT COST TGT HD LOW NKE LULU MCD SBUX CMG DIS
BA CAT DE GE HON LMT RTX NOC GD UPS FDX
XOM CVX COP OXY SLB HAL DVN EOG
FCX NEM NUE AA CLF ALB MP
NEE CEG VST SO DUK
T VZ TMUS
F GM RIVN LCID NIO XPEV LI
"""

HIGH_BETA = """
AEHR ALAB TSSI IONQ RGTI QBTS QUBT SOUN BBAI AI PATH S IREN CIFR WULF CORZ BTDR MARA RIOT CLSK HUT
APLD CRWV NBIS OKLO SMR NNE LEU CCJ UEC BWXT
RKLB ASTS LUNR RDW ACHR JOBY
HIMS CELH DUOL CAVA ELF ONON DKNG
SERV RR KTOS AVAV
VKTX HOOD MSTR CVNA OPEN UPST AFRM
ENPH FSLR RUN PLUG BE CHPT EOSE
NVAX SAVA OCGN SPCE TLRY CGC
GME AMC BB
"""

ETFS = "SPY QQQ DIA IWM XLK XLF XLE XLV XLI XLY XLP XLU XLB XLRE XLC SMH XBI ARKK BITO"


def _parse(block: str) -> list[str]:
    return [t.strip().upper() for t in block.split() if t.strip()]


def base_universe() -> list[str]:
    tickers = _parse(LARGE_LIQUID) + _parse(HIGH_BETA)
    extra = CONFIG_DIR / "universe_extra.txt"
    if extra.exists():
        for ln in extra.read_text(encoding="utf-8").splitlines():
            ln = ln.split("#", 1)[0].strip().upper()
            if ln:
                tickers.append(ln)
    out, seen = [], set()
    for t in tickers:
        if t not in seen:
            seen.add(t)
            out.append(t)
    return out


def etf_universe() -> list[str]:
    return _parse(ETFS)


def full_universe(watchlist: list[str] | None = None) -> list[str]:
    u = base_universe()
    for t in watchlist or []:
        if t not in u:
            u.append(t)
    return u
