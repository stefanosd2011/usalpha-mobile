"""Τεχνικοί δείκτες (καθαρό pandas/numpy, χωρίς look-ahead: κάθε τιμή στη γραμμή t
χρησιμοποιεί μόνο δεδομένα έως και t)."""
from __future__ import annotations

import numpy as np
import pandas as pd


def ema(s: pd.Series, n: int) -> pd.Series:
    return s.ewm(span=n, adjust=False, min_periods=n).mean()


def sma(s: pd.Series, n: int) -> pd.Series:
    return s.rolling(n, min_periods=n).mean()


def wilder(s: pd.Series, n: int) -> pd.Series:
    return s.ewm(alpha=1 / n, adjust=False, min_periods=n).mean()


def rsi(close: pd.Series, n: int = 14) -> pd.Series:
    d = close.diff()
    up, dn = d.clip(lower=0), (-d).clip(lower=0)
    rs = wilder(up, n) / wilder(dn, n).replace(0, np.nan)
    out = 100 - 100 / (1 + rs)
    return out.where(wilder(dn, n) != 0, 100.0)


def macd(close: pd.Series, fast=12, slow=26, sig=9):
    line = ema(close, fast) - ema(close, slow)
    signal = line.ewm(span=sig, adjust=False, min_periods=sig).mean()
    return line, signal, line - signal


def bollinger(close: pd.Series, n=20, k=2.0):
    mid = sma(close, n)
    sd = close.rolling(n, min_periods=n).std(ddof=0)
    return mid + k * sd, mid, mid - k * sd


def true_range(df: pd.DataFrame) -> pd.Series:
    pc = df["close"].shift(1)
    return pd.concat([df["high"] - df["low"], (df["high"] - pc).abs(), (df["low"] - pc).abs()], axis=1).max(axis=1)


def atr(df: pd.DataFrame, n=14) -> pd.Series:
    return wilder(true_range(df), n)


def adx(df: pd.DataFrame, n=14):
    up = df["high"].diff()
    dn = -df["low"].diff()
    plus_dm = pd.Series(np.where((up > dn) & (up > 0), up, 0.0), index=df.index)
    minus_dm = pd.Series(np.where((dn > up) & (dn > 0), dn, 0.0), index=df.index)
    tr = wilder(true_range(df), n)
    plus_di = 100 * wilder(plus_dm, n) / tr
    minus_di = 100 * wilder(minus_dm, n) / tr
    dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di).replace(0, np.nan)
    return wilder(dx, n), plus_di, minus_di


def stoch_rsi(close: pd.Series, n=14, k=3, d=3):
    r = rsi(close, n)
    lo, hi = r.rolling(n).min(), r.rolling(n).max()
    st = 100 * (r - lo) / (hi - lo).replace(0, np.nan)
    kline = st.rolling(k).mean()
    return kline, kline.rolling(d).mean()


def vwap_rolling(df: pd.DataFrame, n=20) -> pd.Series:
    """Σε ημερήσια bars: VWAP των τελευταίων n ημερών (typical price × volume)."""
    tp = (df["high"] + df["low"] + df["close"]) / 3
    v = df["volume"].fillna(0)
    return (tp * v).rolling(n, min_periods=n).sum() / v.rolling(n, min_periods=n).sum().replace(0, np.nan)


def vwap_intraday(df: pd.DataFrame) -> pd.Series:
    """Σε intraday bars: VWAP που μηδενίζεται κάθε μέρα."""
    tp = (df["high"] + df["low"] + df["close"]) / 3
    v = df["volume"].fillna(0)
    day = df.index.normalize() if hasattr(df.index, "normalize") else df.index
    return (tp * v).groupby(day).cumsum() / v.groupby(day).cumsum().replace(0, np.nan)


def add_all(df: pd.DataFrame) -> pd.DataFrame:
    """Προσθέτει όλους τους δείκτες στο DataFrame (στήλες open/high/low/close/volume)."""
    out = df.copy()
    c = out["close"]
    for n in (9, 20, 50, 200):
        out[f"ema{n}"] = ema(c, n)
    for n in (20, 50, 100, 200):
        out[f"sma{n}"] = sma(c, n)
    out["rsi"] = rsi(c)
    out["macd"], out["macd_sig"], out["macd_hist"] = macd(c)
    out["bb_up"], out["bb_mid"], out["bb_lo"] = bollinger(c)
    out["bb_width"] = (out["bb_up"] - out["bb_lo"]) / out["bb_mid"]
    out["atr"] = atr(out)
    out["atr_pct"] = out["atr"] / c * 100
    out["adx"], out["pdi"], out["mdi"] = adx(out)
    out["stoch_k"], out["stoch_d"] = stoch_rsi(c)
    out["vwap20"] = vwap_rolling(out, 20)
    out["vol_avg20"] = out["volume"].shift(1).rolling(20, min_periods=10).mean()
    out["rvol"] = out["volume"] / out["vol_avg20"].replace(0, np.nan)
    out["dollar_vol20"] = (out["close"] * out["volume"]).shift(1).rolling(20, min_periods=10).mean()
    out["hi20"] = out["high"].shift(1).rolling(20, min_periods=20).max()
    out["lo20"] = out["low"].shift(1).rolling(20, min_periods=20).min()
    out["hi55"] = out["high"].shift(1).rolling(55, min_periods=55).max()
    out["hi252"] = out["high"].rolling(252, min_periods=60).max()
    out["lo252"] = out["low"].rolling(252, min_periods=60).min()
    out["ret1"] = c.pct_change()
    out["ret5"] = c.pct_change(5)
    out["ret21"] = c.pct_change(21)
    out["ret63"] = c.pct_change(63)
    out["ret126"] = c.pct_change(126)
    out["vol21"] = out["ret1"].rolling(21).std() * np.sqrt(252) * 100
    out["gap"] = out["open"] / c.shift(1) - 1
    return out


# ---------------------------------------------------------------- structure
def swing_points(df: pd.DataFrame, k: int = 3) -> tuple[pd.Series, pd.Series]:
    """Fractal swings. Επιβεβαιώνονται k bars αργότερα (χωρίς look-ahead όταν χρησιμοποιείται
    με τη στήλη *_confirmed)."""
    h, l = df["high"], df["low"]
    hi = h[(h == h.rolling(2 * k + 1, center=True).max())]
    lo = l[(l == l.rolling(2 * k + 1, center=True).min())]
    return hi.dropna(), lo.dropna()


def support_resistance(df: pd.DataFrame, lookback: int = 180, k: int = 3, max_levels: int = 6) -> list[dict]:
    d = df.tail(lookback)
    if len(d) < 30:
        return []
    hi, lo = swing_points(d, k)
    pts = [(float(v), "R") for v in hi.values] + [(float(v), "S") for v in lo.values]
    if not pts:
        return []
    a = float(atr(d).iloc[-1] or d["close"].iloc[-1] * 0.02)
    tol = max(a * 0.5, d["close"].iloc[-1] * 0.004)
    pts.sort()
    clusters: list[list[float]] = []
    for p, _ in pts:
        if clusters and abs(p - np.mean(clusters[-1])) <= tol:
            clusters[-1].append(p)
        else:
            clusters.append([p])
    price = float(d["close"].iloc[-1])
    levels = [{"price": round(float(np.mean(c)), 4), "touches": len(c),
               "type": "resistance" if np.mean(c) > price else "support"} for c in clusters]
    levels.sort(key=lambda x: (-x["touches"], abs(x["price"] - price)))
    return sorted(levels[:max_levels], key=lambda x: x["price"])


def fibonacci(df: pd.DataFrame, lookback: int = 120) -> dict | None:
    d = df.tail(lookback)
    if len(d) < 20:
        return None
    hi_i, lo_i = d["high"].idxmax(), d["low"].idxmin()
    hi, lo = float(d.loc[hi_i, "high"]), float(d.loc[lo_i, "low"])
    if hi <= lo:
        return None
    up = lo_i < hi_i  # κίνηση προς τα πάνω -> retracement από την κορυφή
    rng = hi - lo
    ratios = [0, 0.236, 0.382, 0.5, 0.618, 0.786, 1]
    levels = {f"{r:.3f}": round(hi - r * rng if up else lo + r * rng, 4) for r in ratios}
    return {"direction": "up" if up else "down", "high": hi, "low": lo,
            "high_date": str(pd.Timestamp(hi_i).date()), "low_date": str(pd.Timestamp(lo_i).date()),
            "levels": levels}


def volume_profile(df: pd.DataFrame, lookback: int = 120, bins: int = 24) -> dict | None:
    d = df.tail(lookback).dropna(subset=["close", "volume"])
    if len(d) < 20 or d["volume"].sum() <= 0:
        return None
    tp = (d["high"] + d["low"] + d["close"]) / 3
    hist, edges = np.histogram(tp, bins=bins, weights=d["volume"])
    poc_i = int(np.argmax(hist))
    order = np.argsort(hist)[::-1]
    total, acc, va = hist.sum(), 0.0, []
    for i in order:
        acc += hist[i]
        va.append(i)
        if acc >= 0.7 * total:
            break
    return {"bins": [{"low": round(float(edges[i]), 4), "high": round(float(edges[i + 1]), 4),
                      "volume": float(hist[i])} for i in range(bins)],
            "poc": round(float((edges[poc_i] + edges[poc_i + 1]) / 2), 4),
            "va_low": round(float(edges[min(va)]), 4), "va_high": round(float(edges[max(va) + 1]), 4),
            "note": "Προσέγγιση από ημερήσια bars (typical price), όχι tick δεδομένα."}


def relative_strength(df: pd.DataFrame, bench: pd.DataFrame, n: int = 63) -> dict | None:
    if bench is None or bench.empty or len(df) < n + 1:
        return None
    j = df[["close"]].join(bench[["close"]].rename(columns={"close": "b"}), how="inner").dropna()
    if len(j) < n + 1:
        return None
    rs_line = j["close"] / j["b"]
    perf = float(j["close"].iloc[-1] / j["close"].iloc[-n - 1] - 1)
    bperf = float(j["b"].iloc[-1] / j["b"].iloc[-n - 1] - 1)
    slope = float(rs_line.iloc[-1] / rs_line.iloc[-21] - 1) if len(rs_line) > 21 else 0.0
    return {"stock_ret": perf * 100, "bench_ret": bperf * 100, "excess": (perf - bperf) * 100,
            "rs_slope_21d": slope * 100, "rs_new_high": bool(rs_line.iloc[-1] >= rs_line.tail(126).max())}


def divergences(df: pd.DataFrame, lookback: int = 60, k: int = 3) -> list[dict]:
    """Bullish: χαμηλότερο χαμηλό τιμής με υψηλότερο χαμηλό RSI. Bearish: το αντίθετο στις κορυφές.
    Λαμβάνονται υπόψη μόνο swings επιβεβαιωμένα (τουλάχιστον k bars πριν το τέλος)."""
    d = df.tail(lookback + 2 * k).copy()
    if "rsi" not in d:
        d["rsi"] = rsi(df["close"]).tail(len(d))
    hi, lo = swing_points(d, k)
    cutoff = d.index[-k - 1] if len(d) > k + 1 else d.index[-1]
    hi, lo = hi[hi.index <= cutoff], lo[lo.index <= cutoff]
    out = []
    if len(lo) >= 2:
        (i1, p1), (i2, p2) = list(lo.items())[-2:]
        r1, r2 = d.loc[i1, "rsi"], d.loc[i2, "rsi"]
        if p2 < p1 and r2 > r1 and r2 < 45:
            out.append({"type": "bullish", "date": str(pd.Timestamp(i2).date()),
                        "text": f"Bullish divergence: νέο χαμηλό τιμής αλλά RSI υψηλότερα ({r1:.0f}→{r2:.0f})"})
    if len(hi) >= 2:
        (i1, p1), (i2, p2) = list(hi.items())[-2:]
        r1, r2 = d.loc[i1, "rsi"], d.loc[i2, "rsi"]
        if p2 > p1 and r2 < r1 and r1 > 60:
            out.append({"type": "bearish", "date": str(pd.Timestamp(i2).date()),
                        "text": f"Bearish divergence: νέο υψηλό τιμής αλλά RSI χαμηλότερα ({r1:.0f}→{r2:.0f})"})
    return out


def recent_cross(a: pd.Series, b: pd.Series, within: int = 10) -> str | None:
    diff = (a - b).dropna()
    if len(diff) < within + 1:
        return None
    s = np.sign(diff.tail(within + 1))
    ch = s.diff().fillna(0)
    if (ch > 0).any() and s.iloc[-1] > 0:
        return "up"
    if (ch < 0).any() and s.iloc[-1] < 0:
        return "down"
    return None
