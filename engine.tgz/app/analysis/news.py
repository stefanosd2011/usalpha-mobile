"""News intelligence: κατηγοριοποίηση, sentiment, αξιοπιστία πηγής, σημαντικότητα, χρονικός
ορίζοντας, έλεγχος αν έχει ήδη ενσωματωθεί στην τιμή, και αφαίρεση διπλοεγγραφών.
Λειτουργεί χωρίς AI (κανόνες/λεξικό). Αν υπάρχει AI key, το AI βελτιώνει την αξιολόγηση."""
from __future__ import annotations

import hashlib
import json
import math
import re
from datetime import datetime, timedelta, timezone

import pandas as pd

from .. import db

CATEGORIES = [
    # (name, regex, importance 0-1, prior sentiment, horizon)
    ("bankruptcy", r"\b(bankruptcy|chapter 11|going concern|delist)", 1.0, -0.9, "εβδομάδες-μήνες"),
    ("offering", r"\b(public offering|stock offering|share offering|priced .*offering|registered direct|at-the-market|atm program|private placement|convertible notes?)", 0.9, -0.6, "ημέρες"),
    ("fda", r"\b(fda|pdufa|phase (1|2|3|i|ii|iii)|clinical trial|breakthrough therapy|biologics license|nda\b|ema approval)", 0.95, 0.0, "ημέρες-εβδομάδες"),
    ("earnings", r"\b(earnings|quarterly results|q[1-4] results|eps|revenue (beat|miss)|reports? (first|second|third|fourth)[- ]quarter)", 0.9, 0.0, "ημέρες"),
    ("guidance", r"\b(guidance|outlook|forecast)\b.*\b(raise|raises|raised|cut|cuts|lower|lowers|boost)", 0.9, 0.0, "εβδομάδες"),
    ("mna", r"\b(acquire|acquisition|merger|to buy|takeover|buyout|tender offer|definitive agreement)", 0.95, 0.3, "εβδομάδες"),
    ("contract", r"\b(contract|award(ed)?|order worth|deal worth|multi-year agreement|purchase order)", 0.75, 0.5, "ημέρες-εβδομάδες"),
    ("partnership", r"\b(partner(ship)?|collaborat|joint venture|teams? up|strategic alliance)", 0.6, 0.4, "ημέρες-εβδομάδες"),
    ("product", r"\b(launch(es|ed)?|unveil|introduc(es|ed)|new product|rolls? out|release[sd]?)", 0.5, 0.3, "εβδομάδες"),
    ("upgrade", r"\b(upgrade[sd]?|raises? (price )?target|initiat\w+ .*\b(buy|outperform|overweight))", 0.6, 0.6, "ημέρες"),
    ("downgrade", r"\b(downgrade[sd]?|cuts? (price )?target|lowers? (price )?target)", 0.6, -0.6, "ημέρες"),
    ("insider", r"\b(insider (buy|purchase|sell|sale)|ceo (buys|sells|bought|sold)|director (buys|bought))", 0.5, 0.0, "εβδομάδες"),
    ("legal", r"\b(lawsuit|sued|investigation|subpoena|sec charges|class action|probe|fraud)", 0.7, -0.5, "εβδομάδες"),
    ("buyback", r"\b(buyback|repurchase)", 0.5, 0.5, "εβδομάδες"),
    ("management", r"\b(ceo|cfo|chief executive)\b.*\b(resign|steps down|appoint|named|depart)", 0.6, -0.1, "εβδομάδες"),
    ("macro", r"\b(fed|fomc|powell|inflation|cpi|ppi|jobs report|payrolls|gdp|interest rates?|treasury yields?|recession)", 0.7, 0.0, "ημέρες"),
    ("geopolitics", r"\b(tariff|sanction|war|military|china|taiwan|russia|ukraine|middle east|iran|export control)", 0.65, -0.2, "ημέρες-εβδομάδες"),
]

POS = set("""beat beats beating record surge surges soar soars jump jumps rally rallies gain gains strong stronger
growth grow grows raise raises raised upgrade upgraded outperform approval approved approves win wins won award
awarded expand expands expansion profit profitable exceed exceeds exceeded boost boosts bullish breakthrough
positive accelerate accelerates momentum higher upside buy partnership milestone success successful""".split())
NEG = set("""miss misses missed plunge plunges plummet tumble tumbles fall falls fell drop drops slump weak weaker
decline declines loss losses cut cuts lower lowers lowered downgrade downgraded underperform reject rejected
rejection delay delayed halt halted recall lawsuit probe investigation fraud bankruptcy dilution offering warn
warns warning bearish negative concern concerns fears layoffs layoff sell selloff slowdown default disappoint
disappointing disappoints crash""".split())
NEGATORS = {"not", "no", "never", "without", "fails", "failed"}

CREDIBILITY = [
    (r"sec\.gov|sec filing|edgar", 1.0), (r"reuters", 0.95), (r"bloomberg", 0.95), (r"wall street journal|wsj", 0.93),
    (r"associated press|\bap\b", 0.9), (r"financial times|\bft\b", 0.92), (r"cnbc", 0.85), (r"barron", 0.85),
    (r"marketwatch", 0.8), (r"business wire|pr newswire|globenewswire|accesswire|newsfile", 0.8),
    (r"yahoo", 0.7), (r"investor'?s business daily|ibd", 0.75), (r"zacks", 0.55), (r"benzinga", 0.6),
    (r"seeking alpha", 0.55), (r"motley fool|fool\.com", 0.5), (r"investorplace", 0.45), (r"finnhub", 0.65),
]

_word = re.compile(r"[a-z][a-z'-]+")


def credibility(source: str | None) -> float:
    s = (source or "").lower()
    for pat, v in CREDIBILITY:
        if re.search(pat, s):
            return v
    return 0.5


def categorize(text: str) -> tuple[str, float, float, str]:
    t = text.lower()
    for name, pat, imp, prior, hz in CATEGORIES:
        if re.search(pat, t):
            return name, imp, prior, hz
    return "general", 0.35, 0.0, "ημέρες"


def lexicon_sentiment(text: str) -> float:
    words = _word.findall(text.lower())
    score, n = 0.0, 0
    for i, w in enumerate(words):
        v = 1 if w in POS else (-1 if w in NEG else 0)
        if v:
            if any(x in NEGATORS for x in words[max(0, i - 3):i]):
                v = -v
            score += v
            n += 1
    if n == 0:
        return 0.0
    return max(-1.0, min(1.0, score / (n + 1.5)))


def sentiment(title: str, summary: str = "") -> tuple[float, dict]:
    text = f"{title}. {summary or ''}"
    cat, imp, prior, hz = categorize(text)
    lex = lexicon_sentiment(title) * 0.7 + lexicon_sentiment(summary or "") * 0.3
    s = 0.6 * lex + 0.4 * prior if lex else prior * 0.8
    # ειδικές περιπτώσεις
    tl = text.lower()
    if cat == "fda":
        if re.search(r"approv|clear(ed|ance)|met primary|positive", tl):
            s = max(s, 0.7)
        if re.search(r"reject|complete response letter|crl|fail|did not meet|halt", tl):
            s = min(s, -0.8)
    if cat == "earnings":
        if re.search(r"\bbeat|tops|exceed|above (estimates|expectations)", tl):
            s = max(s, 0.5)
        if re.search(r"\bmiss|below (estimates|expectations)|falls short", tl):
            s = min(s, -0.5)
    return round(max(-1.0, min(1.0, s)), 3), {"category": cat, "importance": imp, "horizon": hz}


# ------------------------------------------------------------------ dedup
def _norm_tokens(title: str) -> set[str]:
    stop = {"the", "a", "an", "to", "of", "in", "on", "for", "and", "is", "as", "at", "by", "with", "its", "after"}
    return {w for w in _word.findall(title.lower()) if w not in stop and len(w) > 2}


def jaccard(a: set, b: set) -> float:
    return len(a & b) / len(a | b) if a and b else 0.0


def news_id(item: dict) -> str:
    key = (item.get("url") or "") + "|" + (item.get("title") or "").strip().lower()
    return hashlib.sha1(key.encode()).hexdigest()[:20]


def _parse_dt(v) -> datetime | None:
    if not v:
        return None
    try:
        d = pd.Timestamp(v)
        d = d.tz_localize("UTC") if d.tzinfo is None else d.tz_convert("UTC")
        return d.to_pydatetime()
    except Exception:
        return None


def priced_in(ticker: str | None, published: datetime | None, sent: float) -> tuple[str, float | None]:
    """Συγκρίνει την κίνηση της τιμής από τη δημοσίευση με το ATR. Επιστρέφει ετικέτα + κίνηση %."""
    if not ticker or not published:
        return "άγνωστο", None
    df = db.load_prices(ticker, start=(published - timedelta(days=40)).strftime("%Y-%m-%d"))
    if len(df) < 15:
        return "άγνωστο", None
    pub_day = pd.Timestamp(published.date())
    before = df[df.index < pub_day]
    if before.empty:
        return "άγνωστο", None
    p0 = float(before["close"].iloc[-1])
    q = db.q1("SELECT price FROM quotes WHERE ticker=?", (ticker,))
    p1 = float(q["price"]) if q and q.get("price") else float(df["close"].iloc[-1])
    move = (p1 / p0 - 1) * 100
    tr = (df["high"] - df["low"]).tail(14).mean() / p0 * 100
    if abs(sent) < 0.15:
        return "ουδέτερη είδηση", round(move, 2)
    if math.copysign(1, move) == math.copysign(1, sent) and abs(move) >= 1.5 * tr:
        return "μάλλον ενσωματώθηκε", round(move, 2)
    if math.copysign(1, move) != math.copysign(1, sent) and abs(move) >= 1.0 * tr:
        return "η αγορά αντέδρασε αντίθετα", round(move, 2)
    return "πιθανώς όχι ακόμα", round(move, 2)


def ingest(items: list[dict]) -> int:
    """Αποθηκεύει νέες ειδήσεις με αξιολόγηση και cluster διπλοεγγραφών."""
    if not items:
        return 0
    added = 0
    for it in items:
        nid = news_id(it)
        if db.q1("SELECT 1 FROM news WHERE id=?", (nid,)):
            continue
        pub = _parse_dt(it.get("published_at")) or datetime.now(timezone.utc)
        ticker = it.get("ticker")
        toks = _norm_tokens(it["title"])
        cluster, primary = nid, 1
        recent = db.q("SELECT id, cluster_id, title FROM news WHERE (ticker IS ? OR ticker=?) AND published_at>=?",
                      (ticker, ticker, (pub - timedelta(hours=48)).isoformat()))
        for r in recent:
            if jaccard(toks, _norm_tokens(r["title"])) >= 0.55:
                cluster, primary = r["cluster_id"], 0
                break
        s, meta = sentiment(it["title"], it.get("summary", ""))
        cred = credibility(it.get("source"))
        label, _move = priced_in(ticker, pub, s)
        impact = round(s * cred * meta["importance"], 3)
        db.execute(
            "INSERT OR IGNORE INTO news(id,cluster_id,ticker,title,summary,url,source,published_at,fetched_at,category,"
            "sentiment,credibility,importance,horizon,priced_in,impact,is_primary) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (nid, cluster, ticker, it["title"][:400], (it.get("summary") or "")[:1500], it.get("url"),
             it.get("source"), pub.isoformat(), db.now_iso(), meta["category"], s, cred, meta["importance"],
             meta["horizon"], label, impact, primary))
        added += 1
    return added


def news_score(ticker: str, days: int = 7, now: datetime | None = None) -> dict:
    """Βαθμολογία ειδήσεων 0-100. Κάθε cluster μετράει ΜΙΑ φορά (η πιο αξιόπιστη πηγή του)."""
    now = now or datetime.now(timezone.utc)
    rows = db.q("SELECT * FROM news WHERE ticker=? AND published_at>=? ORDER BY published_at DESC",
                (ticker, (now - timedelta(days=days)).isoformat()))
    clusters: dict[str, dict] = {}
    for r in rows:
        c = clusters.get(r["cluster_id"])
        if c is None or (r["credibility"] or 0) > (c["credibility"] or 0):
            clusters[r["cluster_id"]] = r
    total, items = 0.0, []
    for r in clusters.values():
        ai = json.loads(r["ai_json"]) if r.get("ai_json") else None
        sent = ai.get("sentiment", r["sentiment"]) if ai else r["sentiment"]
        imp = ai.get("importance", r["importance"]) if ai else r["importance"]
        age_d = max(0.0, (now - datetime.fromisoformat(r["published_at"])).total_seconds() / 86400)
        decay = 0.5 ** (age_d / 2.0)
        pin = r.get("priced_in") or ""
        pin_factor = 0.5 if pin.startswith("μάλλον") else 1.0
        contrib = sent * (r["credibility"] or 0.5) * imp * decay * pin_factor
        total += contrib
        items.append({**r, "contribution": round(contrib, 3)})
    score = 50 + 50 * math.tanh(total * 1.2)
    items.sort(key=lambda x: abs(x["contribution"]), reverse=True)
    return {"score": round(score, 1), "n_clusters": len(clusters), "n_articles": len(rows),
            "top": items[:8], "raw": round(total, 3)}
