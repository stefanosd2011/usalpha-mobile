"""Θεμελιώδης ανάλυση από company intelligence (Yahoo + SEC). Βαθμολογία 0-100 (50 = ουδέτερο)
και ρητή κάλυψη δεδομένων: όταν λείπουν στοιχεία, η βαθμολογία συρρικνώνεται προς το 50."""
from __future__ import annotations

from datetime import date, datetime

import numpy as np


def _g(d: dict, k: str):
    v = d.get(k)
    try:
        return None if v is None else float(v)
    except (TypeError, ValueError):
        return None


def days_until(d: str | None) -> int | None:
    if not d:
        return None
    try:
        return (datetime.strptime(d[:10], "%Y-%m-%d").date() - date.today()).days
    except ValueError:
        return None


def analyze(info: dict, price: float | None = None, peers: dict | None = None) -> dict:
    if not info:
        return {"ok": False, "score": 50.0, "coverage": 0, "pros": [], "cons": [],
                "risks": ["Δεν υπάρχουν θεμελιώδη δεδομένα"], "flags": ["no_fundamentals"], "metrics": {}}
    pros, cons, risks, flags = [], [], [], []
    pts, used = 0.0, 0
    fields = ["revenueGrowth", "earningsGrowth", "forwardPE", "trailingPE", "debtToEquity", "freeCashflow",
              "operatingMargins", "returnOnEquity", "heldPercentInstitutions", "currentRatio"]
    coverage = sum(1 for f in fields if _g(info, f) is not None) / len(fields)

    rg = _g(info, "revenueGrowth")
    if rg is not None:
        used += 1
        if rg > 0.25:
            pts += 3; pros.append(f"Πολύ ισχυρή αύξηση εσόδων {rg*100:.0f}%")
        elif rg > 0.10:
            pts += 1.5; pros.append(f"Αύξηση εσόδων {rg*100:.0f}%")
        elif rg < 0:
            pts -= 2; cons.append(f"Πτώση εσόδων {rg*100:.0f}%")
    eg = _g(info, "earningsGrowth") or _g(info, "earningsQuarterlyGrowth")
    if eg is not None:
        used += 1
        if eg > 0.20:
            pts += 1.5; pros.append(f"Αύξηση κερδών {eg*100:.0f}%")
        elif eg < -0.2:
            pts -= 1.5; cons.append(f"Πτώση κερδών {eg*100:.0f}%")

    fpe, tpe = _g(info, "forwardPE"), _g(info, "trailingPE")
    eps = _g(info, "trailingEps")
    if eps is not None and eps < 0:
        cons.append("Ζημιογόνα εταιρεία (αρνητικό EPS)"); pts -= 1; flags.append("unprofitable")
    if fpe is not None and fpe > 0:
        used += 1
        peer_pe = (peers or {}).get("forwardPE")
        if peer_pe:
            rel = fpe / peer_pe
            if rel < 0.75:
                pts += 1.5; pros.append(f"Forward P/E {fpe:.1f} φθηνότερο από τον κλάδο ({peer_pe:.1f})")
                flags.append("cheap_vs_sector")
            elif rel > 1.6:
                pts -= 1; cons.append(f"Forward P/E {fpe:.1f} ακριβό έναντι κλάδου ({peer_pe:.1f})")
        else:
            if fpe < 15:
                pts += 1; pros.append(f"Χαμηλό forward P/E {fpe:.1f}")
            elif fpe > 60:
                pts -= 1; cons.append(f"Πολύ υψηλό forward P/E {fpe:.1f}")
        if tpe and fpe < tpe * 0.8:
            pros.append("Forward P/E αρκετά κάτω από το τρέχον: αναμένεται άνοδος κερδών")
            pts += 0.5

    de = _g(info, "debtToEquity")
    if de is not None:
        used += 1
        de_ratio = de / 100 if de > 10 else de  # Yahoo το δίνει συνήθως ×100
        if de_ratio > 2.5:
            pts -= 1.5; cons.append(f"Υψηλό χρέος (D/E {de_ratio:.1f})"); risks.append("Υψηλή μόχλευση")
        elif de_ratio < 0.5:
            pts += 1; pros.append(f"Χαμηλό χρέος (D/E {de_ratio:.2f})")

    fcf, ocf = _g(info, "freeCashflow"), _g(info, "operatingCashflow")
    cash = _g(info, "totalCash")
    if fcf is not None:
        used += 1
        if fcf > 0:
            pts += 1.5; pros.append("Θετικές ελεύθερες ταμειακές ροές")
        else:
            pts -= 1.5; cons.append("Αρνητικές ελεύθερες ταμειακές ροές (καίει μετρητά)")
            if cash is not None and fcf < 0 and cash < abs(fcf) * 1.0:
                risks.append("Μετρητά για < 12 μήνες με τον τρέχοντα ρυθμό: υψηλός κίνδυνος αύξησης κεφαλαίου")
                flags.append("cash_runway_short")

    om, roe = _g(info, "operatingMargins"), _g(info, "returnOnEquity")
    if om is not None:
        used += 1
        if om > 0.2:
            pts += 1; pros.append(f"Υψηλό λειτουργικό περιθώριο {om*100:.0f}%")
        elif om < -0.2:
            pts -= 1; cons.append(f"Αρνητικό λειτουργικό περιθώριο {om*100:.0f}%")
    if roe is not None and roe > 0.2:
        pts += 0.5

    inst = _g(info, "heldPercentInstitutions")
    if inst is not None:
        used += 1
        if inst > 0.6:
            pts += 0.5
        elif inst < 0.15:
            risks.append(f"Χαμηλή θεσμική συμμετοχή ({inst*100:.0f}%)")

    # Insiders (τελευταίοι 6 μήνες)
    ins = info.get("insiders") or []
    buys = sum(1 for i in ins if i.get("kind") == "buy")
    sells = sum(1 for i in ins if i.get("kind") == "sell")
    buy_val = sum((i.get("value") or 0) for i in ins if i.get("kind") == "buy")
    if buys >= 2 or buy_val > 500_000:
        pts += 2; pros.append(f"Insider αγορές: {buys} συναλλαγές (${buy_val/1e6:.1f}M)"); flags.append("insider_buying")
    elif sells >= 6 and buys == 0:
        pts -= 0.5; cons.append(f"Συνεχείς πωλήσεις insiders ({sells})")

    # Short interest
    si = _g(info, "shortPercentOfFloat")
    sr = _g(info, "shortRatio")
    if si is not None:
        if si > 0.20:
            flags.append("high_short_interest")
            risks.append(f"Πολύ υψηλό short interest {si*100:.0f}% του float (μεγάλη μεταβλητότητα, πιθανό squeeze)")
        elif si > 0.10:
            flags.append("elevated_short_interest")

    # Analysts
    tgt = _g(info, "targetMeanPrice")
    n_an = _g(info, "numberOfAnalystOpinions") or 0
    upside = None
    if tgt and price and n_an >= 3:
        upside = (tgt / price - 1) * 100
        if upside > 25:
            pts += 1; pros.append(f"Μέσος στόχος αναλυτών {upside:.0f}% πάνω ({int(n_an)} αναλυτές)")
        elif upside < -10:
            pts -= 1; cons.append(f"Η τιμή είναι {abs(upside):.0f}% πάνω από τον μέσο στόχο αναλυτών")
    acts = info.get("analyst_actions") or []
    ups = sum(1 for a in acts if "up" in a.get("action", "").lower())
    downs = sum(1 for a in acts if "down" in a.get("action", "").lower())
    if ups > downs:
        pts += 0.5 * min(ups - downs, 3); pros.append(f"{ups} αναβαθμίσεις αναλυτών τις τελευταίες 30 μέρες")
    elif downs > ups:
        pts -= 0.5 * min(downs - ups, 3); cons.append(f"{downs} υποβαθμίσεις αναλυτών τις τελευταίες 30 μέρες")

    # Dilution (SEC)
    dil = [f for f in (info.get("filings") or []) if f.get("kind") == "dilution"]
    if dil:
        flags.append("dilution_risk"); pts -= 2
        risks.append("Κίνδυνος dilution: πρόσφατο " + ", ".join(f"{f['form']} ({f['filed_at']})" for f in dil[:3]))
    if "cash_runway_short" in flags and "dilution_risk" not in flags:
        flags.append("dilution_risk")

    # Earnings
    ed = info.get("earnings_date")
    dd = days_until(ed)
    if dd is not None and 0 <= dd <= 10:
        flags.append("earnings_soon"); risks.append(f"Earnings στις {ed} (σε {dd} μέρες): κίνδυνος gap")

    raw = 50 + pts * 4.5
    score = 50 + (raw - 50) * min(1.0, coverage / 0.6)  # συρρίκνωση όταν λείπουν δεδομένα
    if coverage < 0.3:
        flags.append("low_fundamental_coverage")
    return {
        "ok": True, "score": round(float(np.clip(score, 0, 100)), 1), "coverage": round(coverage, 2),
        "pros": pros, "cons": cons, "risks": risks, "flags": flags,
        "metrics": {
            "market_cap": _g(info, "marketCap"), "shares_out": _g(info, "sharesOutstanding"),
            "float": _g(info, "floatShares"), "pe": tpe, "forward_pe": fpe, "peg": _g(info, "pegRatio"),
            "ps": _g(info, "priceToSalesTrailing12Months"), "eps": eps, "revenue_growth": rg, "earnings_growth": eg,
            "gross_margin": _g(info, "grossMargins"), "op_margin": om, "roe": roe, "debt_to_equity": de,
            "free_cash_flow": fcf, "operating_cash_flow": ocf, "cash": cash, "debt": _g(info, "totalDebt"),
            "inst_pct": inst, "insider_pct": _g(info, "heldPercentInsiders"), "short_pct_float": si,
            "short_ratio": sr, "target_mean": tgt, "analyst_upside_pct": upside, "n_analysts": n_an,
            "recommendation": info.get("recommendationKey"), "earnings_date": ed, "days_to_earnings": dd,
            "insider_buys_6m": buys, "insider_sells_6m": sells, "beta": _g(info, "beta"),
        },
    }


def sector_medians(rows: list[dict]) -> dict[str, dict]:
    """rows: [{sector, forwardPE, revenueGrowth, ...}] -> median ανά κλάδο."""
    by: dict[str, dict[str, list]] = {}
    for r in rows:
        s = r.get("sector")
        if not s:
            continue
        for k in ("forwardPE", "revenueGrowth", "operatingMargins", "priceToSalesTrailing12Months"):
            v = r.get(k)
            if isinstance(v, (int, float)) and v == v and (k != "forwardPE" or 0 < v < 300):
                by.setdefault(s, {}).setdefault(k, []).append(float(v))
    return {s: {k: float(np.median(v)) for k, v in d.items() if len(v) >= 3} for s, d in by.items()}
