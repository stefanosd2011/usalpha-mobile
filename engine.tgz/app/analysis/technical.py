"""Τεχνική εικόνα μιας μετοχής: συνδυασμός δεικτών (ποτέ ένας μόνος), flags, επίπεδα,
και δύο βαθμολογίες 0-100: technical και momentum/volume. 50 = ουδέτερο."""
from __future__ import annotations

import math

import numpy as np
import pandas as pd

from . import indicators as ind

MIN_BARS = 60


def _f(v, nd=4):
    try:
        v = float(v)
        return None if math.isnan(v) or math.isinf(v) else round(v, nd)
    except (TypeError, ValueError):
        return None


def _clip(x, lo=0.0, hi=100.0):
    return max(lo, min(hi, x))


def analyze(df: pd.DataFrame, bench: pd.DataFrame | None = None, with_levels: bool = True,
            precomputed: bool = False) -> dict:
    """df: OHLCV με lowercase στήλες (ή ήδη με δείκτες αν precomputed=True).
    Επιστρέφει dict με score, flags, pros/cons, metrics."""
    if df is None or len(df) < MIN_BARS:
        return {"ok": False, "reason": f"Ανεπαρκές ιστορικό ({0 if df is None else len(df)} bars, χρειάζονται {MIN_BARS})"}
    x = df if precomputed else ind.add_all(df)
    last = x.iloc[-1]
    prev = x.iloc[-2]
    c = float(last["close"])
    flags: list[str] = []
    pros: list[str] = []
    cons: list[str] = []
    pts = 0.0  # technical points

    # ---- Trend (EMA/SMA stack)
    trend_votes = 0
    for cond, txt in [
        (c > last["ema20"], "Τιμή πάνω από EMA20"),
        (last["ema20"] > last["ema50"], "EMA20 > EMA50"),
        (pd.notna(last["sma200"]) and c > last["sma200"], "Τιμή πάνω από SMA200"),
        (pd.notna(last["sma200"]) and last["sma50"] > last["sma200"], "SMA50 > SMA200"),
    ]:
        if pd.isna(cond):
            continue
        trend_votes += 1 if cond else -1
    if trend_votes >= 3:
        flags.append("trend_up"); pros.append("Ανοδική τάση σε όλους τους μέσους όρους"); pts += 3
    elif trend_votes <= -3:
        flags.append("trend_down"); cons.append("Καθοδική τάση σε όλους τους μέσους όρους"); pts -= 3
    else:
        pts += trend_votes * 0.5

    ema50_slope = (x["ema50"].iloc[-1] / x["ema50"].iloc[-11] - 1) * 100 if len(x) > 60 else 0
    # ---- Crosses
    gc = ind.recent_cross(x["sma50"], x["sma200"], 15)
    if gc == "up":
        flags.append("golden_cross"); pros.append("Golden Cross (SMA50 πάνω από SMA200) τις τελευταίες 15 μέρες"); pts += 1.5
    elif gc == "down":
        flags.append("death_cross"); cons.append("Death Cross τις τελευταίες 15 μέρες"); pts -= 1.5
    tc = ind.recent_cross(x["ema20"], x["ema50"], 5)
    if tc == "up":
        flags.append("trend_change_up"); pros.append("Πιθανή αλλαγή τάσης: EMA20 πέρασε πάνω από EMA50")
        pts += 1
    elif tc == "down":
        flags.append("trend_change_down"); cons.append("Πιθανή αλλαγή τάσης προς τα κάτω (EMA20 κάτω από EMA50)")
        pts -= 1

    # ---- Momentum: RSI / MACD / StochRSI
    r = float(last["rsi"]) if pd.notna(last["rsi"]) else 50
    if 50 <= r <= 70:
        pts += 1.5; pros.append(f"RSI {r:.0f}: υγιές momentum")
    elif r > 75:
        flags.append("overbought"); cons.append(f"RSI {r:.0f}: υπεραγορασμένη, κίνδυνος διόρθωσης"); pts -= 1.5
    elif r < 30:
        flags.append("oversold"); pros.append(f"RSI {r:.0f}: υπερπουλημένη (πιθανό αναπήδημα, όχι βεβαιότητα)"); pts += 0.5
    elif r < 45:
        cons.append(f"RSI {r:.0f}: αδύναμο momentum"); pts -= 1
    if pd.notna(last["macd_hist"]):
        if last["macd_hist"] > 0 and last["macd_hist"] > prev["macd_hist"]:
            pts += 1.5; pros.append("MACD θετικό και ανεβαίνει")
        elif last["macd_hist"] < 0 and last["macd_hist"] < prev["macd_hist"]:
            pts -= 1.5; cons.append("MACD αρνητικό και επιδεινώνεται")
        mc = ind.recent_cross(x["macd"], x["macd_sig"], 3)
        if mc == "up":
            flags.append("macd_cross_up")
        elif mc == "down":
            flags.append("macd_cross_down")
    if pd.notna(last["stoch_k"]):
        if last["stoch_k"] < 20 and last["stoch_k"] > last["stoch_d"]:
            pts += 0.5; pros.append("Stoch RSI γυρίζει από υπερπουλημένη ζώνη")
        elif last["stoch_k"] > 80 and last["stoch_k"] < last["stoch_d"]:
            pts -= 0.5; cons.append("Stoch RSI γυρίζει από υπεραγορασμένη ζώνη")

    # ---- ADX
    a = float(last["adx"]) if pd.notna(last["adx"]) else 0
    if a >= 25:
        if last["pdi"] > last["mdi"]:
            pts += 1; pros.append(f"ADX {a:.0f}: ισχυρή ανοδική τάση")
        else:
            pts -= 1; cons.append(f"ADX {a:.0f}: ισχυρή καθοδική τάση")
    elif a < 18:
        flags.append("no_trend")

    # ---- Bollinger squeeze
    if len(x) > 130 and pd.notna(last["bb_width"]):
        if last["bb_width"] <= x["bb_width"].tail(126).quantile(0.1):
            flags.append("squeeze"); pros.append("Bollinger squeeze: συμπίεση μεταβλητότητας, πιθανή έντονη κίνηση (κατεύθυνση άγνωστη)")

    # ---- Breakout / fakeout
    rv = float(last["rvol"]) if pd.notna(last["rvol"]) else None
    if pd.notna(last["hi20"]) and c > last["hi20"]:
        if rv and rv >= 1.5:
            flags.append("breakout_20"); pros.append(f"Breakout πάνω από υψηλό 20 ημερών με όγκο {rv:.1f}x"); pts += 2
        else:
            flags.append("weak_breakout"); cons.append("Breakout χωρίς επιβεβαίωση όγκου")
    if pd.notna(last["hi55"]) and c > last["hi55"] and rv and rv >= 1.3:
        flags.append("breakout_55"); pts += 1
    recent = x.tail(6).iloc[:-1]
    if ((recent["close"] > recent["hi20"]).any()) and pd.notna(last["hi20"]) and c < last["hi20"] * 0.99:
        flags.append("fakeout"); cons.append("Πιθανό fakeout: έσπασε το υψηλό 20 ημερών αλλά επέστρεψε κάτω"); pts -= 2
    if pd.notna(last["lo20"]) and c < last["lo20"]:
        flags.append("breakdown_20"); cons.append("Σπάσιμο κάτω από χαμηλό 20 ημερών"); pts -= 2

    # ---- Divergences
    for dv in ind.divergences(x):
        if dv["type"] == "bullish":
            flags.append("bull_div"); pros.append(dv["text"]); pts += 1.5
        else:
            flags.append("bear_div"); cons.append(dv["text"]); pts -= 1.5

    # ---- VWAP
    if pd.notna(last["vwap20"]):
        if c > last["vwap20"]:
            pts += 0.5
        else:
            pts -= 0.5

    technical_score = _clip(50 + pts * 4.5)

    # ================= Momentum & Volume score =================
    mp = 0.0
    ret21, ret63 = _f(last["ret21"] * 100, 2), _f(last["ret63"] * 100, 2)
    rs = ind.relative_strength(x, bench) if bench is not None else None
    if rs:
        mp += np.clip(rs["excess"] / 5, -3, 3)
        if rs["rs_new_high"]:
            mp += 1; pros.append("Relative strength vs S&P 500 σε νέο υψηλό 6 μηνών")
        if rs["excess"] > 10:
            pros.append(f"Υπεραπόδοση {rs['excess']:.0f}% έναντι S&P 500 (3 μήνες)")
        elif rs["excess"] < -10:
            cons.append(f"Υστέρηση {abs(rs['excess']):.0f}% έναντι S&P 500 (3 μήνες)")
    if ret21 is not None:
        mp += np.clip(ret21 / 6, -2, 2)
    if rv is not None:
        if rv >= 2:
            flags.append("unusual_volume")
            if last["ret1"] > 0:
                mp += 2; pros.append(f"Ασυνήθιστος όγκος {rv:.1f}x με άνοδο (συσσώρευση)")
            else:
                mp -= 2; cons.append(f"Ασυνήθιστος όγκος {rv:.1f}x με πτώση (διανομή)")
    t20 = x.tail(20)
    upv = t20.loc[t20["ret1"] > 0, "volume"].sum()
    dnv = t20.loc[t20["ret1"] < 0, "volume"].sum()
    if dnv > 0:
        ud = upv / dnv
        mp += np.clip((ud - 1) * 2, -2, 2)
    else:
        ud = None
    near_high = pd.notna(last["hi252"]) and c >= last["hi252"] * 0.95
    near_low = pd.notna(last["lo252"]) and c <= last["lo252"] * 1.05
    if near_high:
        flags.append("near_52w_high"); mp += 1
    if near_low:
        flags.append("near_52w_low"); mp -= 1
    momentum_score = _clip(50 + mp * 6)

    out = {
        "ok": True,
        "technical_score": round(technical_score, 1),
        "momentum_score": round(momentum_score, 1),
        "flags": sorted(set(flags)),
        "pros": pros, "cons": cons,
        "metrics": {
            "close": _f(c), "change_pct": _f(last["ret1"] * 100, 2), "rsi": _f(r, 1), "adx": _f(a, 1),
            "macd": _f(last["macd"]), "macd_signal": _f(last["macd_sig"]), "macd_hist": _f(last["macd_hist"]),
            "stoch_k": _f(last["stoch_k"], 1), "stoch_d": _f(last["stoch_d"], 1),
            "ema9": _f(last["ema9"]), "ema20": _f(last["ema20"]), "ema50": _f(last["ema50"]), "ema200": _f(last["ema200"]),
            "sma20": _f(last["sma20"]), "sma50": _f(last["sma50"]), "sma100": _f(last["sma100"]), "sma200": _f(last["sma200"]),
            "bb_up": _f(last["bb_up"]), "bb_lo": _f(last["bb_lo"]), "bb_width": _f(last["bb_width"]),
            "vwap20": _f(last["vwap20"]), "atr": _f(last["atr"]), "atr_pct": _f(last["atr_pct"], 2),
            "rvol": _f(rv, 2), "avg_volume20": _f(last["vol_avg20"], 0), "dollar_vol20": _f(last["dollar_vol20"], 0),
            "hi52": _f(last["hi252"]), "lo52": _f(last["lo252"]), "ret5": _f(last["ret5"] * 100, 2),
            "ret21": ret21, "ret63": ret63, "ret126": _f(last["ret126"] * 100, 2),
            "volatility21": _f(last["vol21"], 1), "gap_pct": _f(last["gap"] * 100, 2),
            "ema50_slope10": _f(ema50_slope, 2), "updown_vol_ratio": _f(ud, 2),
            "rs": rs,
        },
        "as_of": str(x.index[-1].date()),
    }
    if with_levels:
        out["levels"] = ind.support_resistance(x)
        out["fibonacci"] = ind.fibonacci(x)
        out["volume_profile"] = ind.volume_profile(x)
    return out


def chart_series(df: pd.DataFrame, bars: int = 400) -> dict:
    """Σειρές για τα charts του UI (lightweight-charts format)."""
    x = ind.add_all(df).tail(bars)
    t = [d.strftime("%Y-%m-%d") for d in x.index]

    def line(col):
        return [{"time": ti, "value": round(float(v), 4)} for ti, v in zip(t, x[col]) if pd.notna(v)]

    return {
        "candles": [{"time": ti, "open": round(float(o), 4), "high": round(float(h), 4),
                     "low": round(float(l), 4), "close": round(float(c), 4)}
                    for ti, o, h, l, c in zip(t, x["open"], x["high"], x["low"], x["close"])],
        "volume": [{"time": ti, "value": float(v or 0), "up": bool(c >= o)}
                   for ti, v, c, o in zip(t, x["volume"], x["close"], x["open"])],
        "ema9": line("ema9"), "ema20": line("ema20"), "ema50": line("ema50"), "ema200": line("ema200"),
        "sma20": line("sma20"), "sma50": line("sma50"), "sma100": line("sma100"), "sma200": line("sma200"),
        "bb_up": line("bb_up"), "bb_lo": line("bb_lo"), "vwap20": line("vwap20"),
        "rsi": line("rsi"), "macd": line("macd"), "macd_sig": line("macd_sig"), "macd_hist": line("macd_hist"),
        "adx": line("adx"), "stoch_k": line("stoch_k"), "stoch_d": line("stoch_d"), "atr": line("atr"),
    }
