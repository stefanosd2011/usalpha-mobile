"""Συνθήκες αγοράς (regime) και δύναμη κλάδων."""
from __future__ import annotations

import math

import pandas as pd

from .. import db
from ..data.universe import SECTOR_ETF, THEME_ETF
from . import indicators as ind


def _last(df: pd.DataFrame, col: str = "close"):
    return float(df[col].iloc[-1]) if not df.empty else None


def _ret(df: pd.DataFrame, n: int):
    if len(df) <= n:
        return None
    return (float(df["close"].iloc[-1]) / float(df["close"].iloc[-n - 1]) - 1) * 100


def market_conditions(breadth_pct50: float | None = None) -> dict:
    spy = db.load_prices("SPY")
    if len(spy) < 210:
        return {"ok": False, "score": 50.0, "regime": "Άγνωστο", "reason": "Λείπει ιστορικό SPY",
                "pros": [], "cons": []}
    x = ind.add_all(spy)
    last = x.iloc[-1]
    pts, pros, cons = 0.0, [], []
    if last["close"] > last["sma200"]:
        pts += 2; pros.append("S&P 500 πάνω από SMA200 (μακροπρόθεσμη ανοδική τάση)")
    else:
        pts -= 2; cons.append("S&P 500 κάτω από SMA200")
    if last["close"] > last["sma50"]:
        pts += 1
    else:
        pts -= 1; cons.append("S&P 500 κάτω από SMA50")
    vix = db.load_prices("^VIX")
    vix_last = _last(vix)
    if vix_last is not None:
        if vix_last < 16:
            pts += 1; pros.append(f"VIX {vix_last:.1f}: χαμηλός φόβος")
        elif vix_last > 30:
            pts -= 2.5; cons.append(f"VIX {vix_last:.1f}: πανικός / υψηλός κίνδυνος")
        elif vix_last > 22:
            pts -= 1; cons.append(f"VIX {vix_last:.1f}: αυξημένη νευρικότητα")
    if breadth_pct50 is not None:
        if breadth_pct50 > 60:
            pts += 1; pros.append(f"Ευρεία συμμετοχή: {breadth_pct50:.0f}% των μετοχών πάνω από SMA50")
        elif breadth_pct50 < 35:
            pts -= 1; cons.append(f"Στενή αγορά: μόνο {breadth_pct50:.0f}% πάνω από SMA50")
    iwm, qqq = db.load_prices("IWM"), db.load_prices("QQQ")
    tnx, oil = db.load_prices("^TNX"), db.load_prices("CL=F")
    score = max(0.0, min(100.0, 50 + pts * 8))
    regime = "Risk-on" if score >= 62 else ("Risk-off" if score <= 38 else "Ουδέτερο")
    return {
        "ok": True, "score": round(score, 1), "regime": regime, "pros": pros, "cons": cons,
        "spy": {"close": _last(spy), "ret1": _ret(spy, 1), "ret21": _ret(spy, 21), "above200": bool(last["close"] > last["sma200"])},
        "qqq": {"close": _last(qqq), "ret1": _ret(qqq, 1), "ret21": _ret(qqq, 21)},
        "iwm": {"close": _last(iwm), "ret1": _ret(iwm, 1), "ret21": _ret(iwm, 21)},
        "vix": vix_last, "vix_ret1": _ret(vix, 1),
        "tnx": (_last(tnx) / 10 if tnx is not None and not tnx.empty and _last(tnx) > 20 else _last(tnx)),
        "oil": _last(oil), "breadth_pct50": breadth_pct50,
        "as_of": str(spy.index[-1].date()),
    }


def sector_strength(member_scores: dict[str, list[float]] | None = None) -> list[dict]:
    """Κατάταξη κλάδων: απόδοση ETF έναντι SPY (1/3 μήνες) + τάση + μέση τεχνική βαθμολογία μελών."""
    spy = db.load_prices("SPY")
    out = []
    for sector, etf in {**SECTOR_ETF, **{f"Θέμα: {k}": v for k, v in THEME_ETF.items()}}.items():
        df = db.load_prices(etf)
        if len(df) < 70 or spy.empty:
            continue
        r21, r63 = _ret(df, 21), _ret(df, 63)
        s21, s63 = _ret(spy, 21), _ret(spy, 63)
        x = ind.add_all(df)
        trend = 1 if x["close"].iloc[-1] > x["sma50"].iloc[-1] else -1
        rel = (r21 - s21) * 0.6 + (r63 - s63) * 0.4 if None not in (r21, r63, s21, s63) else 0
        members = (member_scores or {}).get(sector) or []
        mavg = sum(members) / len(members) if members else None
        score = 50 + math.tanh(rel / 6) * 30 + trend * 8 + ((mavg - 50) * 0.3 if mavg else 0)
        out.append({"sector": sector, "etf": etf, "ret1": _ret(df, 1), "ret5": _ret(df, 5), "ret21": r21, "ret63": r63,
                    "rel21": None if r21 is None or s21 is None else r21 - s21,
                    "above_sma50": trend > 0, "members": len(members),
                    "members_avg_score": round(mavg, 1) if mavg else None,
                    "score": round(max(0, min(100, score)), 1)})
    out.sort(key=lambda r: r["score"], reverse=True)
    for i, r in enumerate(out):
        r["rank"] = i + 1
    return out


def sector_score_for(sector: str | None, table: list[dict]) -> float:
    for r in table:
        if r["sector"] == sector:
            return r["score"]
    return 50.0
