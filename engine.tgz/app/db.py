"""SQLite αποθήκευση με indexes. Thread-safe μέσω μιας σύνδεσης ανά thread + WAL."""
from __future__ import annotations

import json
import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Any, Iterable

import pandas as pd

from .config import settings

_local = threading.local()
_write_lock = threading.RLock()

SCHEMA = """
CREATE TABLE IF NOT EXISTS prices_daily (
    ticker TEXT NOT NULL, date TEXT NOT NULL,
    open REAL, high REAL, low REAL, close REAL, adj_close REAL, volume REAL,
    PRIMARY KEY (ticker, date)
);
CREATE INDEX IF NOT EXISTS ix_prices_date ON prices_daily(date);

CREATE TABLE IF NOT EXISTS quotes (
    ticker TEXT PRIMARY KEY, price REAL, prev_close REAL, change_pct REAL,
    volume REAL, bid REAL, ask REAL, pre_price REAL, post_price REAL,
    day_high REAL, day_low REAL, day_open REAL,
    source TEXT, quality TEXT, as_of TEXT, fetched_at TEXT
);

CREATE TABLE IF NOT EXISTS company (
    ticker TEXT PRIMARY KEY, name TEXT, sector TEXT, industry TEXT,
    data_json TEXT, fetched_at TEXT
);
CREATE INDEX IF NOT EXISTS ix_company_sector ON company(sector);

CREATE TABLE IF NOT EXISTS news (
    id TEXT PRIMARY KEY, cluster_id TEXT, ticker TEXT, title TEXT, summary TEXT,
    url TEXT, source TEXT, published_at TEXT, fetched_at TEXT,
    category TEXT, sentiment REAL, credibility REAL, importance REAL,
    horizon TEXT, priced_in TEXT, impact REAL, ai_json TEXT, is_primary INTEGER DEFAULT 1
);
CREATE INDEX IF NOT EXISTS ix_news_ticker ON news(ticker, published_at);
CREATE INDEX IF NOT EXISTS ix_news_pub ON news(published_at);
CREATE INDEX IF NOT EXISTS ix_news_cluster ON news(cluster_id);

CREATE TABLE IF NOT EXISTS filings (
    accession TEXT PRIMARY KEY, ticker TEXT, form TEXT, filed_at TEXT, url TEXT, description TEXT
);
CREATE INDEX IF NOT EXISTS ix_filings_ticker ON filings(ticker, filed_at);

CREATE TABLE IF NOT EXISTS scores (
    ticker TEXT NOT NULL, date TEXT NOT NULL, score REAL, components_json TEXT,
    explain_json TEXT, calibrated_prob REAL, created_at TEXT,
    PRIMARY KEY (ticker, date)
);
CREATE INDEX IF NOT EXISTS ix_scores_date ON scores(date, score);

CREATE TABLE IF NOT EXISTS scan_results (
    run_id TEXT, ticker TEXT, categories TEXT, metrics_json TEXT, score REAL,
    PRIMARY KEY (run_id, ticker)
);
CREATE TABLE IF NOT EXISTS scan_runs (
    run_id TEXT PRIMARY KEY, started_at TEXT, finished_at TEXT, n_tickers INTEGER,
    n_ok INTEGER, status TEXT, notes TEXT
);

CREATE TABLE IF NOT EXISTS signals (
    id INTEGER PRIMARY KEY AUTOINCREMENT, ticker TEXT, horizon TEXT, bias TEXT,
    created_at TEXT, price REAL, entry_low REAL, entry_high REAL, stop REAL,
    tp1 REAL, tp2 REAL, tp3 REAL, rr REAL, holding TEXT, score REAL,
    confidence TEXT, confirmations INTEGER, checks_passed INTEGER,
    catalysts_json TEXT, risks_json TEXT, conflicts_json TEXT, status TEXT,
    last_check_at TEXT, closed_at TEXT, outcome TEXT, outcome_return REAL,
    history_json TEXT
);
CREATE INDEX IF NOT EXISTS ix_signals_status ON signals(status, ticker);

CREATE TABLE IF NOT EXISTS predictions (
    id INTEGER PRIMARY KEY AUTOINCREMENT, ticker TEXT, made_at TEXT, horizon_days INTEGER,
    score REAL, prob REAL, price REAL, target_date TEXT,
    resolved INTEGER DEFAULT 0, realized_return REAL, hit INTEGER
);
CREATE INDEX IF NOT EXISTS ix_pred_resolved ON predictions(resolved, target_date);

CREATE TABLE IF NOT EXISTS paper_trades (
    id INTEGER PRIMARY KEY AUTOINCREMENT, ticker TEXT, side TEXT, qty REAL,
    entry REAL, stop REAL, target REAL, opened_at TEXT, closed_at TEXT,
    exit REAL, pnl REAL, status TEXT, signal_id INTEGER, note TEXT
);

CREATE TABLE IF NOT EXISTS watchlist (ticker TEXT PRIMARY KEY, added_at TEXT);

CREATE TABLE IF NOT EXISTS alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT, ticker TEXT, kind TEXT,
    severity TEXT, message TEXT, dedup_key TEXT UNIQUE, seen INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS ix_alerts_created ON alerts(created_at);

CREATE TABLE IF NOT EXISTS reports (
    date TEXT PRIMARY KEY, created_at TEXT, json TEXT
);

CREATE TABLE IF NOT EXISTS backtests (
    id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT, name TEXT, params_json TEXT,
    metrics_json TEXT, equity_json TEXT, trades_json TEXT
);

CREATE TABLE IF NOT EXISTS calibration (
    horizon TEXT PRIMARY KEY, created_at TEXT, table_json TEXT, n_samples INTEGER, brier REAL
);

CREATE TABLE IF NOT EXISTS ai_usage (
    id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT, provider TEXT, model TEXT, purpose TEXT,
    input_tokens INTEGER, output_tokens INTEGER, cost_usd REAL, ok INTEGER, error TEXT
);

CREATE TABLE IF NOT EXISTS api_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT, provider TEXT, endpoint TEXT,
    ok INTEGER, ms REAL, error TEXT
);
CREATE INDEX IF NOT EXISTS ix_apilog_at ON api_log(at);

CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY, value TEXT, updated_at TEXT);

CREATE TABLE IF NOT EXISTS universe (
    ticker TEXT PRIMARY KEY, name TEXT, exchange TEXT, market_cap REAL, price REAL, avg_volume REAL,
    dollar_volume REAL, source TEXT, updated_at TEXT, active INTEGER DEFAULT 1, fail_count INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS ix_universe_dv ON universe(active, dollar_volume);

CREATE TABLE IF NOT EXISTS snapshot (
    ticker TEXT PRIMARY KEY, data_json TEXT, as_of TEXT
);

CREATE TABLE IF NOT EXISTS ml_models (
    horizon TEXT PRIMARY KEY, created_at TEXT, path TEXT, validated INTEGER, metrics_json TEXT,
    calib_json TEXT, features_json TEXT, importance_json TEXT, n_train INTEGER, data_end TEXT
);

CREATE TABLE IF NOT EXISTS ml_predictions (
    ticker TEXT NOT NULL, date TEXT NOT NULL, horizon TEXT NOT NULL, p REAL, p_raw REAL, rank_pct REAL,
    exp_r REAL, created_at TEXT, PRIMARY KEY (ticker, date, horizon)
);
CREATE INDEX IF NOT EXISTS ix_mlpred_date ON ml_predictions(date, horizon, p);
"""


def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def conn() -> sqlite3.Connection:
    c = getattr(_local, "conn", None)
    if c is None:
        c = sqlite3.connect(settings.db_path, timeout=30, check_same_thread=False)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA journal_mode=WAL")
        c.execute("PRAGMA synchronous=NORMAL")
        _local.conn = c
    return c


def init_db() -> None:
    with _write_lock:
        conn().executescript(SCHEMA)
        for sql in MIGRATIONS:
            try:
                conn().execute(sql)
            except sqlite3.OperationalError:
                pass  # ήδη εφαρμοσμένο
        conn().commit()


MIGRATIONS = [
    "ALTER TABLE quotes ADD COLUMN day_open REAL",
    "ALTER TABLE signals ADD COLUMN setup TEXT",
    "ALTER TABLE signals ADD COLUMN ml_p REAL",
    "ALTER TABLE signals ADD COLUMN ml_exp_r REAL",
    "ALTER TABLE signals ADD COLUMN rank_pct REAL",
]


@contextmanager
def tx():
    with _write_lock:
        c = conn()
        try:
            yield c
            c.commit()
        except Exception:
            c.rollback()
            raise


def q(sql: str, params: Iterable[Any] = ()) -> list[dict]:
    return [dict(r) for r in conn().execute(sql, tuple(params)).fetchall()]


def q1(sql: str, params: Iterable[Any] = ()) -> dict | None:
    r = conn().execute(sql, tuple(params)).fetchone()
    return dict(r) if r else None


def execute(sql: str, params: Iterable[Any] = ()) -> int:
    with tx() as c:
        cur = c.execute(sql, tuple(params))
        return cur.lastrowid


def executemany(sql: str, rows: list[tuple]) -> None:
    if not rows:
        return
    with tx() as c:
        c.executemany(sql, rows)


# ---------- KV ----------
def kv_get(key: str, default: Any = None) -> Any:
    r = q1("SELECT value FROM kv WHERE key=?", (key,))
    if not r:
        return default
    try:
        return json.loads(r["value"])
    except Exception:
        return r["value"]


def kv_set(key: str, value: Any) -> None:
    execute(
        "INSERT INTO kv(key,value,updated_at) VALUES(?,?,?) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at",
        (key, json.dumps(value, default=str), now_iso()),
    )


# ---------- Prices ----------
def save_prices(ticker: str, df: pd.DataFrame) -> int:
    if df is None or df.empty:
        return 0
    d = df.dropna(subset=[c for c in ("Open", "High", "Low", "Close") if c in df.columns])
    if d.empty:
        return 0
    n = len(d)
    dates = pd.DatetimeIndex(d.index).strftime("%Y-%m-%d").tolist()

    def col(name, alt=None):
        s = d[name] if name in d.columns else (d[alt] if alt and alt in d.columns else pd.Series([None] * n, index=d.index))
        return [None if v is None or v != v else float(v) for v in s.tolist()]

    rows = list(zip([ticker] * n, dates, col("Open"), col("High"), col("Low"), col("Close"),
                    col("Adj Close", "Close"), col("Volume")))
    executemany(
        "INSERT INTO prices_daily(ticker,date,open,high,low,close,adj_close,volume) VALUES(?,?,?,?,?,?,?,?) "
        "ON CONFLICT(ticker,date) DO UPDATE SET open=excluded.open, high=excluded.high, low=excluded.low, "
        "close=excluded.close, adj_close=excluded.adj_close, volume=excluded.volume",
        rows,
    )
    return len(rows)


def load_prices(ticker: str, start: str | None = None) -> pd.DataFrame:
    sql = "SELECT date,open,high,low,close,adj_close,volume FROM prices_daily WHERE ticker=?"
    params: list = [ticker]
    if start:
        sql += " AND date>=?"
        params.append(start)
    sql += " ORDER BY date"
    rows = q(sql, params)
    if not rows:
        return pd.DataFrame(columns=["open", "high", "low", "close", "adj_close", "volume"])
    df = pd.DataFrame(rows)
    df["date"] = pd.to_datetime(df["date"])
    return df.set_index("date")


def last_price_date(ticker: str) -> str | None:
    r = q1("SELECT MAX(date) d FROM prices_daily WHERE ticker=?", (ticker,))
    return r["d"] if r else None


def log_api(provider: str, endpoint: str, ok: bool, ms: float, error: str = "") -> None:
    try:
        execute("INSERT INTO api_log(at,provider,endpoint,ok,ms,error) VALUES(?,?,?,?,?,?)",
                (now_iso(), provider, endpoint[:200], int(ok), round(ms, 1), (error or "")[:300]))
    except Exception:
        pass
