"""Μοντέλο πρόβλεψης v4 — εκπαιδεύεται ΔΙΠΛΑ στο v3 και δεν το αντικαθιστά χωρίς απόδειξη.

Τι προσθέτει σε σχέση με το v3:
  • ~80 νέα στοιχεία ανά μετοχή και ημέρα: beta και «καθαρό» momentum (χωρίς την κίνηση της αγοράς),
    ιδιοσυγκρατική μεταβλητότητα, ασυμμετρία, νυχτερινές και ημερήσιες αποδόσεις, ρευστότητα (Amihud),
    εποχικότητα (η ίδια περίοδος τα προηγούμενα χρόνια), momentum 12-1, ημερολόγιο, μακρο (επιτόκια,
    καμπύλη, δολάριο, πετρέλαιο, ομόλογα, χρυσός, πιστωτικός κίνδυνος, μικρές vs μεγάλες, Nasdaq vs αγορά),
    σύγκριση με κλάδο ΚΑΙ βιομηχανία, κατατάξεις μέσα στον κλάδο.
  • Πυκνότερο δείγμα ημερών (περισσότερα δεδομένα εκπαίδευσης).
  • Κατάταξη: στόχος προσαρμοσμένος στη μεταβλητότητα και συνδυασμός δύο μοντέλων (παλινδρόμηση + LambdaRank).
  • Δίκαιη σύγκριση: στις ΙΔΙΕΣ περιόδους ελέγχου και στις ΙΔΙΕΣ γραμμές εκπαιδεύεται ξανά και το v3,
    ώστε το «πριν / μετά» να είναι μετρημένο και όχι υπόσχεση.

Ενεργοποίηση: ένας ορίζοντας του v4 επηρεάζει score/signals ΜΟΝΟ αν (α) περάσει τον ίδιο αυστηρό έλεγχο με
το v3 και (β) είναι καλύτερος από το v3 στο ίδιο out-of-sample. Αλλιώς φαίνεται μόνο ως πληροφορία.
Το v3 (model.py) δεν αλλάζει σε τίποτα.
"""
from __future__ import annotations

import gc
import json
import logging
import math
import os
import time

import numpy as np
import pandas as pd

from .. import db
from ..config import DATA_DIR, settings
from . import features as F
from . import model as M3

log = logging.getLogger("usalpha.ml4")
VERSION = "v4"
MODEL_DIR = DATA_DIR / "models"
TARGET_ROWS = int(os.environ.get("ML4_TARGET_ROWS", 1_600_000))
MAX_TRAIN_ROWS = int(os.environ.get("ML4_MAX_TRAIN_ROWS", 1_200_000))
# σειρά προτεραιότητας: αν δεν φτάνει ο χρόνος, εκπαιδεύονται πρώτα οι πιο χρήσιμοι ορίζοντες
ORDER = ["rank21", "rank5", "short", "day", "swing"]

SCHEMA = """
CREATE TABLE IF NOT EXISTS ml4_models (
    horizon TEXT PRIMARY KEY, created_at TEXT, path TEXT, validated INTEGER, active INTEGER,
    metrics_json TEXT, baseline_json TEXT, compare_json TEXT, calib_json TEXT, importance_json TEXT,
    n_train INTEGER, data_end TEXT
);
CREATE TABLE IF NOT EXISTS ml4_predictions (
    ticker TEXT NOT NULL, date TEXT NOT NULL, horizon TEXT NOT NULL, p REAL, rank_pct REAL, exp_r REAL,
    created_at TEXT, PRIMARY KEY (ticker, date, horizon)
);
CREATE INDEX IF NOT EXISTS ix_ml4pred_date ON ml4_predictions(date, horizon);
"""

# ------------------------------------------------------------------ νέα χαρακτηριστικά
EXTRA_TICKER = [
    "beta_63", "beta_252", "res_ret_5", "res_ret_21", "res_ret_63", "res_ret_126", "res_mom_12_1", "mom_12_1",
    "ivol_21", "ivol_63", "ivol_ratio", "skew_63", "kurt_63", "downvol_21", "updown_vol",
    "overnight_5", "overnight_21", "intraday_5", "intraday_21", "amihud_21", "dvol_chg",
    "max_ret_5", "min_ret_5", "ret_1_lag1", "dist_lo52", "seas_5", "seas_21", "hl_vol_21", "close_to_high_5",
    "dow", "dom", "month", "tom",
]
MACRO = ["m_tnx", "m_tnx_chg_21", "m_curve", "m_dxy_ret_21", "m_oil_ret_21", "m_qqq_spy_21", "m_iwm_spy_21",
         "m_tlt_ret_21", "m_gld_ret_21", "m_credit_21", "m_spy_vol_21", "m_spy_dd", "m_spy_ret_1", "m_vix_pct"]
GROUP_REL = ["ind_rel_5", "ind_rel_21", "ind_rel_63", "ind_mom_rank", "sec4_rel_21", "sec4_rel_63", "sec4_mom_rank"]
CS_EXTRA = ["beta_252", "res_ret_21", "res_ret_63", "res_ret_126", "res_mom_12_1", "mom_12_1", "ivol_63", "skew_63",
            "overnight_21", "intraday_21", "amihud_21", "dvol_chg", "max_ret_5", "seas_5", "seas_21", "dist_lo52"]
SN_SOURCES = ["ret_5", "ret_21", "ret_63", "res_ret_21", "res_ret_63", "mom_12_1", "ivol_63", "rvol", "dist_hi52",
              "f_earn_yield", "f_book_yield", "f_rev_growth", "f_roe"]
NEW_FEATURES = (EXTRA_TICKER + MACRO + GROUP_REL + [f"cs_{c}" for c in CS_EXTRA] + [f"sn_{c}" for c in SN_SOURCES])
FEATURES_V4 = F.FEATURES + NEW_FEATURES

LABELS = {
    "beta_63": "Beta 3μ (ευαισθησία στην αγορά)", "beta_252": "Beta 1 έτους", "res_ret_5": "Καθαρή απόδοση 1 εβδ. (χωρίς αγορά)",
    "res_ret_21": "Καθαρή απόδοση 1μ (χωρίς αγορά)", "res_ret_63": "Καθαρή απόδοση 3μ (χωρίς αγορά)",
    "res_ret_126": "Καθαρή απόδοση 6μ (χωρίς αγορά)", "res_mom_12_1": "Καθαρό momentum 12-1 μηνών",
    "mom_12_1": "Momentum 12-1 μηνών", "ivol_21": "Ιδιοσυγκρατική μεταβλητότητα 1μ", "ivol_63": "Ιδιοσυγκρατική μεταβλητότητα 3μ",
    "ivol_ratio": "Αλλαγή ιδιοσυγκρατικής μεταβλητότητας", "skew_63": "Ασυμμετρία αποδόσεων 3μ", "kurt_63": "Ακραίες κινήσεις 3μ",
    "downvol_21": "Μεταβλητότητα πτώσεων 1μ", "updown_vol": "Μεταβλητότητα ανόδων vs πτώσεων",
    "overnight_5": "Νυχτερινές αποδόσεις 1 εβδ.", "overnight_21": "Νυχτερινές αποδόσεις 1μ",
    "intraday_5": "Αποδόσεις μέσα στη μέρα 1 εβδ.", "intraday_21": "Αποδόσεις μέσα στη μέρα 1μ",
    "amihud_21": "Αδυναμία ρευστότητας (Amihud)", "dvol_chg": "Αλλαγή τζίρου (1 εβδ. vs 3μ)",
    "max_ret_5": "Μέγιστη ημερ. άνοδος 1 εβδ.", "min_ret_5": "Μέγιστη ημερ. πτώση 1 εβδ.", "ret_1_lag1": "Απόδοση προχθές",
    "dist_lo52": "Απόσταση από χαμηλό 52 εβδ.", "seas_5": "Εποχικότητα: ίδια εβδομάδα τα προηγ. χρόνια",
    "seas_21": "Εποχικότητα: ίδιος μήνας τα προηγ. χρόνια", "hl_vol_21": "Εύρος ημέρας (μέσος 1μ)",
    "close_to_high_5": "Κλείσιμο vs υψηλό εβδομάδας", "dow": "Ημέρα εβδομάδας", "dom": "Ημέρα μήνα", "month": "Μήνας",
    "tom": "Αλλαγή μήνα (τελευταίες/πρώτες μέρες)",
    "m_tnx": "Επιτόκιο 10ετούς", "m_tnx_chg_21": "Μεταβολή επιτοκίου 10ετούς 1μ", "m_curve": "Καμπύλη επιτοκίων (10ετές − 3μηνο)",
    "m_dxy_ret_21": "Δολάριο 1μ", "m_oil_ret_21": "Πετρέλαιο 1μ", "m_qqq_spy_21": "Nasdaq vs S&P 1μ",
    "m_iwm_spy_21": "Μικρές vs μεγάλες εταιρείες 1μ", "m_tlt_ret_21": "Μακροπρόθεσμα ομόλογα 1μ", "m_gld_ret_21": "Χρυσός 1μ",
    "m_credit_21": "Πιστωτικός κίνδυνος (HYG vs LQD) 1μ", "m_spy_vol_21": "Μεταβλητότητα αγοράς 1μ",
    "m_spy_dd": "Πτώση αγοράς από το υψηλό έτους", "m_spy_ret_1": "Κίνηση αγοράς χθες", "m_vix_pct": "VIX σε σχέση με το έτος",
    "ind_rel_5": "Απόδοση vs βιομηχανία 1 εβδ.", "ind_rel_21": "Απόδοση vs βιομηχανία 1μ", "ind_rel_63": "Απόδοση vs βιομηχανία 3μ",
    "ind_mom_rank": "Δύναμη βιομηχανίας", "sec4_rel_21": "Απόδοση vs κλάδος 1μ", "sec4_rel_63": "Απόδοση vs κλάδος 3μ",
    "sec4_mom_rank": "Δύναμη κλάδου (όλες οι μετοχές)",
}
LABELS.update({f"cs_{c}": "Κατάταξη στην αγορά: " + LABELS.get(c, c) for c in CS_EXTRA})
LABELS.update({f"sn_{c}": "Κατάταξη μέσα στον κλάδο: " + (LABELS.get(c) or F.FEATURE_LABELS.get(c, c)) for c in SN_SOURCES})

_progress = {"running": False, "step": "", "pct": 0, "started_at": None, "error": None, "horizon": None}
_cache: dict = {}


def label(feat: str) -> str:
    return LABELS.get(feat) or F.FEATURE_LABELS.get(feat, feat)


def progress() -> dict:
    return dict(_progress)


def _step(msg: str, pct: float | None = None) -> None:
    _progress["step"] = msg
    if pct is not None:
        _progress["pct"] = round(pct, 1)
    log.info("ML4: %s", msg)


def init() -> None:
    db.conn().executescript(SCHEMA)
    db.conn().commit()


def extra_ticker_features(d: pd.DataFrame, spy_close: pd.Series) -> pd.DataFrame:
    """d: open/high/low/close/volume με index ημερομηνίες. Κάθε τιμή στη γραμμή t χρησιμοποιεί ΜΟΝΟ δεδομένα έως t."""
    c, o, h, l = d["close"], d["open"], d["high"], d["low"]
    v = d["volume"].fillna(0)
    lr = np.log(c).diff()
    s = np.log(spy_close.reindex(d.index).ffill()).diff()
    f = pd.DataFrame(index=d.index)
    for n in (63, 252):
        cov = lr.rolling(n, min_periods=n // 2).cov(s)
        var = s.rolling(n, min_periods=n // 2).var()
        f[f"beta_{n}"] = cov / var.replace(0, np.nan)
    b = f["beta_252"].fillna(f["beta_63"]).fillna(1.0).clip(-3, 5)
    res = lr - b * s
    for n in (5, 21, 63, 126):
        f[f"res_ret_{n}"] = res.rolling(n, min_periods=max(3, int(n * 0.8))).sum()
    f["res_mom_12_1"] = res.shift(21).rolling(231, min_periods=150).sum()
    f["mom_12_1"] = np.log(c.shift(21) / c.shift(252))
    f["ivol_21"] = res.rolling(21, min_periods=15).std()
    f["ivol_63"] = res.rolling(63, min_periods=40).std()
    f["ivol_ratio"] = f["ivol_21"] / f["ivol_63"]
    f["skew_63"] = lr.rolling(63, min_periods=40).skew()
    f["kurt_63"] = lr.rolling(63, min_periods=40).kurt()
    dn = lr.where(lr < 0, 0.0)
    up = lr.where(lr > 0, 0.0)
    f["downvol_21"] = np.sqrt((dn ** 2).rolling(21, min_periods=15).mean())
    f["updown_vol"] = np.sqrt((up ** 2).rolling(63, min_periods=40).mean()) / np.sqrt((dn ** 2).rolling(63, min_periods=40).mean()).replace(0, np.nan)
    on = np.log(o / c.shift(1))
    intra = np.log(c / o)
    f["overnight_5"] = on.rolling(5).sum()
    f["overnight_21"] = on.rolling(21, min_periods=15).sum()
    f["intraday_5"] = intra.rolling(5).sum()
    f["intraday_21"] = intra.rolling(21, min_periods=15).sum()
    dv = c * v
    f["amihud_21"] = np.log1p((lr.abs() / dv.replace(0, np.nan)).rolling(21, min_periods=10).mean() * 1e9)
    f["dvol_chg"] = np.log((dv.rolling(5).mean() + 1) / (dv.rolling(63, min_periods=30).mean() + 1))
    f["max_ret_5"] = lr.rolling(5).max()
    f["min_ret_5"] = lr.rolling(5).min()
    f["ret_1_lag1"] = lr.shift(1)
    lo252 = l.rolling(252, min_periods=126).min()
    f["dist_lo52"] = c / lo252 - 1
    lc = np.log(c)
    for H in (5, 21):
        parts = [lc.shift(252 * k - H) - lc.shift(252 * k) for k in (1, 2, 3, 4, 5)]
        Mx = pd.concat(parts, axis=1)
        f[f"seas_{H}"] = Mx.mean(axis=1, skipna=True).where(Mx.notna().sum(axis=1) >= 2)
    f["hl_vol_21"] = np.log(h / l).rolling(21, min_periods=15).mean()
    f["close_to_high_5"] = c / h.rolling(5).max() - 1
    idx = d.index
    f["dow"] = idx.dayofweek.astype(float)
    f["dom"] = idx.day.astype(float)
    f["month"] = idx.month.astype(float)
    f["tom"] = ((idx.day >= 26) | (idx.day <= 3)).astype(float)
    return f.replace([np.inf, -np.inf], np.nan)


def _close(sym: str) -> pd.Series | None:
    try:
        d = db.load_prices(sym)
        return d["close"] if len(d) > 30 else None
    except Exception:  # noqa: BLE001
        return None


def macro_features() -> pd.DataFrame:
    """Στοιχεία ημέρας για όλη την αγορά (ίδια για όλες τις μετοχές). Όσα σύμβολα λείπουν μένουν κενά."""
    spy = _close("SPY")
    if spy is None:
        return pd.DataFrame()
    m = pd.DataFrame(index=spy.index)
    al = lambda x: None if x is None else x.reindex(spy.index).ffill()  # noqa: E731
    lspy = np.log(spy)
    tnx, irx, dxy, oil = al(_close("^TNX")), al(_close("^IRX")), al(_close("DX-Y.NYB")), al(_close("CL=F"))
    qqq, iwm, tlt, gld, hyg, lqd, vix = (al(_close(s)) for s in ("QQQ", "IWM", "TLT", "GLD", "HYG", "LQD", "^VIX"))
    nan = pd.Series(np.nan, index=spy.index)
    r21 = lambda x: nan if x is None else np.log(x / x.shift(21))  # noqa: E731
    m["m_tnx"] = nan if tnx is None else tnx
    m["m_tnx_chg_21"] = nan if tnx is None else tnx - tnx.shift(21)
    m["m_curve"] = nan if tnx is None or irx is None else tnx - irx
    m["m_dxy_ret_21"] = r21(dxy)
    m["m_oil_ret_21"] = r21(oil.where(oil > 0) if oil is not None else None)
    m["m_qqq_spy_21"] = nan if qqq is None else r21(qqq) - r21(spy)
    m["m_iwm_spy_21"] = nan if iwm is None else r21(iwm) - r21(spy)
    m["m_tlt_ret_21"] = r21(tlt)
    m["m_gld_ret_21"] = r21(gld)
    m["m_credit_21"] = nan if hyg is None or lqd is None else r21(hyg) - r21(lqd)
    m["m_spy_vol_21"] = lspy.diff().rolling(21).std()
    m["m_spy_dd"] = spy / spy.rolling(252, min_periods=60).max() - 1
    m["m_spy_ret_1"] = lspy.diff()
    m["m_vix_pct"] = nan if vix is None else vix.rolling(252, min_periods=60).rank(pct=True)
    return m.replace([np.inf, -np.inf], np.nan).astype(np.float32)


def ensure_macro_history() -> None:
    """Κατεβάζει (μία φορά, μετά σταδιακά) τα επιπλέον σύμβολα μακρο. Αν αποτύχει, απλώς μένουν κενά."""
    need = ["^IRX", "TLT", "GLD", "HYG", "LQD", "QQQ", "IWM", "^TNX", "DX-Y.NYB", "CL=F"]
    if os.environ.get("ML4_SKIP_MACRO_DL"):
        return
    try:
        from ..data import service
        service.update_history(need, years=settings.history_years)
    except Exception as e:  # noqa: BLE001
        log.warning("macro history: %s", e)


def _group_maps() -> tuple[dict, dict]:
    """(κλάδος, βιομηχανία) ανά μετοχή: SEC/Yahoo + Nasdaq screener (meta_alt) για όσες λείπουν."""
    sec = dict(M3._sector_map())
    ind: dict[str, str] = {}
    try:
        for r in db.q("SELECT ticker, industry FROM company WHERE industry IS NOT NULL AND industry<>''"):
            ind[r["ticker"]] = r["industry"]
    except Exception:  # noqa: BLE001
        pass
    try:
        for r in db.q("SELECT ticker, sector, industry FROM meta_alt"):
            if r.get("sector"):
                sec.setdefault(r["ticker"], r["sector"])
            if r.get("industry"):
                ind.setdefault(r["ticker"], r["industry"])
    except Exception:  # noqa: BLE001
        pass
    return sec, ind


def add_features(P: pd.DataFrame, history_start: str | None = None) -> pd.DataFrame:
    """Προσθέτει στο panel του v3 τα νέα χαρακτηριστικά του v4 (ίδιες γραμμές, ίδιες ημερομηνίες)."""
    spy = _close("SPY")
    if spy is None:
        raise RuntimeError("Λείπει ιστορικό SPY")
    tickers = list(P["ticker"].unique())
    prices = M3._load_prices(tickers, history_start)
    want = P.groupby("ticker", sort=False)["date"].apply(lambda s: s.to_numpy("datetime64[ns]")).to_dict()
    parts = []
    for t, d in prices.groupby("ticker", sort=False):
        dates = want.get(t)
        if dates is None or not len(d):
            continue
        d = d.sort_values("date").set_index("date")
        e = extra_ticker_features(d, spy)
        e = e.reindex(pd.DatetimeIndex(dates))
        e = e.astype(np.float32)
        e["ticker"] = t
        e.index.name = "date"
        parts.append(e.reset_index())
    del prices
    if parts:
        E = pd.concat(parts, ignore_index=True)
        P = P.merge(E, on=["ticker", "date"], how="left")
        del E, parts
    mac = macro_features()
    if not mac.empty:
        mac.index.name = "date"
        P = P.merge(mac.reset_index(), on="date", how="left")
    sec, ind = _group_maps()
    P["_sec"] = P["ticker"].map(sec).fillna("?")
    P["_ind"] = P["ticker"].map(ind).fillna("?")
    for key, pre in (("_ind", "ind"), ("_sec", "sec4")):
        g = P.groupby(["date", key])
        cnt = g["ret_21"].transform("size")
        for n, src in ((5, "ret_5"), (21, "ret_21"), (63, "ret_63")):
            if pre == "sec4" and n == 5:
                continue
            P[f"{pre}_rel_{n}"] = (P[src] - g[src].transform("median")).where((P[key] != "?") & (cnt >= 3))
        mom = g["ret_63"].transform("median").where((P[key] != "?") & (cnt >= 3))
        P[f"{pre}_mom_rank"] = mom.groupby(P["date"]).rank(pct=True)
    gd = P.groupby("date")
    ranks = gd[CS_EXTRA].rank(pct=True).astype(np.float32)
    ranks.columns = [f"cs_{c}" for c in CS_EXTRA]
    gsn = P.groupby(["date", "_sec"])
    sn = gsn[SN_SOURCES].rank(pct=True).astype(np.float32)
    sn.columns = [f"sn_{c}" for c in SN_SOURCES]
    sn[P["_sec"].to_numpy() == "?"] = np.nan
    P = pd.concat([P.drop(columns=["_sec", "_ind"]), ranks, sn], axis=1)
    miss = [c for c in NEW_FEATURES if c not in P]
    if miss:
        P = pd.concat([P, pd.DataFrame(np.float32(np.nan), index=P.index, columns=miss)], axis=1)
    for c in NEW_FEATURES:
        if P[c].dtype != np.float32:
            P[c] = P[c].astype(np.float32)
    return P


def add_targets(P: pd.DataFrame) -> pd.DataFrame:
    """Στόχος v4 για την κατάταξη: υπεραπόδοση προσαρμοσμένη στη μεταβλητότητα (πιο σταθερός).
    Η αξιολόγηση γίνεται ΠΑΝΤΑ στην ίδια υπεραπόδοση R με το v3, για δίκαιη σύγκριση."""
    vol = P["vol_21"].clip(lower=0.005)
    new = {}
    for hz in F.RANKS:
        R = P.get(f"R_{hz}")
        if R is None:
            continue
        z = R / (vol * math.sqrt(F.HORIZONS[hz]["H"]))
        new[f"y4_{hz}"] = z.groupby(P["date"]).rank(pct=True).astype(np.float32)
    return pd.concat([P, pd.DataFrame(new, index=P.index)], axis=1) if new else P


def build_panel(tickers: list[str], with_labels: bool = True, last_only: bool = False, stats: dict | None = None) -> pd.DataFrame:
    if last_only:
        start = (pd.Timestamp.today() - pd.Timedelta(days=430)).strftime("%Y-%m-%d")
        P = M3.build_panel(tickers, start=start, with_labels=False, last_only=True)
        hist = (pd.Timestamp.today() - pd.Timedelta(days=int(365.25 * 5.6))).strftime("%Y-%m-%d")
        return add_features(P, history_start=hist)
    raw = (db.q1("SELECT COUNT(*) n FROM prices_daily") or {}).get("n") or 0
    se = max(1, int(math.ceil(raw * 0.85 / max(TARGET_ROWS, 1))))
    P = M3.build_panel(tickers, with_labels=with_labels, sample_every=se, stats=stats)
    P = add_features(P)
    if with_labels:
        P = add_targets(P)
    if stats is not None:
        stats.update(v4_features=len(FEATURES_V4), v4_rows=int(len(P)), v4_sample_every=se)
    return P


# ------------------------------------------------------------------ μοντέλα
class Ens4:
    """kind=barrier: μέσος όρος πιθανοτήτων. kind=rank: μέσος όρος ΚΑΤΑΤΑΞΕΩΝ (ανά ημέρα).
    Κάθε μοντέλο μπορεί να βλέπει υποσύνολο των στηλών (π.χ. ο συνδυασμός v3 + v4)."""

    def __init__(self, models: list, kind: str, variant: str = "B"):
        self.models, self.kind, self.variant = models, kind, variant

    @staticmethod
    def _unpack(m):
        return m if isinstance(m, tuple) else (m, None)

    def predict(self, X: np.ndarray, groups: np.ndarray | None = None) -> np.ndarray:
        if self.kind == "barrier":
            ps = []
            for m in self.models:
                est, idx = self._unpack(m)
                ps.append(est.predict_proba(X if idx is None else X[:, idx])[:, 1])
            return np.mean(ps, axis=0)
        outs = []
        g = pd.Series(groups if groups is not None else np.zeros(len(X)))
        for m in self.models:
            est, idx = self._unpack(m)
            raw = pd.Series(est.predict(X if idx is None else X[:, idx]))
            outs.append(raw.groupby(g.to_numpy()).rank(pct=True).to_numpy())
        return np.mean(outs, axis=0)

    def contrib(self, X: np.ndarray) -> np.ndarray | None:
        try:
            parts = []
            for m in self.models:
                est, idx = self._unpack(m)
                if not hasattr(est, "booster_"):
                    continue  # π.χ. το v3 μέσα στον συνδυασμό E
                c = est.booster_.predict(X if idx is None else X[:, idx], pred_contrib=True)[:, :-1]
                s = np.abs(c).sum(axis=1, keepdims=True)
                c = c / np.where(s > 0, s, 1)
                if idx is not None:
                    full = np.zeros((len(X), X.shape[1]))
                    full[:, idx] = c
                    c = full
                parts.append(c)
            return np.mean(parts, axis=0) if parts else None
        except Exception:  # noqa: BLE001
            return None

    def gain_importance(self) -> np.ndarray | None:
        try:
            gs = []
            for m in self.models:
                est, idx = self._unpack(m)
                if not hasattr(est, "booster_"):
                    continue
                g = est.booster_.feature_importance("gain").astype(float)
                g = g / max(g.sum(), 1e-12)
                if idx is not None:
                    full = np.zeros(len(FEATURES_V4))
                    full[idx] = g
                    g = full
                gs.append(g)
            return np.mean(gs, axis=0) if gs else None
        except Exception:  # noqa: BLE001
            return None


def _params(seed: int, kind: str) -> dict:
    return dict(n_estimators=900, learning_rate=0.03, num_leaves=47, min_child_samples=1200, subsample=0.7,
                subsample_freq=1, colsample_bytree=0.45, reg_lambda=8.0, reg_alpha=0.5, min_split_gain=0.0,
                n_jobs=-1, random_state=seed, verbose=-1, max_bin=63, force_col_wise=True)


def _params_v3(seed: int) -> dict:
    """Ίδιες ρυθμίσεις με το v3 (για να φανεί καθαρά τι προσθέτουν τα νέα στοιχεία)."""
    return dict(n_estimators=800, learning_rate=0.035, num_leaves=63, min_child_samples=400, subsample=0.7,
                subsample_freq=1, colsample_bytree=0.55, reg_lambda=3.0, n_jobs=-1, random_state=seed, verbose=-1, max_bin=127)


IDX_V3 = np.arange(len(F.FEATURES))  # οι στήλες του v3 είναι οι πρώτες του v4
# λίγα νέα στοιχεία με τεκμηρίωση στη βιβλιογραφία (λιγότερος «θόρυβος» από όλα μαζί)
SELECT_NEW = ["mom_12_1", "res_mom_12_1", "res_ret_21", "ivol_63", "max_ret_5", "seas_21", "overnight_21", "intraday_21",
              "amihud_21", "beta_252", "ind_rel_21", "sn_ret_21"]
IDX_D = np.array(list(IDX_V3) + [FEATURES_V4.index(c) for c in SELECT_NEW])
VARIANTS = {"A": "ρυθμίσεις v3 + όλα τα νέα στοιχεία", "B": "στόχος με μεταβλητότητα + LambdaRank",
            "C": "συνδυασμός v3 και A", "D": "ρυθμίσεις v3 + 12 επιλεγμένα νέα στοιχεία"}
# επιπλέον (προστέθηκαν· οι A–D μένουν ίδιες): συνδυασμός όλων και αυτόματη αναζήτηση που βελτιώνεται κάθε βράδυ
EXTRA_VARIANTS = {"E": "συνδυασμός v3 + A + D (μέσος όρος)",
                  "S": "ο καλύτερος συνδυασμός ρυθμίσεων της αυτόματης αναζήτησης μέχρι σήμερα"}
AUTO_TRIES = int(os.environ.get("ML4_AUTO_TRIES", 3))          # νέες δοκιμές ανά ορίζοντα κάθε βράδυ (ελάχιστο)
AUTO_MAX_TRIES = int(os.environ.get("ML4_AUTO_MAX_TRIES", 8))   # ανώτατο όταν περισσεύει χρόνος
AUTO_BUDGET_MIN = float(os.environ.get("ML4_AUTO_BUDGET_MIN", 75))  # λεπτά για την αναζήτηση σε όλους τους ορίζοντες
AUTO_CFG_SEC = float(os.environ.get("ML4_AUTO_CFG_SEC", 450))  # μέγιστος χρόνος ανά δοκιμή (όλες οι περίοδοι)


class _V3Member:
    """Το v3 (ίδιο μοντέλο, ίδιες ρυθμίσεις) ως μέλος του συνδυασμού E· βλέπει μόνο τις στήλες του v3."""

    def __init__(self, ens):
        self.ens = ens

    def predict(self, X: np.ndarray) -> np.ndarray:
        return self.ens.predict(X)

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        p = self.ens.predict(X)
        return np.c_[1 - p, p]


def _fit_lgb(est, Xtr, ytr, Xva, yva, gtr=None, gva=None, lgb=None):
    cb = [lgb.early_stopping(60, verbose=False)]
    kw = {"group": gtr} if gtr is not None else {}
    if Xva is not None and len(Xva) > 1000:
        ekw = {"eval_group": [gva], "eval_at": [50]} if gva is not None else {}
        for style in ("new", "old"):
            try:
                if style == "new":
                    est.fit(Xtr, ytr, eval_X=(Xva,), eval_y=(yva,), callbacks=cb, **kw, **ekw)
                else:
                    est.fit(Xtr, ytr, eval_set=[(Xva, yva)], callbacks=cb, **kw, **ekw)
                return est
            except TypeError:
                continue
    est.set_params(n_estimators=300)
    est.fit(Xtr, ytr, **kw)
    return est


def _groups(dates: np.ndarray) -> np.ndarray:
    """Μεγέθη ομάδων (ανά ημερομηνία) για LambdaRank — οι γραμμές πρέπει να είναι ταξινομημένες κατά ημερομηνία."""
    _, counts = np.unique(dates, return_counts=True)
    return counts


def fit_v4(kind: str, data: pd.DataFrame, hz: str, H: int, seed0: int = 0, max_rows: int = MAX_TRAIN_ROWS,
           variant: str = "B") -> Ens4:
    lgb = M3._lgb()
    dates = np.sort(data["date"].unique())
    cut = pd.Timestamp(dates[int(len(dates) * 0.88)])
    gap = pd.Timedelta(days=int(H * 1.5) + 3)
    tr = data[data["date"] < cut - gap]
    va = data[data["date"] >= cut]
    if len(tr) > max_rows:
        tr = tr.sample(n=max_rows, random_state=seed0)
    if len(va) > 200_000:
        va = va.sample(n=200_000, random_state=seed0)
    tr = tr.sort_values("date", kind="stable")
    va = va.sort_values("date", kind="stable")
    Xtr, Xva = tr[FEATURES_V4].to_numpy(np.float32), va[FEATURES_V4].to_numpy(np.float32)
    models = []
    if lgb is None:  # χωρίς LightGBM: ένα μοντέλο scikit-learn (ίδιο με το v3)
        ycol = f"y4_{hz}" if kind == "rank" and variant == "B" else f"y_{hz}"
        m = M3._fit_one(kind, Xtr, tr[ycol].to_numpy(np.float32 if kind == "rank" else int), None, None, seed0)
        return Ens4([m], kind, variant)
    if variant == "D":
        yt = np.float32 if kind == "rank" else int
        ytr, yva = tr[f"y_{hz}"].to_numpy(yt), va[f"y_{hz}"].to_numpy(yt)
        est = lgb.LGBMRegressor(objective="regression", **_params_v3(seed0 + 17)) if kind == "rank" else lgb.LGBMClassifier(**_params_v3(seed0 + 17))
        return Ens4([(_fit_lgb(est, Xtr[:, IDX_D], ytr, Xva[:, IDX_D], yva, lgb=lgb), IDX_D)], kind, variant)
    if variant in ("A", "C"):
        yt = np.float32 if kind == "rank" else int
        ytr, yva = tr[f"y_{hz}"].to_numpy(yt), va[f"y_{hz}"].to_numpy(yt)
        mk = (lambda s: lgb.LGBMRegressor(objective="regression", **_params_v3(s))) if kind == "rank" else \
             (lambda s: lgb.LGBMClassifier(**_params_v3(s)))
        models.append((_fit_lgb(mk(seed0 + 11), Xtr, ytr, Xva, yva, lgb=lgb), None))
        if variant == "C":
            models.append((_fit_lgb(mk(seed0 + 13), Xtr[:, IDX_V3], ytr, Xva[:, IDX_V3], yva, lgb=lgb), IDX_V3))
        return Ens4(models, kind, variant)
    if kind == "barrier":
        ytr, yva = tr[f"y_{hz}"].to_numpy(int), va[f"y_{hz}"].to_numpy(int)
        for k in range(2):
            p = _params(seed0 + k, kind)
            if k == 1:
                p.update(num_leaves=31, colsample_bytree=0.35, min_child_samples=2000, learning_rate=0.04)
            models.append(_fit_lgb(lgb.LGBMClassifier(**p), Xtr, ytr, Xva, yva, lgb=lgb))
        return Ens4(models, kind, variant)
    # κατάταξη: (1) παλινδρόμηση στον στόχο v4, (2) LambdaRank σε δεκατημόρια ανά ημέρα
    ytr, yva = tr[f"y4_{hz}"].to_numpy(np.float32), va[f"y4_{hz}"].to_numpy(np.float32)
    models.append(_fit_lgb(lgb.LGBMRegressor(objective="regression", **_params(seed0, kind)), Xtr, ytr, Xva, yva, lgb=lgb))
    try:
        dtr = np.minimum((np.nan_to_num(ytr, nan=0.5) * 10).astype(int), 9)
        dva = np.minimum((np.nan_to_num(yva, nan=0.5) * 10).astype(int), 9)
        rp = _params(seed0 + 7, kind)
        rp.update(objective="lambdarank", lambdarank_truncation_level=60, label_gain=list(range(10)), num_leaves=31)
        models.append(_fit_lgb(lgb.LGBMRanker(**rp), Xtr, dtr, Xva, dva, gtr=_groups(tr["date"].to_numpy()),
                               gva=_groups(va["date"].to_numpy()), lgb=lgb))
    except Exception as e:  # noqa: BLE001
        log.warning("LambdaRank %s: %s — συνεχίζω μόνο με την παλινδρόμηση", hz, e)
    return Ens4(models, kind, variant)


# ------------------------------------------------------------------ αυτόματη αναζήτηση (βελτιώνεται μόνη της)
# Κάθε βράδυ δοκιμάζονται λίγοι νέοι συνδυασμοί ρυθμίσεων/στοιχείων ΣΤΙΣ ΙΔΙΕΣ περιόδους ελέγχου. Ο καλύτερος
# μέχρι σήμερα («πρωταθλητής») ξαναμετριέται κάθε βράδυ με τα νέα δεδομένα και αντικαθίσταται μόνο από
# δοκιμή που τον ξεπερνά. Για να μη «φουσκώνει» το αποτέλεσμα από τις πολλές δοκιμές, το όριο του ελέγχου
# ανεβαίνει όσο αυξάνονται οι δοκιμές (διόρθωση για πολλαπλές δοκιμές).
def _fsets() -> dict[str, np.ndarray | None]:
    ix = {c: i for i, c in enumerate(FEATURES_V4)}
    v3 = list(IDX_V3)
    grp = lambda cols: np.array(v3 + [ix[c] for c in cols if c in ix])  # noqa: E731
    return {"v3": IDX_V3, "v3+12": IDX_D, "all": None,
            "v3+ομάδα": grp(GROUP_REL + [f"sn_{c}" for c in SN_SOURCES]),
            "v3+μακρο": grp(MACRO),
            "v3+κατατάξεις": grp([f"cs_{c}" for c in CS_EXTRA]),
            "v3+μετοχή": grp(EXTRA_TICKER)}


SPACE = {"num_leaves": [15, 31, 63, 127], "min_child_samples": [200, 400, 1000, 2500, 5000],
         "learning_rate": [0.02, 0.035, 0.05], "colsample_bytree": [0.3, 0.45, 0.6, 0.8],
         "subsample": [0.5, 0.7, 0.9], "reg_lambda": [0.0, 1.0, 3.0, 10.0, 30.0], "max_bin": [63, 127, 255],
         "path_smooth": [0.0, 10.0, 50.0], "extra_trees": [False, True]}
SPACE_RANK = {"objective": ["regression", "huber", "lambdarank", "rank_xendcg"], "target": ["y", "y4"]}
FSET_NAMES = ["v3", "v3+12", "all", "v3+ομάδα", "v3+μακρο", "v3+κατατάξεις", "v3+μετοχή"]


def _cfg_key(cfg: dict) -> str:
    return json.dumps(cfg, sort_keys=True, ensure_ascii=False)


def cfg_text(cfg: dict | None) -> str:
    if not cfg:
        return "—"
    obj = {"regression": "παλινδρόμηση", "huber": "huber", "lambdarank": "LambdaRank", "rank_xendcg": "XE-NDCG"}
    parts = [f"στοιχεία {cfg.get('fs')}"]
    if cfg.get("objective"):
        parts.append(obj.get(cfg["objective"], cfg["objective"]) + (" (στόχος με μεταβλητότητα)" if cfg.get("target") == "y4" else ""))
    parts.append(f"φύλλα {cfg.get('num_leaves')}, ελάχ. δείγμα {cfg.get('min_child_samples')}, βήμα {cfg.get('learning_rate')}")
    return ", ".join(parts)


def _v3_like(kind: str) -> dict:
    c = {"fs": "v3+12", "num_leaves": 63, "min_child_samples": 400, "learning_rate": 0.035, "colsample_bytree": 0.6,
         "subsample": 0.7, "reg_lambda": 3.0, "max_bin": 127, "path_smooth": 0.0, "extra_trees": False}
    if kind == "rank":
        c.update(objective="regression", target="y")
    return c


def auto_tries(ast: dict, n_hz: int, deadline_left: float | None = None) -> int:
    """Πόσες νέες δοκιμές απόψε: όσες χωράνε στον χρόνο (από τη διάρκεια μιας δοκιμής τις προηγούμενες βραδιές),
    τουλάχιστον AUTO_TRIES και το πολύ AUTO_MAX_TRIES. Χωρίς ιστορικό χρόνου: AUTO_TRIES."""
    per = float(ast.get("sec_per_cfg") or 0)
    if per <= 0 or AUTO_BUDGET_MIN <= 0:
        return AUTO_TRIES
    budget = AUTO_BUDGET_MIN * 60 / max(1, n_hz)
    if deadline_left is not None:
        budget = min(budget, max(0.0, deadline_left) * 0.35 / max(1, n_hz))
    n = int(budget // per) - (1 if ast.get("champion") else 0)
    return int(max(min(AUTO_TRIES, 2), min(AUTO_MAX_TRIES, n)))


def _weighted(rng, items: list, wins: dict | None):
    """Επιλογή με βάρος: ό,τι έχει κερδίσει παλιότερα δοκιμάζεται συχνότερα (αλλά όλα έχουν πιθανότητα)."""
    w = np.array([1.0 + 2.0 * float((wins or {}).get(str(x), 0)) for x in items])
    return items[int(rng.choice(len(items), p=w / w.sum()))]


def sample_configs(kind: str, champion: dict | None, n: int, seed: int, tried: set[str] | None = None,
                   wins: dict | None = None) -> list[dict]:
    """Νέοι συνδυασμοί: οι μισοί μικρές αλλαγές στον πρωταθλητή (1-2 ρυθμίσεις), οι άλλοι εντελώς νέοι.
    wins: {"fs": {...}, "objective": {...}} — οι επιλογές που έχουν βγάλει πρωταθλητή προτιμώνται."""
    wins = wins or {}
    rng = np.random.default_rng(seed)
    tried = set(tried or ())
    space = dict(SPACE, **(SPACE_RANK if kind == "rank" else {}))
    base = champion or _v3_like(kind)
    out: list[dict] = []
    for _ in range(n * 30):
        if len(out) >= n:
            break
        if rng.random() < 0.5:
            c = dict(base)
            for k in rng.choice(list(space) + ["fs"], size=int(rng.integers(1, 3)), replace=False):
                c[k] = _weighted(rng, FSET_NAMES, wins.get("fs")) if k == "fs" else \
                    _weighted(rng, list(space[k]), wins.get(k)) if k in ("objective", "target") else space[k][int(rng.integers(len(space[k])))]
        else:
            c = {k: (_weighted(rng, list(v), wins.get(k)) if k in ("objective", "target") else v[int(rng.integers(len(v)))]) for k, v in space.items()}
            c["fs"] = _weighted(rng, FSET_NAMES, wins.get("fs"))
        c = {k: (v.item() if hasattr(v, "item") else v) for k, v in c.items()}
        key = _cfg_key(c)
        if key in tried or key == _cfg_key(base):
            continue
        tried.add(key)
        out.append(c)
    return out


def auto_state(hz: str) -> dict:
    try:
        st = db.kv_get(f"ml4_auto:{hz}") or {}
    except Exception:  # noqa: BLE001
        st = {}
    st.setdefault("champion", None)
    st.setdefault("tried", 0)
    st.setdefault("keys", [])
    st.setdefault("history", [])
    return st


def need_for(kind: str, tried: int) -> float:
    """Αυστηρότερο όριο όσο περισσότερες δοκιμές έχουν γίνει (t για κατάταξη, AUC για στόχο/stop)."""
    f = math.log2(1 + max(0, tried) / 8)
    return round(2.5 + 0.3 * f, 2) if kind == "rank" else round(0.53 + 0.003 * f, 4)


def fit_auto(kind: str, data: pd.DataFrame, hz: str, H: int, cfg: dict, seed0: int = 0,
             max_rows: int = MAX_TRAIN_ROWS) -> Ens4:
    lgb = M3._lgb()
    if lgb is None:
        return fit_v4(kind, data, hz, H, seed0, max_rows, variant="A")
    dates = np.sort(data["date"].unique())
    cut = pd.Timestamp(dates[int(len(dates) * 0.88)])
    gap = pd.Timedelta(days=int(H * 1.5) + 3)
    tr = data[data["date"] < cut - gap]
    va = data[data["date"] >= cut]
    if len(tr) > max_rows:
        tr = tr.sample(n=max_rows, random_state=seed0)
    if len(va) > 200_000:
        va = va.sample(n=200_000, random_state=seed0)
    tr = tr.sort_values("date", kind="stable")
    va = va.sort_values("date", kind="stable")
    idx = _fsets().get(cfg.get("fs"), IDX_D)
    cols = FEATURES_V4 if idx is None else [FEATURES_V4[i] for i in idx]
    Xtr, Xva = tr[cols].to_numpy(np.float32), va[cols].to_numpy(np.float32)
    p = dict(n_estimators=1500, learning_rate=cfg["learning_rate"], num_leaves=cfg["num_leaves"],
             min_child_samples=cfg["min_child_samples"], subsample=cfg["subsample"], subsample_freq=1,
             colsample_bytree=cfg["colsample_bytree"], reg_lambda=cfg["reg_lambda"], max_bin=cfg["max_bin"],
             path_smooth=cfg.get("path_smooth", 0.0), extra_trees=bool(cfg.get("extra_trees")),
             n_jobs=-1, random_state=seed0 + 31, verbose=-1)
    if kind == "barrier":
        ytr, yva = tr[f"y_{hz}"].to_numpy(int), va[f"y_{hz}"].to_numpy(int)
        est = _fit_lgb(lgb.LGBMClassifier(**p), Xtr, ytr, Xva, yva, lgb=lgb)
        return Ens4([(est, idx)], kind, "S")
    ycol = f"y4_{hz}" if cfg.get("target") == "y4" else f"y_{hz}"
    ytr, yva = tr[ycol].to_numpy(np.float32), va[ycol].to_numpy(np.float32)
    obj = cfg.get("objective", "regression")
    if obj in ("lambdarank", "rank_xendcg"):
        dtr = np.minimum((np.nan_to_num(ytr, nan=0.5) * 10).astype(int), 9)
        dva = np.minimum((np.nan_to_num(yva, nan=0.5) * 10).astype(int), 9)
        p.update(objective=obj)
        if obj == "lambdarank":
            p.update(lambdarank_truncation_level=60, label_gain=list(range(10)))
        est = _fit_lgb(lgb.LGBMRanker(**p), Xtr, dtr, Xva, dva, gtr=_groups(tr["date"].to_numpy()),
                       gva=_groups(va["date"].to_numpy()), lgb=lgb)
    else:
        if obj == "huber":
            p.update(alpha=0.25)
        est = _fit_lgb(lgb.LGBMRegressor(objective=obj, **p), Xtr, ytr, Xva, yva, lgb=lgb)
    return Ens4([(est, idx)], kind, "S")


def fit_e(kind: str, data: pd.DataFrame, hz: str, H: int, seed0: int = 100) -> Ens4:
    """Συνδυασμός E: v3 (ίδιο με το σημερινό) + A + D, μέσος όρος (πιθανοτήτων ή κατατάξεων)."""
    ens3 = M3.fit_ensemble(kind, data, f"y_{hz}", H, n_models=1, seed0=seed0)
    a = fit_v4(kind, data, hz, H, seed0=seed0, variant="A")
    d = fit_v4(kind, data, hz, H, seed0=seed0, variant="D")
    return Ens4([(_V3Member(ens3), IDX_V3)] + list(a.models) + list(d.models), kind, "E")


def _rank_in_day(p: np.ndarray, g: np.ndarray) -> np.ndarray:
    return pd.Series(p).groupby(g).rank(pct=True).to_numpy()


# ------------------------------------------------------------------ έλεγχος: v4 και v3 στις ίδιες περιόδους
def _nw_t(x: np.ndarray, lag: int) -> float | None:
    """t-statistic με διόρθωση Newey-West: οι αποδόσεις διπλανών ημερών επικαλύπτονται (π.χ. 5ήμερες αποδόσεις
    κάθε μέρα), άρα οι καθημερινές μετρήσεις ΔΕΝ είναι ανεξάρτητες και το απλό t φουσκώνει."""
    x = np.asarray(x, float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n < 10:
        return None
    e = x - x.mean()
    s = float(e @ e) / n
    for k in range(1, min(lag, n - 1) + 1):
        s += 2 * (1 - k / (lag + 1)) * float(e[k:] @ e[:-k]) / n
    if s <= 0:
        return None
    return float(x.mean() / math.sqrt(s / n))


def _overlap_lag(oos: pd.DataFrame, H: int) -> int:
    d = np.sort(oos["date"].unique())
    if len(d) < 3:
        return max(1, H)
    gap_td = max(1.0, float(np.median(np.diff(d) / np.timedelta64(1, "D"))) * 5 / 7)
    return max(1, int(math.ceil(H / gap_td)))


def _honest(m: dict, oos: pd.DataFrame, pcol: str, kind: str, H: int) -> dict:
    """Αντικαθιστά το t του IC με το διορθωμένο (πιο αυστηρό). Το απλό κρατιέται ως ic_t_raw."""
    ics = M3._daily_ic(oos, pcol, "R", spearman=(kind == "rank"))
    lag = _overlap_lag(oos, H)
    t = _nw_t(ics, lag)
    m = dict(m)
    m["ic_t_raw"] = m.get("ic_t")
    m["ic_t"] = round(t, 2) if t is not None else None
    m["nw_lag"] = lag
    return m


def _better(m4: dict, m3: dict, kind: str) -> tuple[bool, list[str]]:
    """Είναι το v4 καλύτερο από το v3 στο ίδιο out-of-sample; (ίδιες γραμμές, ίδιες περίοδοι)"""
    notes = []
    if kind == "rank":
        t4, t3 = m4.get("ic_t") or -9, m3.get("ic_t") or -9
        top4, top3 = m4.get("top_decile_R") or -9, m3.get("top_decile_R") or -9
        ok = t4 > t3 and top4 >= top3
        notes.append(f"IC t: v3 {m3.get('ic_t')} → v4 {m4.get('ic_t')}")
        notes.append(f"Top 10% υπεραπόδοση: v3 {100 * (m3.get('top_decile_R') or 0):.2f}% → v4 {100 * (m4.get('top_decile_R') or 0):.2f}%")
    else:
        a4, a3 = m4.get("auc") or 0, m3.get("auc") or 0
        top4, top3 = m4.get("top_decile_R") or -9, m3.get("top_decile_R") or -9
        ok = a4 > a3 and top4 >= top3
        notes.append(f"AUC: v3 {m3.get('auc')} → v4 {m4.get('auc')}")
        notes.append(f"Top 10% μέσο R: v3 {m3.get('top_decile_R')} → v4 {m4.get('top_decile_R')}")
    return bool(ok), notes


def walk_forward_pair(P: pd.DataFrame, hz: str, cb=None, auto_cfgs: dict[str, dict] | None = None,
                      auto_info: dict | None = None) -> tuple[pd.DataFrame, list[dict]]:
    cfg = F.HORIZONS[hz]
    kind = cfg["kind"]
    data = P[P[f"y_{hz}"].notna() & P[f"R_{hz}"].notna()]
    if kind == "rank":
        data = data[data[f"y4_{hz}"].notna()]
    dates = np.sort(data["date"].unique())
    if len(dates) < 250:
        raise RuntimeError("Ανεπαρκές ιστορικό για walk-forward")
    first, last = pd.Timestamp(dates[0]), pd.Timestamp(dates[-1])
    span_years = (last - first).days / 365.25
    min_train = M3.MIN_TRAIN_YEARS if span_years >= M3.MIN_TRAIN_YEARS + 2 else 2.0
    test_months = 12 if span_years > 6 else 6
    embargo = pd.Timedelta(days=int(cfg["H"] * 1.5) + 4)
    test_start = first + pd.DateOffset(months=int(min_train * 12))
    n_folds = max(1, int(((last - test_start).days / 30.4) // test_months) + 1)
    folds, oos = [], []
    auto_cfgs = dict(auto_cfgs or {})
    spent = {n: 0.0 for n in auto_cfgs}
    dropped: set[str] = set()
    k = 0
    while test_start < last:
        test_end = test_start + pd.DateOffset(months=test_months)
        tr = data[data["date"] < test_start - embargo]
        te = data[(data["date"] >= test_start) & (data["date"] < test_end)]
        if len(tr) > 5000 and len(te) > 500:
            if cb:
                cb(k, n_folds, f"{cfg['label']} (v4): περίοδος {k + 1}/{n_folds}, εκπαίδευση έως {test_start.date()}")
            ens3 = M3.fit_ensemble(kind, tr, f"y_{hz}", cfg["H"], n_models=1, seed0=k)
            p3 = ens3.predict(te[F.FEATURES].to_numpy(np.float32))
            del ens3
            Xte, gte = te[FEATURES_V4].to_numpy(np.float32), te["date"].to_numpy()
            ens4 = fit_v4(kind, tr, hz, cfg["H"], seed0=k, variant="B")
            pB = ens4.predict(Xte, groups=gte)
            del ens4
            ens4 = fit_v4(kind, tr, hz, cfg["H"], seed0=k, variant="A")
            pA = ens4.predict(Xte, groups=gte)
            del ens4
            ens4 = fit_v4(kind, tr, hz, cfg["H"], seed0=k, variant="D")
            pD = ens4.predict(Xte, groups=gte)
            del ens4
            if kind == "rank":  # C = μέσος όρος των κατατάξεων v3 και A (ίδια μέρα)
                g = pd.Series(gte)
                pC = (pd.Series(pA).groupby(g).rank(pct=True) + pd.Series(p3).groupby(g).rank(pct=True)).to_numpy() / 2
                pE = (_rank_in_day(p3, gte) + _rank_in_day(pA, gte) + _rank_in_day(pD, gte)) / 3
            else:
                pC = (pA + p3) / 2
                pE = (p3 + pA + pD) / 3
            o = pd.DataFrame({"date": te["date"].to_numpy(), "ticker": te["ticker"].to_numpy(), "p": pB, "pB": pB, "pA": pA,
                              "pC": pC, "pD": pD, "pE": pE, "p3": p3, "y": te[f"y_{hz}"].to_numpy(),
                              "R": te[f"R_{hz}"].to_numpy(), "fold": k})
            for name, acfg in auto_cfgs.items():  # αυτόματη αναζήτηση: ίδια περίοδος, ίδιες γραμμές
                if name in dropped:
                    o["p" + name] = np.nan
                    continue
                if k > 0 and spent[name] / k * n_folds > AUTO_CFG_SEC:
                    dropped.add(name)  # πολύ αργή για τον διαθέσιμο χρόνο: δεν μετράει απόψε
                    o["p" + name] = np.nan
                    continue
                t1 = time.time()
                try:
                    e_ = fit_auto(kind, tr, hz, cfg["H"], acfg, seed0=k)
                    o["p" + name] = e_.predict(Xte, groups=gte)
                    del e_
                except Exception as ex:  # noqa: BLE001
                    log.warning("auto %s %s: %s", hz, name, ex)
                    dropped.add(name)
                    o["p" + name] = np.nan
                spent[name] += time.time() - t1
            if kind == "rank":
                o["A"] = te[f"A_{hz}"].to_numpy()
            oos.append(o)
            f4 = M3.evaluate(o, kind=kind)
            f3 = M3.evaluate(o.assign(p=o["p3"]), kind=kind)
            folds.append({"fold": k + 1, "train_end": str((test_start - embargo).date()),
                          "test": [str(test_start.date()), str(min(test_end, last).date())],
                          "n_train": int(len(tr)), "n_test": int(len(te)),
                          "auc": f4.get("auc"), "ic_mean": f4["ic_mean"], "top_decile_R": f4["top_decile_R"],
                          "avg_R_all": f4["avg_R_all"], "base_rate": f4.get("base_rate"), "long_short": f4.get("long_short"),
                          "v3": {"auc": f3.get("auc"), "ic_mean": f3["ic_mean"], "top_decile_R": f3["top_decile_R"]}})
            gc.collect()
            k += 1
        test_start = test_end
    if not oos:
        raise RuntimeError("Δεν δημιουργήθηκαν περίοδοι ελέγχου (λίγα δεδομένα)")
    if auto_info is not None:
        auto_info.update(dropped=sorted(dropped), seconds={n: round(v) for n, v in spent.items()})
    return pd.concat(oos, ignore_index=True), folds


def _importance(ens: Ens4) -> list[dict]:
    g = ens.gain_importance()
    if g is None:
        return []
    imp = sorted(zip(FEATURES_V4, g), key=lambda x: -x[1])
    return [{"feature": f, "label": label(f), "importance": round(float(v), 5), "new": f in NEW_FEATURES} for f, v in imp]


def _stale(hz: str, max_age_days: float) -> bool:
    r = db.q1("SELECT created_at, compare_json FROM ml4_models WHERE horizon=?", (hz,))
    if not r or not r["created_at"]:
        return True
    if '"E": {' not in (r.get("compare_json") or ""):
        return True  # παλιότερη έκδοση του v4 (χωρίς όλες τις παραλλαγές): ξανά εκπαίδευση
    try:
        age = (pd.Timestamp.now(tz="UTC") - pd.Timestamp(r["created_at"])).total_seconds() / 86400
    except Exception:  # noqa: BLE001
        return True
    if age >= max_age_days:
        return True
    return load(hz) is None


def train_all(tickers: list[str] | None = None, horizons: list[str] | None = None, deadline: float | None = None,
              only_stale: bool = False, max_age_days: float | None = None) -> dict:
    """Εκπαιδεύει το v4 (και ξανά το v3 στις ίδιες περιόδους για σύγκριση). deadline: time.time() όριο —
    αν δεν φτάνει ο χρόνος για τον επόμενο ορίζοντα, σταματά και συνεχίζει την επόμενη φορά."""
    import joblib
    if _progress["running"]:
        return {"status": "already_running"}
    init()
    _progress.update(running=True, step="Ξεκίνημα", pct=0, started_at=db.now_iso(), error=None, horizon=None)
    t0 = time.time()
    max_age = max_age_days if max_age_days is not None else settings.ml_retrain_days
    hz_list = [h for h in (horizons or ORDER) if h in F.HORIZONS]
    if only_stale:
        hz_list = [h for h in hz_list if _stale(h, max_age)]
    if not hz_list:
        _progress["running"] = False
        return {"status": "up_to_date"}
    try:
        from ..data.listings import universe_tickers
        tickers = tickers or universe_tickers(settings.ml_max_tickers)
        _step("Επιπλέον στοιχεία αγοράς (επιτόκια, ομόλογα, χρυσός, πιστωτικός κίνδυνος)", 1)
        ensure_macro_history()
        _step(f"Φόρτωση τιμών & υπολογισμός {len(FEATURES_V4)} χαρακτηριστικών για {len(tickers)} μετοχές", 3)
        stats: dict = {}
        P = build_panel(tickers, with_labels=True, stats=stats)
        _step(f"Panel v4: {len(P):,} γραμμές × {len(FEATURES_V4)} χαρακτηριστικά", 15)
        MODEL_DIR.mkdir(parents=True, exist_ok=True)
        results, skipped = {}, []
        span = 84 / len(hz_list)
        per_hz: list[float] = []
        for hi, hz in enumerate(hz_list):
            if deadline is not None:
                need = (np.mean(per_hz) * 1.15) if per_hz else 0
                if time.time() + need > deadline:
                    skipped = hz_list[hi:]
                    _step(f"Δεν φτάνει ο χρόνος για {', '.join(skipped)} — θα εκπαιδευτούν την επόμενη φορά")
                    break
            cfg = F.HORIZONS[hz]
            kind = cfg["kind"]
            base_pct = 15 + hi * span
            _progress["horizon"] = hz

            def cb(k, n, msg, _b=base_pct, _s=span):
                _step(msg, _b + 0.8 * _s * k / max(n, 1))

            ht0 = time.time()
            # αυτόματη αναζήτηση: ο πρωταθλητής ξαναμετριέται + AUTO_TRIES νέοι συνδυασμοί, στις ίδιες περιόδους
            ast = auto_state(hz)
            cfgs: dict[str, dict] = {}
            n_try = auto_tries(ast, len(hz_list), (deadline - time.time()) if deadline is not None else None)
            if M3._lgb() is not None and AUTO_TRIES > 0:
                if ast["champion"]:
                    cfgs["S"] = ast["champion"]
                seed = int(pd.Timestamp.now(tz="UTC").strftime("%Y%m%d")) * 7 + hi
                for i, c in enumerate(sample_configs(kind, ast["champion"], n_try, seed, set(ast["keys"]), ast.get("wins")), 1):
                    cfgs[f"S{i}"] = c
            ainfo: dict = {}
            oos, folds = walk_forward_pair(P, hz, cb, auto_cfgs=cfgs, auto_info=ainfo)
            ok_auto = [n for n in cfgs if n not in ainfo.get("dropped", []) and f"p{n}" in oos and oos[f"p{n}"].notna().all()]
            # όλες οι παραλλαγές του v4 στις ίδιες περιόδους: κρατάμε την καλύτερη (τις αναφέρουμε όλες)
            var_m = {}
            for v in list(VARIANTS) + ["E"] + ok_auto:
                mv = _honest(M3.evaluate(oos.assign(p=oos["p" + v]), kind=kind), oos, "p" + v, kind, cfg["H"])
                var_m[v] = {"ic": mv.get("ic_mean"), "icT": mv.get("ic_t"), "top": mv.get("top_decile_R"), "auc": mv.get("auc"),
                            "ls": mv.get("long_short"), "hit": mv.get("top_decile_hit")}
            key = (lambda v: (var_m[v]["icT"] if var_m[v]["icT"] is not None else -9, var_m[v]["top"] or -9)) if kind == "rank" else \
                  (lambda v: (var_m[v]["auc"] or 0, var_m[v]["top"] or -9))
            # πρωταθλητής / διεκδικητές: αλλάζει μόνο αν κάποια νέα δοκιμή τον ξεπεράσει ΑΠΟΨΕ, στα ίδια δεδομένα
            new_try = [n for n in cfgs if n != "S"]
            ast["tried"] = int(ast["tried"]) + len(new_try)
            ast["keys"] = (list(ast["keys"]) + [_cfg_key(cfgs[n]) for n in new_try])[-500:]
            champ, changed = ("S" if "S" in ok_auto else None), False
            cand = [n for n in ok_auto if n != "S"]
            if cand:
                best_new = max(cand, key=key)
                if champ is None or key(best_new) > key(champ):
                    champ, changed = best_new, True
                    ast["champion"] = cfgs[best_new]
                    wins = ast.setdefault("wins", {})
                    for k in ("fs", "objective", "target"):  # μαθαίνει ποιες επιλογές φέρνουν βελτίωση
                        if cfgs[best_new].get(k) is not None:
                            wins.setdefault(k, {})[str(cfgs[best_new][k])] = wins.get(k, {}).get(str(cfgs[best_new][k]), 0) + 1
            if champ:
                ast["champion_score"] = var_m[champ]
            secs_cfg = [v for v in (ainfo.get("seconds") or {}).values() if v and v > 0]
            if secs_cfg:  # μέσος χρόνος μιας δοκιμής (όλες οι περίοδοι), για να ξέρει πόσες χωράνε την επόμενη φορά
                m_ = float(np.mean(secs_cfg))
                ast["sec_per_cfg"] = round(0.5 * float(ast.get("sec_per_cfg") or m_) + 0.5 * m_, 1)
            ast["history"] = ([{"at": db.now_iso(), "tried": len(new_try), "evaluated": len(cand), "changed": changed,
                                "score": var_m.get(champ) if champ else None, "champion": cfg_text(ast["champion"])}]
                              + list(ast["history"]))[:30]
            try:
                db.kv_set(f"ml4_auto:{hz}", ast)
            except Exception:  # noqa: BLE001
                log.warning("auto state save failed")
            sel = list(VARIANTS) + ["E"] + ([champ] if champ else [])
            chosen = max(sel, key=key)
            vdesc = dict(VARIANTS, **EXTRA_VARIANTS)
            vdesc.update({n: "αυτόματη αναζήτηση: " + cfg_text(c) for n, c in cfgs.items()})
            oos = oos.assign(p=oos["p" + chosen])
            for f in folds:  # μετρήσεις ανά περίοδο για την επιλεγμένη παραλλαγή (για τον έλεγχο σταθερότητας)
                fo = oos[oos["fold"] == f["fold"] - 1]
                fm = M3.evaluate(fo, kind=kind)
                f.update(auc=fm.get("auc"), ic_mean=fm["ic_mean"], top_decile_R=fm["top_decile_R"], avg_R_all=fm["avg_R_all"])
            pcols = [c for c in oos.columns if c.startswith("p") and c != "p"]
            calib, cal, oos_c = M3.calibrate(oos.drop(columns=pcols), kind)
            m4 = _honest(M3.evaluate(oos, kind=kind), oos, "p", kind, cfg["H"])
            cal3_iso, cal3, _ = M3.calibrate(oos.assign(p=oos["p3"]).drop(columns=pcols), kind)
            m3 = _honest(M3.evaluate(oos.assign(p=oos["p3"]), kind=kind), oos, "p3", kind, cfg["H"])
            folds3 = [{"top_decile_R": f["v3"]["top_decile_R"], "ic_mean": f["v3"]["ic_mean"]} for f in folds]
            ok4, gate4 = M3.validation_gate(m4, cal, folds)
            ok3, gate3 = M3.validation_gate(m3, cal3, folds3)
            note = f"ℹ Το t είναι διορθωμένο για επικάλυψη ημερών (Newey-West, {m4.get('nw_lag')} ημ.) — αυστηρότερο από το απλό {m4.get('ic_t_raw')}"
            gate4.append(note)
            if chosen.startswith("S"):  # διόρθωση για τις πολλές δοκιμές της αυτόματης αναζήτησης
                need = need_for(kind, ast["tried"])
                val = (m4.get("ic_t") if kind == "rank" else m4.get("auc")) or 0
                passed = val >= need
                gate4.append(("✓ " if passed else "✗ ") + f"Διόρθωση για {ast['tried']} δοκιμές της αυτόματης αναζήτησης: "
                             f"χρειάζεται {'t' if kind == 'rank' else 'AUC'} ≥ {need} (έχει {val})")
                ok4 = bool(ok4 and passed)
            gate4.append(f"ℹ Επιλέχθηκε η παραλλαγή {chosen} ({vdesc.get(chosen, chosen)}) από τις " + ", ".join(
                f"{v}: " + (f"t {var_m[v]['icT']}" if kind == "rank" else f"AUC {var_m[v]['auc']}") for v in sel))
            if cfgs:
                gate4.append(f"ℹ Αυτόματη αναζήτηση: απόψε {len(new_try)} νέοι συνδυασμοί ({len(cand)} ολοκληρώθηκαν), "
                             f"συνολικά {ast['tried']}. " + ("Βρέθηκε καλύτερος συνδυασμός και κρατήθηκε." if changed
                                                              else "Ο καλύτερος μέχρι τώρα δεν ξεπεράστηκε."))
            better, cmp_notes = _better(m4, m3, kind)
            active = bool(ok4 and better)
            _step(f"{cfg['label']} (v4): τελικό μοντέλο σε όλο το ιστορικό", base_pct + 0.85 * span)
            data = P[P[f"y_{hz}"].notna() & P[f"R_{hz}"].notna()]
            if kind == "rank":
                data = data[data[f"y4_{hz}"].notna()]
            if chosen == "E":
                ens = fit_e(kind, data, hz, cfg["H"], seed0=100)
            elif chosen.startswith("S"):
                ens = fit_auto(kind, data, hz, cfg["H"], cfgs[chosen], seed0=100)
            else:
                ens = fit_v4(kind, data, hz, cfg["H"], seed0=100, variant=chosen)
            imp = _importance(ens)
            path = MODEL_DIR / f"model4_{hz}.joblib"
            joblib.dump({"model": ens, "calibrator": calib, "features": FEATURES_V4, "horizon": hz, "kind": kind,
                         "cal_table": cal.get("table", []), "trained_at": db.now_iso(), "version": VERSION,
                         "data_end": str(P["date"].max().date())}, path)
            secs = round(time.time() - ht0)
            per_hz.append(secs)
            auto_out = {"tried": ast["tried"], "tonight": len(new_try), "completed": len(cand), "changed": changed,
                        "champion": cfg_text(ast["champion"]), "championScore": ast.get("champion_score"),
                        "need": need_for(kind, ast["tried"]), "seconds": ainfo.get("seconds")}
            comp = {"better": better, "notes": cmp_notes, "v3_gate": gate3, "v3_validated": ok3, "variant": chosen,
                    "variants": var_m, "variantNames": {k: vdesc.get(k, k) for k in var_m}, "auto": auto_out}
            metrics = {"oos": m4, "calibration": cal, "folds": folds, "gate": gate4, "kind": kind, "horizon_cfg": cfg,
                       "train_seconds": secs, "n_tickers": int(P["ticker"].nunique()), "panel_rows": int(len(P)),
                       "n_features": len(FEATURES_V4), "n_new_features": len(NEW_FEATURES), "throughput": stats,
                       "engine": M3.engine_name() + (" + LambdaRank" if kind == "rank" and len(ens.models) > 1 else "")}
            db.execute("INSERT INTO ml4_models(horizon,created_at,path,validated,active,metrics_json,baseline_json,compare_json,"
                       "calib_json,importance_json,n_train,data_end) VALUES(?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(horizon) DO UPDATE SET "
                       "created_at=excluded.created_at, path=excluded.path, validated=excluded.validated, active=excluded.active, "
                       "metrics_json=excluded.metrics_json, baseline_json=excluded.baseline_json, compare_json=excluded.compare_json, "
                       "calib_json=excluded.calib_json, importance_json=excluded.importance_json, n_train=excluded.n_train, "
                       "data_end=excluded.data_end",
                       (hz, db.now_iso(), str(path), int(ok4), int(active), json.dumps(metrics, default=str),
                        json.dumps({"oos": m3, "gate": gate3, "validated": ok3}, default=str), json.dumps(comp, default=str),
                        json.dumps(cal, default=str), json.dumps(imp[:60]), int(len(data)), str(P["date"].max().date())))
            results[hz] = {"validated": ok4, "active": active, "better": better, "gate": gate4, "compare": cmp_notes,
                           "v3_validated": ok3, "seconds": secs, "variant": chosen, "variants": var_m, "auto": auto_out}
            _cache.pop(hz, None)
            del oos, oos_c, data, ens
            gc.collect()
        del P
        gc.collect()
        if results:
            _step("Πρόβλεψη v4 για σήμερα σε όλη την αγορά", 99)
            try:
                predict_today(tickers)
            except Exception as e:  # noqa: BLE001
                log.warning("v4 predict after training failed: %s", e)
        db.kv_set("ml4_trained_at", db.now_iso())
        _step(f"Ολοκληρώθηκε σε {round((time.time() - t0) / 60, 1)} λεπτά", 100)
        return {"status": "ok", "results": results, "skipped": skipped, "throughput": stats}
    except Exception as e:  # noqa: BLE001
        log.exception("ML4 training failed")
        _progress["error"] = repr(e)[:400]
        _step(f"Σφάλμα: {e}")
        return {"status": "error", "error": str(e)}
    finally:
        _progress["running"] = False
        _progress["horizon"] = None


# ------------------------------------------------------------------ πρόβλεψη
def load(hz: str) -> dict | None:
    import joblib
    try:
        init()
        row = db.q1("SELECT * FROM ml4_models WHERE horizon=?", (hz,))
    except Exception:  # noqa: BLE001
        return None
    if not row:
        return None
    c = _cache.get(hz)
    if c and c["created_at"] == row["created_at"]:
        return c
    try:
        obj = joblib.load(row["path"])
    except Exception as e:  # noqa: BLE001
        log.warning("cannot load v4 model %s: %s", hz, e)
        return None
    if obj.get("features") != FEATURES_V4:
        return None
    obj.update(created_at=row["created_at"], validated=bool(row["validated"]), active=bool(row["active"]),
               importance=json.loads(row["importance_json"] or "[]"))
    _cache[hz] = obj
    return obj


def predict_today(tickers: list[str] | None = None) -> dict:
    models = {hz: load(hz) for hz in F.HORIZONS}
    models = {k: v for k, v in models.items() if v}
    if not models:
        return {"status": "no_model"}
    from ..data.listings import universe_tickers
    tickers = tickers or universe_tickers()
    P = build_panel(tickers, with_labels=False, last_only=True)
    X = P[FEATURES_V4].to_numpy(np.float32)
    rows = []
    for hz, m in models.items():
        raw = m["model"].predict(X)
        if m["kind"] == "rank":
            pc = pd.Series(raw).rank(pct=True).to_numpy()
            rk = pc
        else:
            pc = m["calibrator"].predict(raw) if m.get("calibrator") is not None else raw
            rk = pd.Series(pc).rank(pct=True).to_numpy()
        for t, d, a, r in zip(P["ticker"], P["date"], pc, rk):
            rows.append((t, str(d.date()), hz, float(a), float(r), M3.expected_R(float(a), m["cal_table"]), db.now_iso()))
    db.executemany("INSERT INTO ml4_predictions(ticker,date,horizon,p,rank_pct,exp_r,created_at) VALUES(?,?,?,?,?,?,?) "
                   "ON CONFLICT(ticker,date,horizon) DO UPDATE SET p=excluded.p, rank_pct=excluded.rank_pct, "
                   "exp_r=excluded.exp_r, created_at=excluded.created_at", rows)
    old = (pd.Timestamp.today() - pd.Timedelta(days=40)).strftime("%Y-%m-%d")
    db.execute("DELETE FROM ml4_predictions WHERE date<?", (old,))
    _cache["latest_panel"] = P.set_index("ticker")
    try:
        P.to_pickle(DATA_DIR / "ml4_latest.pkl")
    except Exception:  # noqa: BLE001
        pass
    db.kv_set("ml4_predicted_at", db.now_iso())
    return {"status": "ok", "date": str(P["date"].max().date()), "n": int(len(P))}


def _latest_panel() -> pd.DataFrame | None:
    P = _cache.get("latest_panel")
    if P is None:
        f = DATA_DIR / "ml4_latest.pkl"
        if f.exists():
            try:
                P = pd.read_pickle(f).set_index("ticker")
                _cache["latest_panel"] = P
            except Exception:  # noqa: BLE001
                return None
    return P


def active_horizons() -> dict[str, bool]:
    try:
        init()
        return {r["horizon"]: bool(r["active"]) for r in db.q("SELECT horizon, active FROM ml4_models")}
    except Exception:  # noqa: BLE001
        return {}


def overlay(ml: dict) -> dict:
    """Για τους ορίζοντες όπου το v4 είναι ενεργό (επικυρωμένο ΚΑΙ καλύτερο από το v3), οι προβλέψεις του v4
    παίρνουν τη θέση του v3 στο score/signals. Αν δεν υπάρχει τίποτα ενεργό, δεν αλλάζει τίποτα."""
    act = [h for h, a in active_horizons().items() if a]
    if not act:
        return ml
    rows = db.q(f"SELECT ticker, horizon, p, rank_pct, exp_r, date FROM ml4_predictions WHERE horizon IN "
                f"({','.join('?' * len(act))}) AND date=(SELECT MAX(date) FROM ml4_predictions)", act)
    for r in rows:
        r["validated"] = True
        r["model"] = VERSION
        ml.setdefault(r["ticker"], {})[r["horizon"]] = r
    return ml


def prediction_for(ticker: str) -> dict:
    out = {}
    try:
        init()
        rows = db.q("SELECT * FROM ml4_predictions WHERE ticker=? AND date=(SELECT MAX(date) FROM ml4_predictions WHERE ticker=?)",
                    (ticker, ticker))
    except Exception:  # noqa: BLE001
        return out
    P = _latest_panel()
    for r in rows:
        hz = r["horizon"]
        m = load(hz)
        if not m or hz not in F.HORIZONS:
            continue
        cfg = F.HORIZONS[hz]
        item = {"horizon": hz, "kind": cfg["kind"], "label": cfg["label"], "p": r["p"], "rank_pct": r["rank_pct"],
                "exp_r": r["exp_r"], "date": r["date"], "validated": m["validated"], "active": m["active"], "days": cfg["H"],
                "version": VERSION, "drivers": []}
        if cfg["kind"] == "barrier":
            item.update(breakeven=round(cfg["dn"] / (cfg["up"] + cfg["dn"]), 3))
        if P is not None and ticker in P.index:
            x = P.loc[[ticker], FEATURES_V4]
            con = m["model"].contrib(x.to_numpy(np.float32))
            if con is not None:
                c = con[0]
                order = np.argsort(-np.abs(c))[:10]
                tot = float(np.abs(c).sum()) or 1.0
                for j in order:
                    val = x.iloc[0, j]
                    item["drivers"].append({"feature": FEATURES_V4[j], "label": label(FEATURES_V4[j]),
                                            "value": None if pd.isna(val) else round(float(val), 4),
                                            "effect": round(float(c[j]) / tot, 4)})
        out[hz] = item
    return out


def status() -> dict:
    out = {}
    try:
        init()
        rows = db.q("SELECT * FROM ml4_models")
    except Exception:  # noqa: BLE001
        rows = []
    for r in rows:
        if r["horizon"] not in F.HORIZONS:
            continue
        out[r["horizon"]] = {"created_at": r["created_at"], "validated": bool(r["validated"]), "active": bool(r["active"]),
                             "n_train": r["n_train"], "data_end": r["data_end"], "metrics": json.loads(r["metrics_json"] or "{}"),
                             "baseline": json.loads(r["baseline_json"] or "{}"), "compare": json.loads(r["compare_json"] or "{}"),
                             "importance": json.loads(r["importance_json"] or "[]")[:20],
                             "label": F.HORIZONS[r["horizon"]]["label"], "kind": F.HORIZONS[r["horizon"]]["kind"]}
    last = None
    try:
        last = (db.q1("SELECT MAX(date) d FROM ml4_predictions") or {}).get("d")
    except Exception:  # noqa: BLE001
        pass
    return {"version": VERSION, "models": out, "progress": progress(), "last_prediction_date": last,
            "n_features": len(FEATURES_V4), "n_new_features": len(NEW_FEATURES), "trained_at": db.kv_get("ml4_trained_at")}
