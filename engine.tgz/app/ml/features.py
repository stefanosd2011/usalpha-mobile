"""Χαρακτηριστικά (features) και στόχοι (labels) για το μοντέλο πρόβλεψης.

ΚΑΝΟΝΑΣ: κάθε feature στη γραμμή t χρησιμοποιεί ΜΟΝΟ δεδομένα έως και το κλείσιμο της t.
Ο στόχος (label) κοιτάει το μέλλον (t+1 ... t+H) και χρησιμοποιείται μόνο στην εκπαίδευση.

Στόχος = "triple barrier", ίδιος με τα trading signals:
  είσοδος στο άνοιγμα της t+1, stop = είσοδος − k_dn·ATR, στόχος = είσοδος + k_up·ATR,
  επιτυχία αν ο στόχος χτυπηθεί ΠΡΙΝ το stop μέσα σε H ημέρες. Αν την ίδια μέρα αγγίζονται και τα δύο,
  θεωρείται ότι χτυπήθηκε πρώτα το stop (συντηρητικά). Λήξη χρόνου = αποτυχία.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from ..analysis import indicators as ind

HORIZONS = {
    # barrier: ίδια επίπεδα με τα trading signals (stop_atr, TP1 = 1.5R).
    # day: είσοδος στο αυριανό άνοιγμα, στόχος +1 ATR πριν −0.67 ATR ΜΕΣΑ στην ίδια μέρα (day trade)
    "day": {"kind": "barrier", "H": 1, "up": 1.0, "dn": 0.67, "label": "Day trade (αύριο)"},
    "short": {"kind": "barrier", "H": 5, "up": 1.8, "dn": 1.2, "label": "Βραχυπρόθεσμο (5 ημ.)"},
    "swing": {"kind": "barrier", "H": 25, "up": 3.0, "dn": 2.0, "label": "Swing (25 ημ.)"},
    # rank: ποια μετοχή θα πάει ΚΑΛΥΤΕΡΑ από τις υπόλοιπες (ανεξάρτητα από το αν ανεβαίνει ή πέφτει η αγορά)
    "rank5": {"kind": "rank", "H": 5, "label": "Κατάταξη 5 ημ. (ποιες θα πάνε καλύτερα)"},
    "rank21": {"kind": "rank", "H": 21, "label": "Κατάταξη 1 μήνα (ποιες θα πάνε καλύτερα)"},
}
BARRIER = [h for h, c in HORIZONS.items() if c["kind"] == "barrier"]
RANKS = [h for h, c in HORIZONS.items() if c["kind"] == "rank"]
# ποιο μοντέλο κατάταξης φιλτράρει ποια κατηγορία signals
RANK_FOR_SIGNAL = {"day": "rank5", "short": "rank5", "swing": "rank21", "invest": "rank21"}

TICKER_FEATURES = [
    "ret_1", "ret_3", "ret_5", "ret_10", "ret_21", "ret_63", "ret_126", "ret_252",
    "vol_10", "vol_21", "vol_63", "vol_ratio", "atr_pct", "rsi_14", "rsi_2", "stoch_k", "macd_norm",
    "dist_ema20", "dist_ema50", "dist_sma200", "ema20_slope", "sma50_slope", "bb_pos", "bb_width",
    "adx", "di_diff", "pos_52w", "dist_hi52", "brk_20", "rvol", "rvol_5", "log_dvol", "ud_vol",
    "gap", "clv", "range_pct", "up_days_10", "log_price", "max_ret_21", "min_ret_21",
    "clv_5", "gap_avg_10", "dist_vwap20", "cons_days", "since_hi52", "squeeze_pct", "dd_21", "vol_trend",
    "range_trend", "ret_1_z",
]
MARKET_FEATURES = ["spy_ret_5", "spy_ret_21", "spy_dist_sma200", "vix", "vix_chg_5",
                   "breadth_50", "mkt_ret_1", "mkt_ret_5", "dispersion_5"]
EXCESS_FEATURES = ["ex_ret_5", "ex_ret_21", "ex_ret_63"]
EARN_FEATURES = ["e_days_since", "e_reaction", "e_reaction_raw", "e_vol_spike", "e_count_1y", "e_days_to_next"]
FUND_FEATURES = ["f_rev_growth", "f_rev_q_yoy", "f_rev_accel", "f_eps_growth", "f_ni_growth", "f_gross_margin",
                 "f_op_margin", "f_net_margin", "f_roa", "f_roe", "f_accruals", "f_cfo_assets", "f_asset_growth",
                 "f_shares_growth", "f_leverage", "f_cash_assets", "f_loss", "f_earn_yield", "f_sales_yield",
                 "f_book_yield", "f_cfo_yield", "f_days_since_filing", "f_log_mcap"]
SECTOR_FEATURES = ["sec_rel_5", "sec_rel_21", "sec_rel_63", "sec_mom_rank"]
CS_SOURCES = TICKER_FEATURES + FUND_FEATURES + ["e_reaction", "e_days_since", "ex_ret_5", "ex_ret_21", "ex_ret_63"]
RANK_SOURCES = CS_SOURCES  # συμβατότητα
RANK_FEATURES = [f"cs_{c}" for c in CS_SOURCES]
FEATURES = (TICKER_FEATURES + FUND_FEATURES + EARN_FEATURES + MARKET_FEATURES + EXCESS_FEATURES
            + SECTOR_FEATURES + RANK_FEATURES)

FEATURE_LABELS = {
    "ret_1": "Απόδοση 1 ημ.", "ret_3": "Απόδοση 3 ημ.", "ret_5": "Απόδοση 1 εβδ.", "ret_10": "Απόδοση 2 εβδ.",
    "ret_21": "Απόδοση 1 μήνα", "ret_63": "Απόδοση 3 μηνών", "ret_126": "Απόδοση 6 μηνών", "ret_252": "Απόδοση 1 έτους",
    "vol_10": "Μεταβλητότητα 10ημ", "vol_21": "Μεταβλητότητα 1μ", "vol_63": "Μεταβλητότητα 3μ",
    "vol_ratio": "Αλλαγή μεταβλητότητας", "atr_pct": "ATR %", "rsi_14": "RSI 14", "rsi_2": "RSI 2 (βραχ. αντιστροφή)",
    "stoch_k": "Stoch RSI", "macd_norm": "MACD histogram", "dist_ema20": "Απόσταση από EMA20",
    "dist_ema50": "Απόσταση από EMA50", "dist_sma200": "Απόσταση από SMA200", "ema20_slope": "Κλίση EMA20",
    "sma50_slope": "Κλίση SMA50", "bb_pos": "Θέση στις Bollinger", "bb_width": "Πλάτος Bollinger",
    "adx": "ADX (δύναμη τάσης)", "di_diff": "+DI − −DI", "pos_52w": "Θέση στο εύρος 52 εβδ.",
    "dist_hi52": "Απόσταση από υψηλό 52 εβδ.", "brk_20": "Breakout υψηλού 20ημ", "rvol": "Σχετικός όγκος (RVOL)",
    "rvol_5": "Όγκος 5ημ vs μέσος", "log_dvol": "Ημερήσιος τζίρος ($)", "ud_vol": "Όγκος ανόδου vs πτώσης",
    "gap": "Gap ανοίγματος", "clv": "Θέση κλεισίματος στη μέρα", "range_pct": "Εύρος ημέρας %",
    "up_days_10": "Ανοδικές μέρες (10)", "log_price": "Επίπεδο τιμής", "max_ret_21": "Μέγιστη ημερ. άνοδος 1μ",
    "min_ret_21": "Μέγιστη ημερ. πτώση 1μ", "spy_ret_5": "S&P 500 1 εβδ.", "spy_ret_21": "S&P 500 1 μήνα",
    "spy_dist_sma200": "S&P 500 vs SMA200", "vix": "VIX", "vix_chg_5": "Μεταβολή VIX 1 εβδ.",
    "clv_5": "Θέση κλεισίματος (μέσος 5ημ)", "gap_avg_10": "Μέσο gap ανοίγματος 10ημ",
    "dist_vwap20": "Απόσταση από VWAP 20ημ", "cons_days": "Συνεχόμενες μέρες άνοδος(+)/πτώση(−)",
    "since_hi52": "Μέρες από υψηλό 52εβδ", "squeeze_pct": "Συμπίεση μεταβλητότητας", "dd_21": "Πτώση από υψηλό 1μ",
    "vol_trend": "Τάση όγκου (5 vs 60 ημ)", "range_trend": "Τάση εύρους ημέρας", "ret_1_z": "Σημερινή κίνηση σε σ",
    "breadth_50": "Αγορά: % μετοχών πάνω από EMA50", "mkt_ret_1": "Αγορά: μέση κίνηση ημέρας",
    "mkt_ret_5": "Αγορά: μέση κίνηση εβδομάδας", "dispersion_5": "Αγορά: διασπορά αποδόσεων",
    "ex_ret_5": "Υπεραπόδοση vs S&P 1 εβδ.", "ex_ret_21": "Υπεραπόδοση vs S&P 1μ", "ex_ret_63": "Υπεραπόδοση vs S&P 3μ",
    **{f"cs_{c}": "Κατάταξη στην αγορά: " + c for c in RANK_SOURCES},
}
FEATURE_LABELS.update({
    "e_days_since": "Μέρες από τα τελευταία αποτελέσματα", "e_reaction": "Αντίδραση τιμής στα αποτελέσματα (vs αγορά)",
    "e_reaction_raw": "Κίνηση τιμής στα αποτελέσματα", "e_vol_spike": "Όγκος στα αποτελέσματα vs κανονικό",
    "e_count_1y": "Ανακοινώσεις αποτελεσμάτων (12μ)", "e_days_to_next": "Εκτίμηση ημερών ως τα επόμενα αποτελέσματα",
    "f_rev_growth": "Αύξηση εσόδων (12μ)", "f_rev_q_yoy": "Αύξηση εσόδων τριμήνου", "f_rev_accel": "Επιτάχυνση εσόδων",
    "f_eps_growth": "Αύξηση EPS (12μ)", "f_ni_growth": "Αύξηση καθαρών κερδών", "f_gross_margin": "Μικτό περιθώριο",
    "f_op_margin": "Λειτουργικό περιθώριο", "f_net_margin": "Καθαρό περιθώριο", "f_roa": "Απόδοση ενεργητικού (ROA)",
    "f_roe": "Απόδοση ιδίων κεφαλαίων (ROE)", "f_accruals": "Ποιότητα κερδών (accruals)",
    "f_cfo_assets": "Λειτουργικές ταμειακές ροές / ενεργητικό", "f_asset_growth": "Αύξηση ενεργητικού",
    "f_shares_growth": "Αύξηση μετοχών (dilution)", "f_leverage": "Μόχλευση", "f_cash_assets": "Μετρητά / ενεργητικό",
    "f_loss": "Ζημιογόνα", "f_earn_yield": "Απόδοση κερδών (E/P)", "f_sales_yield": "Πωλήσεις / κεφαλαιοποίηση",
    "f_book_yield": "Λογιστική αξία / τιμή", "f_cfo_yield": "Ταμειακές ροές / κεφαλαιοποίηση",
    "f_days_since_filing": "Μέρες από την τελευταία οικονομική κατάσταση", "f_log_mcap": "Μέγεθος (κεφαλαιοποίηση)",
    "sec_rel_5": "Απόδοση vs κλάδος (1 εβδ.)", "sec_rel_21": "Απόδοση vs κλάδος (1μ)", "sec_rel_63": "Απόδοση vs κλάδος (3μ)",
    "sec_mom_rank": "Δύναμη κλάδου",
})
FEATURE_LABELS.update({f"cs_{c}": "Κατάταξη: " + FEATURE_LABELS.get(c, c) for c in CS_SOURCES})
FEATURE_LABELS.update({"cs_ret_5": "Κατάταξη απόδοσης 1 εβδ.", "cs_ret_21": "Κατάταξη απόδοσης 1μ",
                       "cs_ret_63": "Κατάταξη απόδοσης 3μ", "cs_ret_126": "Κατάταξη απόδοσης 6μ",
                       "cs_rvol": "Κατάταξη σχετικού όγκου", "cs_vol_21": "Κατάταξη μεταβλητότητας",
                       "cs_dist_hi52": "Κατάταξη κοντά σε υψηλό 52εβδ", "cs_log_dvol": "Κατάταξη ρευστότητας",
                       "cs_atr_pct": "Κατάταξη ATR %"})


def ticker_features(d: pd.DataFrame) -> pd.DataFrame:
    """d: open/high/low/close/volume (ταξινομημένο κατά ημερομηνία)."""
    c, h, l, o = d["close"], d["high"], d["low"], d["open"]
    v = d["volume"].fillna(0)
    lr = np.log(c).diff()
    f = pd.DataFrame(index=d.index)
    for n in (1, 3, 5, 10, 21, 63, 126, 252):
        f[f"ret_{n}"] = np.log(c / c.shift(n))
    f["vol_10"] = lr.rolling(10).std()
    f["vol_21"] = lr.rolling(21).std()
    f["vol_63"] = lr.rolling(63).std()
    f["vol_ratio"] = f["vol_10"] / f["vol_63"]
    tr = pd.concat([h - l, (h - c.shift()).abs(), (l - c.shift()).abs()], axis=1).max(axis=1)
    atr = ind.wilder(tr, 14)
    f["atr"] = atr  # βοηθητικό (για labels), όχι feature
    f["atr_pct"] = atr / c
    f["rsi_14"] = ind.rsi(c, 14)
    f["rsi_2"] = ind.rsi(c, 2)
    k, _ = ind.stoch_rsi(c)
    f["stoch_k"] = k
    _, _, hist = ind.macd(c)
    f["macd_norm"] = hist / atr
    ema20, ema50 = ind.ema(c, 20), ind.ema(c, 50)
    sma50, sma200 = ind.sma(c, 50), ind.sma(c, 200)
    f["dist_ema20"] = c / ema20 - 1
    f["dist_ema50"] = c / ema50 - 1
    f["dist_sma200"] = c / sma200 - 1
    f["ema20_slope"] = ema20 / ema20.shift(5) - 1
    f["sma50_slope"] = sma50 / sma50.shift(10) - 1
    up, mid, lo = ind.bollinger(c)
    f["bb_pos"] = (c - lo) / (up - lo).replace(0, np.nan)
    f["bb_width"] = (up - lo) / mid
    adx, pdi, mdi = ind.adx(d)
    f["adx"] = adx
    f["di_diff"] = pdi - mdi
    hi252 = h.rolling(252, min_periods=126).max()
    lo252 = l.rolling(252, min_periods=126).min()
    f["pos_52w"] = (c - lo252) / (hi252 - lo252).replace(0, np.nan)
    f["dist_hi52"] = c / hi252 - 1
    f["brk_20"] = c / h.shift(1).rolling(20).max() - 1
    avgv = v.shift(1).rolling(20, min_periods=10).mean().replace(0, np.nan)
    f["rvol"] = v / avgv
    f["rvol_5"] = v.rolling(5).mean() / avgv
    dv = (c * v).rolling(20, min_periods=10).mean()
    f["log_dvol"] = np.log1p(dv)
    f["dvol20"] = dv  # βοηθητικό (φίλτρο ρευστότητας)
    sv = (np.sign(lr) * v).rolling(20).sum()
    f["ud_vol"] = sv / v.rolling(20).sum().replace(0, np.nan)
    f["gap"] = o / c.shift(1) - 1
    rng = (h - l).replace(0, np.nan)
    f["clv"] = (c - l) / rng
    f["range_pct"] = (h - l) / c
    f["up_days_10"] = (lr > 0).astype(float).rolling(10).mean()
    f["log_price"] = np.log(c)
    f["max_ret_21"] = lr.rolling(21).max()
    f["min_ret_21"] = lr.rolling(21).min()
    # --- πρόσθετα (ροή όγκου, συμπίεση, θέση κλεισίματος, συνέχεια κίνησης)
    f["clv_5"] = f["clv"].rolling(5).mean()
    f["gap_avg_10"] = f["gap"].rolling(10).mean()
    tp = (h + l + c) / 3
    vw = (tp * v).rolling(20, min_periods=10).sum() / v.rolling(20, min_periods=10).sum().replace(0, np.nan)
    f["dist_vwap20"] = c / vw - 1
    sgn = np.sign(lr).fillna(0)
    grp = (sgn != sgn.shift()).cumsum()
    f["cons_days"] = sgn.groupby(grp).cumcount().add(1) * sgn
    hv = h.to_numpy(float)
    since = np.full(len(hv), np.nan)
    if len(hv) >= 252:
        win = np.lib.stride_tricks.sliding_window_view(hv, 252)
        since[251:] = (251 - np.nanargmax(np.where(np.isnan(win), -np.inf, win), axis=1)) / 252
    f["since_hi52"] = since
    bbw = f["bb_width"]
    f["squeeze_pct"] = bbw.rolling(126, min_periods=60).rank(pct=True)
    f["dd_21"] = c / c.rolling(21).max() - 1
    f["vol_trend"] = np.log((v.rolling(5).mean() + 1) / (v.rolling(60, min_periods=30).mean() + 1))
    rp = (h - l) / c
    f["range_trend"] = np.log(rp.rolling(5).mean() / rp.rolling(60, min_periods=30).mean())
    f["ret_1_z"] = lr / lr.rolling(63, min_periods=30).std()
    f["close"] = c
    return f.replace([np.inf, -np.inf], np.nan)


def market_features(spy: pd.DataFrame, vix: pd.DataFrame) -> pd.DataFrame:
    c = spy["close"]
    m = pd.DataFrame(index=spy.index)
    m["spy_ret_5"] = np.log(c / c.shift(5))
    m["spy_ret_21"] = np.log(c / c.shift(21))
    m["spy_ret_63"] = np.log(c / c.shift(63))
    m["spy_dist_sma200"] = c / c.rolling(200).mean() - 1
    if vix is not None and not vix.empty:
        vc = vix["close"].reindex(spy.index).ffill()
        m["vix"] = vc
        m["vix_chg_5"] = np.log(vc / vc.shift(5))
    else:
        m["vix"] = np.nan
        m["vix_chg_5"] = np.nan
    return m


def triple_barrier(d: pd.DataFrame, atr: pd.Series, H: int, up_k: float, dn_k: float,
                   cost_bps: float = 10.0) -> tuple[np.ndarray, np.ndarray]:
    """Επιστρέφει (label 0/1/NaN, realized R). Τιμές στο τέλος της σειράς (χωρίς μέλλον) = NaN."""
    o = d["open"].to_numpy(float)
    hi = d["high"].to_numpy(float)
    lo = d["low"].to_numpy(float)
    cl = d["close"].to_numpy(float)
    a = atr.to_numpy(float)
    n = len(o)
    label = np.full(n, np.nan)
    R = np.full(n, np.nan)
    if n <= H + 1:
        return label, R
    idx = np.arange(n - H - 1)  # χρειάζονται t+1..t+H
    entry = o[idx + 1]
    risk = dn_k * a[idx]
    up = entry + up_k * a[idx]
    dn = entry - risk
    J = np.arange(1, H + 1)
    HH = hi[idx[:, None] + J]
    LL = lo[idx[:, None] + J]
    OO = o[idx[:, None] + J]
    hit_dn = LL <= dn[:, None]
    hit_up = HH >= up[:, None]
    first_dn = np.where(hit_dn.any(1), hit_dn.argmax(1), H)
    first_up = np.where(hit_up.any(1), hit_up.argmax(1), H)
    success = first_up < first_dn  # ίδια μέρα => stop πρώτα
    stopped = (first_dn < H) & ~success
    cost = 2 * cost_bps / 10000 * entry
    # stop: αν η μετοχή άνοιξε με gap κάτω από το stop, η εκτέλεση γίνεται στο άνοιγμα (χειρότερα από −1R)
    fd = np.minimum(first_dn, H - 1)
    stop_fill = np.where(fd > 0, np.minimum(OO[np.arange(len(idx)), fd], dn), dn)
    exit_close = cl[idx + H]
    pnl = np.where(success, up - entry, np.where(stopped, stop_fill - entry, exit_close - entry)) - cost
    valid = np.isfinite(entry) & np.isfinite(a[idx]) & (a[idx] > 0)
    label[idx] = np.where(valid, success.astype(float), np.nan)
    R[idx] = np.where(valid, pnl / risk, np.nan)
    return label, R


def earnings_features(dates: np.ndarray, close: np.ndarray, volume: np.ndarray, spy_lr: np.ndarray,
                      events: np.ndarray | None) -> dict[str, np.ndarray]:
    """Post-earnings drift features. Το γεγονός «ενεργοποιείται» την 2η μέρα συναλλαγών μετά την ανακοίνωση
    (όταν η αντίδραση είναι γνωστή) — καμία πληροφορία από το μέλλον."""
    n = len(dates)
    out = {k: np.full(n, np.nan, dtype=np.float32) for k in EARN_FEATURES}
    if events is None or len(events) == 0 or n < 30:
        return out
    pe = np.searchsorted(dates, events)            # πρώτη μέρα συναλλαγών >= ανακοίνωση
    ok = (pe >= 1) & (pe + 1 < n)
    pe = np.unique(pe[ok])
    if len(pe) == 0:
        return out
    lc = np.log(close)
    raw = lc[pe + 1] - lc[pe - 1]
    cs = np.r_[0, np.nancumsum(np.nan_to_num(spy_lr))]
    mkt = cs[pe + 2] - cs[pe]                       # spy_lr[i] = log(c_i/c_{i-1}) → άθροισμα των δύο ημερών
    react = raw - mkt
    avgv = np.array([np.nanmean(volume[max(0, p - 21):p - 1]) if p > 2 else np.nan for p in pe])
    spike = (volume[pe] + volume[pe + 1]) / 2 / np.where(avgv > 0, avgv, np.nan)
    eff = pe + 1                                     # διαθέσιμο από το κλείσιμο της pe+1
    idx = np.arange(n)
    k = np.searchsorted(eff, idx, side="right") - 1
    has = k >= 0
    kk = np.where(has, k, 0)
    out["e_days_since"] = np.where(has, idx - pe[kk], np.nan).astype(np.float32)
    out["e_reaction"] = np.where(has, react[kk], np.nan).astype(np.float32)
    out["e_reaction_raw"] = np.where(has, raw[kk], np.nan).astype(np.float32)
    out["e_vol_spike"] = np.where(has, spike[kk], np.nan).astype(np.float32)
    cnt = np.searchsorted(eff, idx, side="right") - np.searchsorted(eff, idx - 252, side="right")
    out["e_count_1y"] = cnt.astype(np.float32)
    gaps = np.diff(pe)
    if len(gaps):
        med = np.array([np.median(gaps[max(0, j - 4):j]) if j > 0 else np.nan for j in range(len(pe))])
        out["e_days_to_next"] = np.where(has, med[kk] - (idx - pe[kk]), np.nan).astype(np.float32)
    return out


def forward_returns(open_: np.ndarray, close: np.ndarray, H: int) -> np.ndarray:
    """Απόδοση με είσοδο στο αυριανό άνοιγμα και έξοδο στο κλείσιμο της t+H (εκτελέσιμη)."""
    n = len(close)
    out = np.full(n, np.nan)
    if n > H + 1:
        i = np.arange(n - H)
        valid = i + 1 < n
        i = i[valid]
        out[i] = np.log(close[i + H] / open_[i + 1])
    return out
