"""Μοντέλο πρόβλεψης v3 — LightGBM ensemble πάνω σε ΟΛΗ την αγορά ΗΠΑ.

Δεδομένα ανά μετοχή & ημέρα (~170 χαρακτηριστικά):
  τεχνικά & όγκος · αντίδραση στα αποτελέσματα (SEC 8-K) · οικονομικά point-in-time (SEC XBRL) ·
  αποτίμηση · σύγκριση με κλάδο · κατάταξη μέσα σε όλη την αγορά · κλίμα αγοράς.

Δύο είδη μοντέλων:
  barrier : «θα χτυπήσει τον στόχο πριν το stop;» (ίδια επίπεδα με τα signals) — day / 5 ημ. / 25 ημ.
  rank    : «ποιες μετοχές θα πάνε ΚΑΛΥΤΕΡΑ από τις υπόλοιπες;» — 5 ημ. / 1 μήνας. Αφαιρεί την κίνηση της
            αγοράς από τον στόχο, ώστε το μοντέλο να μαθαίνει να ξεχωρίζει μετοχές και όχι να μαντεύει την αγορά.

Έλεγχος (χωρίς διαρροή μελλοντικής πληροφορίας):
  purged walk-forward: εκπαίδευση μόνο στο παρελθόν, κενό ίσο με τον ορίζοντα, early stopping σε
  χρονικά μεταγενέστερο κομμάτι, έλεγχος σε έτος που το μοντέλο δεν έχει δει, επανάληψη μέχρι σήμερα.
  Ένα μοντέλο επηρεάζει score/signals ΜΟΝΟ αν περάσει αυστηρά κριτήρια out-of-sample.
"""
from __future__ import annotations

import gc
import json
import logging
import math
import time
from datetime import datetime, timezone

import numpy as np
import pandas as pd

from .. import db
from ..config import DATA_DIR, settings
from . import features as F

log = logging.getLogger("usalpha.ml")
MODEL_DIR = DATA_DIR / "models"
MAX_TRAIN_ROWS = 700_000
TARGET_PANEL_ROWS = 1_000_000
MIN_TRAIN_YEARS = 3.0

_progress = {"running": False, "step": "", "pct": 0, "started_at": None, "error": None}
_cache: dict = {}


def progress() -> dict:
    return dict(_progress)


def _step(msg: str, pct: float | None = None) -> None:
    _progress["step"] = msg
    if pct is not None:
        _progress["pct"] = round(pct, 1)
    log.info("ML: %s", msg)


def _lgb():
    try:
        import lightgbm  # noqa: F401
        return lightgbm
    except Exception:  # noqa: BLE001
        return None


def engine_name() -> str:
    return "LightGBM" if _lgb() else "scikit-learn HistGradientBoosting"


# ================================================================== βοηθητικά δεδομένων
def _load_prices(tickers: list[str], start: str | None) -> pd.DataFrame:
    frames = []
    for i in range(0, len(tickers), 800):
        part = tickers[i:i + 800]
        sql = (f"SELECT ticker,date,open,high,low,close,volume FROM prices_daily WHERE ticker IN "
               f"({','.join('?' * len(part))})" + (" AND date>=?" if start else ""))
        params = part + ([start] if start else [])
        frames.append(pd.read_sql_query(sql, db.conn(), params=params))
    if not frames:
        return pd.DataFrame()
    df = pd.concat(frames, ignore_index=True)
    df["date"] = pd.to_datetime(df["date"])
    return df


def _fund_features() -> dict[str, tuple[np.ndarray, pd.DataFrame]]:
    """Οικονομικά point-in-time ανά μετοχή: (ημερομηνίες διαθεσιμότητας, features). Cache σε μνήμη/δίσκο."""
    from ..data import secdata
    try:
        secdata.init()
        key_row = db.q1("SELECT COUNT(*) n, MAX(filed) m FROM fund_facts") or {}
    except Exception:  # noqa: BLE001
        return {}
    key = f"{key_row.get('n')}|{key_row.get('m')}"
    if not key_row.get("n"):
        return {}
    c = _cache.get("fund")
    if c and c[0] == key:
        return c[1]
    path = DATA_DIR / "fund_pit.pkl"
    ff = None
    if path.exists() and db.kv_get("fund_pit_key") == key:
        try:
            ff = pd.read_pickle(path)
        except Exception:  # noqa: BLE001
            ff = None
    if ff is None:
        t0 = time.time()
        ff = secdata.fundamental_features(secdata.fundamentals_pit())
        log.info("fundamental pit built in %.1fs (%d rows)", time.time() - t0, len(ff))
        try:
            ff.to_pickle(path)
            db.kv_set("fund_pit_key", key)
        except Exception:  # noqa: BLE001
            pass
    out = {}
    if ff is not None and not ff.empty:
        for t, g in ff.groupby("ticker", sort=False):
            # διαθέσιμο από την επόμενη μέρα της κατάθεσης (μπορεί να κατατέθηκε μετά το κλείσιμο)
            out[t] = ((g["avail"] + pd.Timedelta(days=1)).to_numpy("datetime64[ns]"), g.drop(columns=["ticker", "avail"]))
    _cache["fund"] = (key, out)
    return out


def _sector_map() -> dict[str, str]:
    m = {}
    try:
        from ..data import secdata
        m.update(secdata.sector_map())
    except Exception:  # noqa: BLE001
        pass
    try:
        for r in db.q("SELECT ticker, sector FROM company WHERE sector IS NOT NULL"):
            m.setdefault(r["ticker"], r["sector"])
    except Exception:  # noqa: BLE001
        pass
    return m


def _earn_events() -> dict[str, np.ndarray]:
    try:
        from ..data import secdata
        return secdata.earnings_events()
    except Exception:  # noqa: BLE001
        return {}


# ================================================================== panel
def build_panel(tickers: list[str], start: str | None = None, with_labels: bool = True,
                sample_every: int | None = None, last_only: bool = False, cost_bps: float | None = None,
                stats: dict | None = None) -> pd.DataFrame:
    t0 = time.time()
    spy, vix = db.load_prices("SPY"), db.load_prices("^VIX")
    if len(spy) < 260:
        raise RuntimeError("Λείπει ιστορικό SPY (χρειάζεται για τα features αγοράς)")
    mkt = F.market_features(spy, vix)
    date_pos = pd.Series(np.arange(len(mkt)), index=mkt.index)
    last_mkt = mkt.index[-1]
    cost_bps = settings.slippage_bps if cost_bps is None else cost_bps
    prices = _load_prices(tickers, start)
    if prices.empty:
        raise RuntimeError("Δεν υπάρχουν τιμές στη βάση")
    if sample_every is None:
        est = len(prices) * 0.85
        sample_every = max(1 if last_only else 2, int(math.ceil(est / TARGET_PANEL_ROWS)))
    fund = _fund_features()
    events = _earn_events()
    spy_c = spy["close"]
    n_raw = 0
    out = []
    keep_cols = F.TICKER_FEATURES + ["close", "dvol20"]
    for t, d in prices.groupby("ticker", sort=False):
        d = d.sort_values("date").set_index("date")
        if len(d) < (60 if last_only else 300):
            continue
        f = F.ticker_features(d)
        dates = d.index.to_numpy("datetime64[ns]")
        spy_lr = np.log(spy_c.reindex(d.index).ffill()).diff().to_numpy()
        ef = F.earnings_features(dates, d["close"].to_numpy(float), d["volume"].fillna(0).to_numpy(float),
                                 spy_lr, events.get(t))
        for k, v in ef.items():
            f[k] = v
        if with_labels:
            o, c = d["open"].to_numpy(float), d["close"].to_numpy(float)
            for hz, cfg in F.HORIZONS.items():
                if cfg["kind"] == "barrier":
                    lab, R = F.triple_barrier(d, f["atr"], cfg["H"], cfg["up"], cfg["dn"], cost_bps)
                    f[f"y_{hz}"] = lab
                    f[f"R_{hz}"] = R
                else:
                    f[f"fwd_{hz}"] = F.forward_returns(o, c, cfg["H"])
        if last_only:
            f = f.iloc[[-1]]
            if (last_mkt - f.index[-1]).days > 5:
                continue  # χωρίς πρόσφατη τιμή — δεν προβλέπουμε σε παλιά δεδομένα
        else:
            f = f.iloc[252:]
            pos = date_pos.reindex(f.index)
            f = f[pos.notna() & (pos % sample_every == 0)]
        f = f[(f["close"] >= settings.min_price) & (f["dvol20"] >= settings.universe_min_dollar_vol * 0.5)]
        if f.empty:
            continue
        n_raw += len(d)
        cols = keep_cols + F.EARN_FEATURES + (
            [c for c in f.columns if c.startswith(("y_", "R_", "fwd_"))] if with_labels else [])
        g = f[cols].astype(np.float32)
        # οικονομικά point-in-time
        fu = fund.get(t)
        if fu is not None:
            av, fdf = fu
            k = np.searchsorted(av, g.index.to_numpy("datetime64[ns]"), side="right") - 1
            has = k >= 0
            vals = fdf.to_numpy(np.float32)[np.where(has, k, 0)]
            vals[~has] = np.nan
            for j, col in enumerate(fdf.columns):
                g[col] = vals[:, j]
            g["f_days_since_filing"] = np.where(has, (g.index.to_numpy("datetime64[ns]") - av[np.where(has, k, 0)])
                                                / np.timedelta64(1, "D"), np.nan).astype(np.float32)
        g["ticker"] = t
        out.append(g)
    if not out:
        raise RuntimeError("Κενό panel")
    P = pd.concat(out)
    del out
    P.index.name = "date"
    P = P.reset_index()
    for col in F.FUND_FEATURES + ["_ni_ttm", "_rev_ttm", "_equity", "_cfo", "_shares"]:
        if col not in P:
            P[col] = np.float32(np.nan)
    # αποτιμήσεις με την κεφαλαιοποίηση της ΙΔΙΑΣ ημέρας
    mcap = (P["_shares"] * P["close"]).where(P["_shares"] > 0)
    P["f_earn_yield"] = (P["_ni_ttm"] / mcap).clip(-5, 5)
    P["f_sales_yield"] = (P["_rev_ttm"] / mcap).clip(0, 50)
    P["f_book_yield"] = (P["_equity"] / mcap).clip(-5, 20)
    P["f_cfo_yield"] = (P["_cfo"] / mcap).clip(-5, 5)
    P["f_log_mcap"] = np.log(mcap)
    P = P.drop(columns=["_ni_ttm", "_rev_ttm", "_equity", "_cfo", "_shares"])
    P = P.merge(mkt.reset_index().rename(columns={"index": "date", spy.index.name or "date": "date"}), on="date", how="left")
    P["ex_ret_5"] = P["ret_5"] - P["spy_ret_5"]
    P["ex_ret_21"] = P["ret_21"] - P["spy_ret_21"]
    P["ex_ret_63"] = P["ret_63"] - P["spy_ret_63"]
    g = P.groupby("date")
    P["breadth_50"] = g["dist_ema50"].transform(lambda x: (x > 0).mean())
    P["mkt_ret_1"] = g["ret_1"].transform("mean")
    P["mkt_ret_5"] = g["ret_5"].transform("mean")
    P["dispersion_5"] = g["ret_5"].transform("std")
    # σύγκριση με κλάδο
    smap = _sector_map()
    P["_sector"] = P["ticker"].map(smap).fillna("?")
    gs = P.groupby(["date", "_sector"])
    for n, src in ((5, "ret_5"), (21, "ret_21"), (63, "ret_63")):
        P[f"sec_rel_{n}"] = P[src] - gs[src].transform("median")
    sec_mom = gs["ret_63"].transform("median")
    P["sec_mom_rank"] = sec_mom.groupby(P["date"]).rank(pct=True)
    P.loc[P["_sector"] == "?", ["sec_rel_5", "sec_rel_21", "sec_rel_63", "sec_mom_rank"]] = np.nan
    P = P.drop(columns=["_sector"])
    # κατάταξη κάθε χαρακτηριστικού μέσα σε ΟΛΗ την αγορά της ίδιας ημέρας
    ranks = P.groupby("date")[F.CS_SOURCES].rank(pct=True).astype(np.float32)
    ranks.columns = [f"cs_{c}" for c in F.CS_SOURCES]
    P = pd.concat([P, ranks], axis=1)
    # στόχοι κατάταξης: υπεραπόδοση έναντι του μέσου όρου της αγοράς την ίδια μέρα
    if with_labels:
        for hz in F.RANKS:
            fw = P[f"fwd_{hz}"]
            P[f"R_{hz}"] = (fw - fw.groupby(P["date"]).transform("mean")).astype(np.float32)
            P[f"y_{hz}"] = fw.groupby(P["date"]).rank(pct=True).astype(np.float32)
            P[f"A_{hz}"] = fw.astype(np.float32)
            P = P.drop(columns=[f"fwd_{hz}"])
    for c in F.FEATURES:
        if c not in P:
            P[c] = np.float32(np.nan)
        elif P[c].dtype != np.float32:
            P[c] = P[c].astype(np.float32)
    secs = time.time() - t0
    if stats is not None:
        vals = int(n_raw) * 60 + int(len(P)) * len(F.FEATURES)
        stats.update(panel_rows=int(len(P)), raw_bars=int(n_raw), features=len(F.FEATURES), seconds=round(secs, 1),
                     values=vals, values_per_sec=int(vals / max(secs, 1e-3)), sample_every=sample_every)
    return P


# ================================================================== μοντέλα
class Ens:
    """Ensemble (μέσος όρος) μοντέλων. kind: barrier -> πιθανότητα, rank -> σκορ κατάταξης."""

    def __init__(self, models: list, kind: str):
        self.models, self.kind = models, kind

    def predict(self, X: np.ndarray) -> np.ndarray:
        if self.kind == "barrier":
            return np.mean([m.predict_proba(X)[:, 1] for m in self.models], axis=0)
        return np.mean([m.predict(X) for m in self.models], axis=0)

    def contrib(self, X: np.ndarray) -> np.ndarray | None:
        """SHAP τιμές ανά χαρακτηριστικό (μόνο LightGBM)."""
        try:
            parts = [m.booster_.predict(X, pred_contrib=True)[:, :-1] for m in self.models]
            return np.mean(parts, axis=0)
        except Exception:  # noqa: BLE001
            return None

    def gain_importance(self) -> np.ndarray | None:
        try:
            g = np.mean([m.booster_.feature_importance("gain") for m in self.models], axis=0)
            return g / max(g.sum(), 1e-12)
        except Exception:  # noqa: BLE001
            return None


def _fit_one(kind: str, Xtr, ytr, Xva, yva, seed: int):
    lgb = _lgb()
    if lgb is not None:
        params = dict(n_estimators=800, learning_rate=0.035, num_leaves=63, min_child_samples=400,
                      subsample=0.7, subsample_freq=1, colsample_bytree=0.55, reg_lambda=3.0,
                      n_jobs=-1, random_state=seed, verbose=-1, max_bin=127)
        m = lgb.LGBMClassifier(**params) if kind == "barrier" else lgb.LGBMRegressor(objective="regression", **params)
        cb = [lgb.early_stopping(50, verbose=False)]
        if Xva is not None and len(Xva) > 1000:
            try:
                m.fit(Xtr, ytr, eval_X=(Xva,), eval_y=(yva,), callbacks=cb)
            except TypeError:  # παλιότερες εκδόσεις LightGBM
                m.fit(Xtr, ytr, eval_set=[(Xva, yva)], callbacks=cb)
        else:
            m.set_params(n_estimators=250)
            m.fit(Xtr, ytr)
        return m
    from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor
    kw = dict(learning_rate=0.05, max_iter=400, max_leaf_nodes=31, min_samples_leaf=400, l2_regularization=1.0,
              early_stopping=True, validation_fraction=0.1, n_iter_no_change=25, random_state=seed)
    m = HistGradientBoostingClassifier(**kw) if kind == "barrier" else HistGradientBoostingRegressor(**kw)
    m.fit(Xtr, ytr)
    return m


def fit_ensemble(kind: str, data: pd.DataFrame, ycol: str, H: int, n_models: int = 1, seed0: int = 0,
                 max_rows: int = MAX_TRAIN_ROWS) -> Ens:
    """Early stopping σε ΧΡΟΝΙΚΑ μεταγενέστερο κομμάτι (τελευταίο 12%), με κενό ίσο με τον ορίζοντα."""
    dates = np.sort(data["date"].unique())
    cut = pd.Timestamp(dates[int(len(dates) * 0.88)])
    gap = pd.Timedelta(days=int(H * 1.5) + 3)
    tr = data[data["date"] < cut - gap]
    va = data[data["date"] >= cut]
    models = []
    for k in range(n_models):
        trs = tr.sample(n=max_rows, random_state=seed0 + k) if len(tr) > max_rows else tr
        vas = va.sample(n=min(len(va), 150_000), random_state=seed0 + k) if len(va) > 150_000 else va
        ytr = trs[ycol].to_numpy(int if kind == "barrier" else np.float32)
        yva = vas[ycol].to_numpy(int if kind == "barrier" else np.float32)
        models.append(_fit_one(kind, trs[F.FEATURES].to_numpy(np.float32), ytr,
                               vas[F.FEATURES].to_numpy(np.float32), yva, seed0 + k))
        del trs, vas
    return Ens(models, kind)


# ================================================================== αξιολόγηση
def _auc(y, p) -> float:
    from sklearn.metrics import roc_auc_score
    return float(roc_auc_score(y, p)) if len(np.unique(y)) > 1 else float("nan")


def _daily_ic(oos: pd.DataFrame, pcol: str, rcol: str = "R", spearman: bool = False) -> np.ndarray:
    ics = []
    for _, g in oos.groupby("date"):
        if len(g) >= 30 and g[rcol].std() > 0:
            r = g[rcol].rank() if spearman else g[rcol]
            ic = g[pcol].rank(pct=True).corr(r)
            if ic == ic:
                ics.append(ic)
    return np.array(ics)


def _deciles(oos: pd.DataFrame, pcol: str, extra: dict | None = None) -> tuple[list[dict], pd.DataFrame]:
    rk = oos.groupby("date")[pcol].rank(pct=True)
    dec = np.minimum((rk * 10).astype(int), 9)
    agg = {"n": ("R", "size"), "avg_R": ("R", "mean"), "avg_p": (pcol, "mean")}
    if "y" in oos and oos["y"].isin([0, 1]).all():
        agg["hit"] = ("y", "mean")
    else:
        oos = oos.assign(_beat=(oos["R"] > 0).astype(float))
        agg["hit"] = ("_beat", "mean")
    if extra:
        agg.update(extra)
    tbl = oos.assign(dec=dec).groupby("dec").agg(**agg)
    rows = [{"decile": int(i) + 1, **{k: (round(float(v), 5) if isinstance(v, (float, np.floating)) else int(v))
                                      for k, v in r.items()}} for i, r in tbl.iterrows()]
    return rows, tbl


def evaluate(oos: pd.DataFrame, pcol: str = "p", kind: str = "barrier") -> dict:
    R = oos["R"].to_numpy()
    ics = _daily_ic(oos, pcol, "R", spearman=(kind == "rank"))
    ic_mean = float(ics.mean()) if len(ics) else float("nan")
    ic_t = float(ic_mean / (ics.std(ddof=1) / math.sqrt(len(ics)))) if len(ics) > 5 and ics.std() > 0 else float("nan")
    extra = {"avg_A": ("A", "mean")} if "A" in oos else None
    deciles, tbl = _deciles(oos, pcol, extra)
    top = tbl.loc[9] if 9 in tbl.index else None
    bot = tbl.loc[0] if 0 in tbl.index else None
    m = {"kind": kind, "n": int(len(oos)), "dates": int(oos["date"].nunique()),
         "ic_mean": round(ic_mean, 4), "ic_t": round(ic_t, 2) if ic_t == ic_t else None,
         "ic_pos_share": round(float((ics > 0).mean()), 3) if len(ics) else None,
         "avg_R_all": round(float(np.nanmean(R)), 5),
         "top_decile_R": round(float(top.avg_R), 5) if top is not None else None,
         "bottom_decile_R": round(float(bot.avg_R), 5) if bot is not None else None,
         "top_decile_hit": round(float(top.hit), 4) if top is not None else None, "deciles": deciles}
    if kind == "barrier":
        y, p = oos["y"].to_numpy(), oos[pcol].to_numpy()
        base = float(y.mean())
        b = float(np.mean((p - y) ** 2))
        b0 = float(np.mean((base - y) ** 2))
        m.update(base_rate=round(base, 4), auc=round(_auc(y, p), 4), brier=round(b, 5), brier_base=round(b0, 5),
                 skill=round(1 - b / b0, 4) if b0 else None)
    else:
        m["long_short"] = round(float(top.avg_R - bot.avg_R), 5) if top is not None and bot is not None else None
        if "A" in oos:
            m["top_decile_abs"] = round(float(top.avg_A), 5) if top is not None else None
            m["universe_abs"] = round(float(oos["A"].mean()), 5)
        # πόσο συχνά το top 10% ξεπέρασε τον μέσο όρο της αγοράς
        rk = oos.groupby("date")[pcol].rank(pct=True)
        topd = oos[rk >= 0.9].groupby("date")["R"].mean()
        m["top_beats_share"] = round(float((topd > 0).mean()), 3) if len(topd) else None
    return m


def validation_gate(m: dict, cal: dict, folds: list[dict] | None = None) -> tuple[bool, list[str]]:
    cost = 2 * settings.slippage_bps / 10000
    if m.get("kind") == "rank":
        pos_folds = [f for f in (folds or []) if (f.get("top_decile_R") or 0) > 0]
        share = len(pos_folds) / max(1, len(folds or []))
        last_ok = bool(folds) and (folds[-1].get("ic_mean") or 0) > 0
        checks = [
            ((m.get("ic_mean") or 0) >= 0.015 and (m.get("ic_t") or 0) >= 2.5,
             f"IC {m.get('ic_mean')} με t={m.get('ic_t')} (χρειάζεται ≥ 0.015 και t ≥ 2.5)"),
            ((m.get("top_decile_R") or -9) >= cost,
             f"Top 10% υπεραπόδοση {100 * (m.get('top_decile_R') or 0):.2f}% (χρειάζεται ≥ {100 * cost:.2f}% για να καλύψει κόστη)"),
            (share >= 0.6, f"Θετικό top 10% σε {len(pos_folds)}/{len(folds or [])} περιόδους (χρειάζεται ≥ 60%)"),
            (last_ok, "Θετικό IC και στην πιο πρόσφατη περίοδο" if last_ok else "Αρνητικό IC στην πιο πρόσφατη περίοδο"),
        ]
    else:
        checks = [
            (m.get("auc", 0) >= 0.53, f"AUC {m.get('auc')} (χρειάζεται ≥ 0.53)"),
            ((cal.get("skill_holdout") or -1) > 0, f"Brier skill στην τελευταία περίοδο {cal.get('skill_holdout')} (χρειάζεται > 0)"),
            ((m.get("ic_t") or 0) >= 2.0 and (m.get("ic_mean") or 0) > 0, f"IC {m.get('ic_mean')} με t={m.get('ic_t')} (χρειάζεται t ≥ 2)"),
            ((m.get("top_decile_R") or -9) > (m.get("avg_R_all") or 0) + 0.05 and (m.get("top_decile_R") or -9) > 0,
             f"Top 10% μέσο R {m.get('top_decile_R')} vs όλων {m.get('avg_R_all')} (χρειάζεται θετικό και +0.05R)"),
        ]
    ok = True
    reasons = []
    for passed, txt in checks:
        reasons.append(("✓ " if passed else "✗ ") + txt)
        ok &= bool(passed)
    return ok, reasons


def walk_forward(P: pd.DataFrame, hz: str, cb=None) -> tuple[pd.DataFrame, list[dict]]:
    cfg = F.HORIZONS[hz]
    kind = cfg["kind"]
    data = P[P[f"y_{hz}"].notna() & P[f"R_{hz}"].notna()]
    dates = np.sort(data["date"].unique())
    if len(dates) < 250:
        raise RuntimeError("Ανεπαρκές ιστορικό για walk-forward")
    first, last = pd.Timestamp(dates[0]), pd.Timestamp(dates[-1])
    span_years = (last - first).days / 365.25
    min_train = MIN_TRAIN_YEARS if span_years >= MIN_TRAIN_YEARS + 2 else 2.0
    test_months = 12 if span_years > 6 else 6
    embargo = pd.Timedelta(days=int(cfg["H"] * 1.5) + 4)
    test_start = first + pd.DateOffset(months=int(min_train * 12))
    n_folds = max(1, int(((last - test_start).days / 30.4) // test_months) + 1)
    folds, oos = [], []
    k = 0
    while test_start < last:
        test_end = test_start + pd.DateOffset(months=test_months)
        tr = data[data["date"] < test_start - embargo]
        te = data[(data["date"] >= test_start) & (data["date"] < test_end)]
        if len(tr) > 5000 and len(te) > 500:
            if cb:
                cb(k, n_folds, f"{cfg['label']}: περίοδος {k + 1}/{n_folds} — εκπαίδευση έως {test_start.date()}")
            ens = fit_ensemble(kind, tr, f"y_{hz}", cfg["H"], n_models=1, seed0=k)
            p = ens.predict(te[F.FEATURES].to_numpy(np.float32))
            o = pd.DataFrame({"date": te["date"].to_numpy(), "ticker": te["ticker"].to_numpy(), "p": p,
                              "y": te[f"y_{hz}"].to_numpy(), "R": te[f"R_{hz}"].to_numpy(), "fold": k})
            if kind == "rank":
                o["A"] = te[f"A_{hz}"].to_numpy()
            oos.append(o)
            fm = evaluate(o, kind=kind)
            folds.append({"fold": k + 1, "train_end": str((test_start - embargo).date()),
                          "test": [str(test_start.date()), str(min(test_end, last).date())],
                          "n_train": int(len(tr)), "n_test": int(len(te)), "auc": fm.get("auc"), "ic_mean": fm["ic_mean"],
                          "top_decile_R": fm["top_decile_R"], "avg_R_all": fm["avg_R_all"],
                          "base_rate": fm.get("base_rate"), "long_short": fm.get("long_short")})
            del ens
            gc.collect()
            k += 1
        test_start = test_end
    if not oos:
        raise RuntimeError("Δεν δημιουργήθηκαν περίοδοι ελέγχου (λίγα δεδομένα)")
    return pd.concat(oos, ignore_index=True), folds


def calibrate(oos: pd.DataFrame, kind: str = "barrier") -> tuple[object, dict, pd.DataFrame]:
    """barrier: isotonic βαθμονόμηση (έλεγχος στην τελευταία περίοδο). rank: πίνακας κατάταξη -> υπεραπόδοση."""
    from sklearn.isotonic import IsotonicRegression
    last_fold = oos["fold"].max()
    if kind == "rank":
        rk = oos.groupby("date")["p"].rank(pct=True)
        oos = oos.assign(pc=rk)
        edges = [0, .1, .2, .3, .4, .5, .6, .7, .8, .9, .95, 1.0001]
        bins = pd.cut(oos["pc"], edges, include_lowest=True, right=False)
        tbl = oos.groupby(bins, observed=True).agg(n=("R", "size"), avg_R=("R", "mean"),
                                                   hit=("R", lambda s: float((s > 0).mean())), avg_p=("pc", "mean"))
        info = {"table": [{"lo": round(float(iv.left), 4), "hi": round(float(min(iv.right, 1.0)), 4), "n": int(r.n),
                           "avg_R": round(float(r.avg_R), 5), "hit": round(float(r.hit), 4), "avg_p": round(float(r.avg_p), 4)}
                          for iv, r in tbl.iterrows()]}
        hold = oos[oos["fold"] == last_fold]
        ics = _daily_ic(hold, "p", "R", spearman=True)
        info["ic_holdout"] = round(float(ics.mean()), 4) if len(ics) else None
        return None, info, oos
    fit, hold = oos[oos["fold"] < last_fold], oos[oos["fold"] == last_fold]
    info = {}
    if len(fit) > 5000 and len(hold) > 1000:
        iso = IsotonicRegression(out_of_bounds="clip", y_min=0.001, y_max=0.999).fit(fit["p"], fit["y"])
        pc = iso.predict(hold["p"])
        base = fit["y"].mean()
        b = float(np.mean((pc - hold["y"]) ** 2))
        b0 = float(np.mean((base - hold["y"]) ** 2))
        info = {"brier_holdout": round(b, 5), "brier_base_holdout": round(b0, 5),
                "skill_holdout": round(1 - b / b0, 4) if b0 else None, "n_holdout": int(len(hold))}
    iso = IsotonicRegression(out_of_bounds="clip", y_min=0.001, y_max=0.999).fit(oos["p"], oos["y"])
    oos = oos.assign(pc=iso.predict(oos["p"]))
    q = np.unique(np.quantile(oos["pc"], np.linspace(0, 1, 11)))
    bins = pd.cut(oos["pc"], q, include_lowest=True, duplicates="drop")
    tbl = oos.groupby(bins, observed=True).agg(n=("y", "size"), hit=("y", "mean"), avg_R=("R", "mean"), avg_p=("pc", "mean"))
    info["table"] = [{"lo": round(float(iv.left), 4), "hi": round(float(iv.right), 4), "n": int(r.n),
                      "hit": round(float(r.hit), 4), "avg_R": round(float(r.avg_R), 4), "avg_p": round(float(r.avg_p), 4)}
                     for iv, r in tbl.iterrows()]
    return iso, info, oos


def _importance(ens: Ens, X: pd.DataFrame | None, y: np.ndarray | None) -> list[dict]:
    g = ens.gain_importance()
    if g is None and X is not None and len(X) > 1000:
        from sklearn.inspection import permutation_importance
        Xs = X.sample(n=min(30000, len(X)), random_state=1)
        ys = y[X.index.get_indexer(Xs.index)]

        class _W:  # wrapper για permutation_importance
            def fit(self, *a):
                return self

            def predict(self, Z):
                return ens.predict(Z)

        r = permutation_importance(_W(), Xs[F.FEATURES].to_numpy(np.float32), ys,
                                   scoring=lambda est, Z, yy: -np.mean((est.predict(Z) - yy) ** 2),
                                   n_repeats=1, random_state=0)
        g = np.maximum(r.importances_mean, 0)
        g = g / max(g.sum(), 1e-12)
    if g is None:
        return []
    imp = sorted(zip(F.FEATURES, g), key=lambda x: -x[1])
    return [{"feature": f, "label": F.FEATURE_LABELS.get(f, f), "importance": round(float(v), 5)} for f, v in imp]


# ================================================================== εκπαίδευση
def train_all(tickers: list[str] | None = None) -> dict:
    import joblib
    if _progress["running"]:
        return {"status": "already_running"}
    _progress.update(running=True, step="Ξεκίνημα", pct=0, started_at=db.now_iso(), error=None)
    t0 = time.time()
    try:
        from ..data.listings import universe_tickers
        tickers = tickers or universe_tickers(settings.ml_max_tickers)
        _step(f"Φόρτωση τιμών & υπολογισμός {len(F.FEATURES)} χαρακτηριστικών για {len(tickers)} μετοχές", 2)
        stats: dict = {}
        P = build_panel(tickers, with_labels=True, stats=stats)
        _step(f"Panel: {len(P):,} γραμμές × {len(F.FEATURES)} χαρακτηριστικά "
              f"({stats.get('values_per_sec', 0) / 1e6:.1f} εκατ. στοιχεία/δευτ.)", 12)
        MODEL_DIR.mkdir(parents=True, exist_ok=True)
        results = {}
        hz_list = list(F.HORIZONS)
        span = 86 / len(hz_list)
        for hi, hz in enumerate(hz_list):
            cfg = F.HORIZONS[hz]
            kind = cfg["kind"]
            base_pct = 12 + hi * span

            def cb(k, n, msg, _b=base_pct, _s=span):
                _step(msg, _b + 0.75 * _s * k / max(n, 1))

            ht0 = time.time()
            oos, folds = walk_forward(P, hz, cb)
            _step(f"{cfg['label']}: βαθμονόμηση & έλεγχος", base_pct + 0.78 * span)
            calib, cal, oos_c = calibrate(oos, kind)
            metrics = evaluate(oos, kind=kind)
            metrics_cal = evaluate(oos_c.assign(p=oos_c["pc"]), kind=kind) if kind == "barrier" else metrics
            ok, reasons = validation_gate(metrics, cal, folds)
            _step(f"{cfg['label']}: τελικό ensemble σε όλο το ιστορικό", base_pct + 0.82 * span)
            data = P[P[f"y_{hz}"].notna() & P[f"R_{hz}"].notna()]
            ens = fit_ensemble(kind, data, f"y_{hz}", cfg["H"], n_models=2, seed0=100)
            imp = _importance(ens, data[F.FEATURES] if len(data) else None, data[f"y_{hz}"].to_numpy() if len(data) else None)
            path = MODEL_DIR / f"model_{hz}.joblib"
            joblib.dump({"model": ens, "calibrator": calib, "features": F.FEATURES, "horizon": hz, "kind": kind,
                         "cal_table": cal.get("table", []), "trained_at": db.now_iso(),
                         "data_end": str(P["date"].max().date()), "engine": engine_name()}, path)
            m_all = {"oos": metrics, "oos_calibrated": metrics_cal, "calibration": cal, "folds": folds,
                     "gate": reasons, "horizon_cfg": cfg, "kind": kind, "engine": engine_name(),
                     "train_seconds": round(time.time() - ht0), "n_tickers": int(P["ticker"].nunique()),
                     "panel_rows": int(len(P)), "n_features": len(F.FEATURES), "throughput": stats}
            db.execute("INSERT INTO ml_models(horizon,created_at,path,validated,metrics_json,calib_json,features_json,"
                       "importance_json,n_train,data_end) VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(horizon) DO UPDATE SET "
                       "created_at=excluded.created_at, path=excluded.path, validated=excluded.validated, "
                       "metrics_json=excluded.metrics_json, calib_json=excluded.calib_json, features_json=excluded.features_json, "
                       "importance_json=excluded.importance_json, n_train=excluded.n_train, data_end=excluded.data_end",
                       (hz, db.now_iso(), str(path), int(ok), json.dumps(m_all, default=str), json.dumps(cal, default=str),
                        json.dumps(F.FEATURES), json.dumps(imp), int(len(data)), str(P["date"].max().date())))
            results[hz] = {"validated": ok, "gate": reasons, "auc": metrics.get("auc"), "ic_t": metrics.get("ic_t"),
                           "kind": kind}
            _cache.pop(hz, None)
            del oos, oos_c, data, ens
            gc.collect()
        # παλιοί ορίζοντες που δεν υπάρχουν πια
        db.execute(f"DELETE FROM ml_models WHERE horizon NOT IN ({','.join('?' * len(hz_list))})", hz_list)
        del P
        gc.collect()
        _step("Πρόβλεψη για σήμερα σε όλη την αγορά", 99)
        try:
            predict_today(tickers)
        except Exception as e:  # noqa: BLE001
            log.warning("predict after training failed: %s", e)
        db.kv_set("ml_throughput", stats)
        _step(f"Ολοκληρώθηκε σε {round((time.time() - t0) / 60, 1)} λεπτά", 100)
        return {"status": "ok", "results": results, "throughput": stats}
    except Exception as e:  # noqa: BLE001
        log.exception("ML training failed")
        _progress["error"] = repr(e)[:400]
        _step(f"Σφάλμα: {e}")
        return {"status": "error", "error": str(e)}
    finally:
        _progress["running"] = False


# ================================================================== πρόβλεψη
def load(hz: str) -> dict | None:
    import joblib
    row = db.q1("SELECT * FROM ml_models WHERE horizon=?", (hz,))
    if not row:
        return None
    c = _cache.get(hz)
    if c and c["created_at"] == row["created_at"]:
        return c
    try:
        obj = joblib.load(row["path"])
    except Exception as e:  # noqa: BLE001
        log.warning("cannot load model %s: %s", hz, e)
        return None
    if obj.get("features") != F.FEATURES:
        log.warning("model %s trained with different features — needs retraining", hz)
        return None
    obj.setdefault("kind", F.HORIZONS.get(hz, {}).get("kind", "barrier"))
    obj.update(created_at=row["created_at"], validated=bool(row["validated"]),
               importance=json.loads(row["importance_json"] or "[]"))
    _cache[hz] = obj
    return obj


def status() -> dict:
    out = {}
    for r in db.q("SELECT horizon, created_at, validated, metrics_json, importance_json, n_train, data_end FROM ml_models"):
        if r["horizon"] not in F.HORIZONS:
            continue
        m = json.loads(r["metrics_json"])
        out[r["horizon"]] = {"created_at": r["created_at"], "validated": bool(r["validated"]), "n_train": r["n_train"],
                             "data_end": r["data_end"], "metrics": m, "importance": json.loads(r["importance_json"] or "[]")[:20],
                             "label": F.HORIZONS[r["horizon"]]["label"], "kind": F.HORIZONS[r["horizon"]]["kind"]}
    last = db.q1("SELECT MAX(date) d FROM ml_predictions")
    return {"models": out, "progress": progress(), "last_prediction_date": last["d"] if last else None,
            "horizons": F.HORIZONS, "engine": engine_name(), "n_features": len(F.FEATURES),
            "throughput": db.kv_get("ml_throughput")}


def expected_R(p: float, table: list[dict]) -> float | None:
    for b in table:
        if b["lo"] <= p <= b["hi"]:
            return b["avg_R"]
    return table[-1]["avg_R"] if table and p > table[-1]["hi"] else None


def predict_today(tickers: list[str] | None = None) -> dict:
    models = {hz: load(hz) for hz in F.HORIZONS}
    models = {k: v for k, v in models.items() if v}
    if not models:
        return {"status": "no_model"}
    from ..data.listings import universe_tickers
    tickers = tickers or universe_tickers()
    if not tickers:
        return {"status": "no_tickers"}
    start = (pd.Timestamp.today() - pd.Timedelta(days=430)).strftime("%Y-%m-%d")
    P = build_panel(tickers, start=start, with_labels=False, last_only=True)
    X = P[F.FEATURES].to_numpy(np.float32)
    date = str(P["date"].max().date())
    rows = []
    for hz, m in models.items():
        raw = m["model"].predict(X)
        if m["kind"] == "rank":
            rk = pd.Series(raw).rank(pct=True).to_numpy()
            pc = rk
        else:
            pc = m["calibrator"].predict(raw) if m.get("calibrator") is not None else raw
            rk = pd.Series(pc).rank(pct=True).to_numpy()
        for t, d, a, b, r in zip(P["ticker"], P["date"], pc, raw, rk):
            rows.append((t, str(d.date()), hz, float(a), float(b), float(r), expected_R(float(a), m["cal_table"]), db.now_iso()))
    db.executemany("INSERT INTO ml_predictions(ticker,date,horizon,p,p_raw,rank_pct,exp_r,created_at) VALUES(?,?,?,?,?,?,?,?) "
                   "ON CONFLICT(ticker,date,horizon) DO UPDATE SET p=excluded.p, p_raw=excluded.p_raw, "
                   "rank_pct=excluded.rank_pct, exp_r=excluded.exp_r, created_at=excluded.created_at", rows)
    db.execute(f"DELETE FROM ml_predictions WHERE horizon NOT IN ({','.join('?' * len(F.HORIZONS))})", list(F.HORIZONS))
    _cache["latest_panel"] = P.set_index("ticker")
    try:
        P.to_pickle(DATA_DIR / "ml_latest.pkl")
    except Exception:  # noqa: BLE001
        pass
    db.kv_set("ml_predicted_at", db.now_iso())
    return {"status": "ok", "date": date, "n": int(len(P))}


def _latest_panel() -> pd.DataFrame | None:
    P = _cache.get("latest_panel")
    if P is None:
        f = DATA_DIR / "ml_latest.pkl"
        if f.exists():
            try:
                P = pd.read_pickle(f).set_index("ticker")
                _cache["latest_panel"] = P
            except Exception:  # noqa: BLE001
                return None
    return P


def prediction_for(ticker: str) -> dict:
    """Πρόβλεψη + επεξήγηση (SHAP: τι έσπρωξε την πρόβλεψη πάνω/κάτω) για μία μετοχή."""
    out = {}
    rows = db.q("SELECT * FROM ml_predictions WHERE ticker=? AND date=(SELECT MAX(date) FROM ml_predictions WHERE ticker=?)",
                (ticker, ticker))
    P = _latest_panel()
    for r in rows:
        hz = r["horizon"]
        if hz not in F.HORIZONS:
            continue
        m = load(hz)
        if not m:
            continue
        cfg = F.HORIZONS[hz]
        item = {"horizon": hz, "kind": cfg["kind"], "label": cfg["label"], "p": r["p"], "rank_pct": r["rank_pct"],
                "exp_r": r["exp_r"], "date": r["date"], "validated": m["validated"], "days": cfg["H"], "drivers": []}
        if cfg["kind"] == "barrier":
            item.update(breakeven=round(cfg["dn"] / (cfg["up"] + cfg["dn"]), 3), target_atr=cfg["up"], stop_atr=cfg["dn"])
        if P is not None and ticker in P.index:
            x = P.loc[[ticker], F.FEATURES]
            X = x.to_numpy(np.float32)
            con = m["model"].contrib(X)
            if con is not None:
                c = con[0]
                order = np.argsort(-np.abs(c))[:10]
                tot = float(np.abs(c).sum()) or 1.0
                for j in order:
                    val = x.iloc[0, j]
                    item["drivers"].append({"feature": F.FEATURES[j], "label": F.FEATURE_LABELS.get(F.FEATURES[j], F.FEATURES[j]),
                                            "value": None if pd.isna(val) else round(float(val), 4),
                                            "effect": round(float(c[j]) / tot, 4)})
            else:
                med = P[F.FEATURES].median()
                base = float(m["model"].predict(X)[0])
                top = [i["feature"] for i in (m.get("importance") or [])[:12]] or F.FEATURES[:12]
                for feat in top:
                    x2 = x.copy()
                    x2[feat] = med[feat]
                    eff = base - float(m["model"].predict(x2.to_numpy(np.float32))[0])
                    val = x[feat].iloc[0]
                    item["drivers"].append({"feature": feat, "label": F.FEATURE_LABELS.get(feat, feat),
                                            "value": None if pd.isna(val) else round(float(val), 4), "effect": round(eff, 4)})
                item["drivers"].sort(key=lambda d: -abs(d["effect"]))
        out[hz] = item
    return out


def ml_component(ticker: str) -> tuple[float | None, dict]:
    rows = db.q("SELECT horizon, p, rank_pct, exp_r FROM ml_predictions WHERE ticker=? AND "
                "date=(SELECT MAX(date) FROM ml_predictions)", (ticker,))
    validated = {r["horizon"]: bool(r["validated"]) for r in db.q("SELECT horizon, validated FROM ml_models")}
    info = {r["horizon"]: {**r, "validated": validated.get(r["horizon"], False)} for r in rows}
    return combined_rank(info), info


def combined_rank(info: dict) -> float | None:
    """Συνιστώσα 0-100 για το score: μόνο επικυρωμένα μοντέλα· προτεραιότητα στα μοντέλα κατάταξης."""
    rank_v = [r["rank_pct"] for h, r in info.items() if r.get("validated") and F.HORIZONS.get(h, {}).get("kind") == "rank"
              and r.get("rank_pct") is not None]
    if rank_v:
        return round(float(np.mean(rank_v)) * 100, 1)
    bar_v = [r["rank_pct"] for h, r in info.items() if r.get("validated") and r.get("rank_pct") is not None]
    return round(float(np.mean(bar_v)) * 100, 1) if bar_v else None


def model_age_days() -> float | None:
    r = db.q1("SELECT MIN(created_at) c FROM ml_models")
    if not r or not r["c"]:
        return None
    return (datetime.now(timezone.utc) - datetime.fromisoformat(r["c"])).total_seconds() / 86400
