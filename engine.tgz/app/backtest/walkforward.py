"""Walk-forward validation, train/validation/test split, βαθμονόμηση πιθανοτήτων και
αξιολόγηση του ιστορικού προβλέψεων. Καμία αλλαγή βαρών δεν εφαρμόζεται αυτόματα: το
σύστημα προτείνει, τεκμηριώνει και ο χρήστης αποφασίζει."""
from __future__ import annotations

import itertools
import json
import logging
import math

import numpy as np
import pandas as pd

from .. import db
from ..config import normalize_weights, settings
from . import engine as bt

log = logging.getLogger("usalpha.wf")

GRID_SCORE = [50, 55, 60, 65]
GRID_RR = [1.5, 1.8, 2.2]
WEIGHT_SETS = {
    "τρέχοντα": None,  # συμπληρώνεται runtime
    "τεχνικά-βαρύ": {"technical": 0.5, "momentum_volume": 0.3, "sector": 0.1, "market": 0.1},
    "momentum-βαρύ": {"technical": 0.25, "momentum_volume": 0.5, "sector": 0.15, "market": 0.1},
    "ισόρροπο": {"technical": 0.25, "momentum_volume": 0.25, "sector": 0.25, "market": 0.25},
    "φίλτρο αγοράς": {"technical": 0.3, "momentum_volume": 0.25, "sector": 0.15, "market": 0.3},
}
MIN_TRADES = 30

_progress = {"running": False, "step": "", "done": 0, "total": 0}


def progress() -> dict:
    return dict(_progress)


def objective(trades: list[dict]) -> float:
    """Expectancy (R) × √n: ανταμείβει σταθερό edge με επαρκές δείγμα, όχι τυχαία λίγα trades."""
    if len(trades) < MIN_TRADES:
        return -1e9
    r = np.array([t["r_multiple"] for t in trades])
    return float(r.mean() * math.sqrt(len(r)))


def grid_search(cands: list[dict], start: str | None, end: str | None, weight_sets: dict) -> dict:
    best = {"obj": -1e9}
    for (wname, w), ms, rr in itertools.product(weight_sets.items(), GRID_SCORE, GRID_RR):
        tr = bt.select(cands, ms, rr, w, start, end)
        o = objective(tr)
        if o > best["obj"]:
            best = {"obj": o, "weights_name": wname, "weights": w, "min_score": ms, "min_rr": rr, "n": len(tr)}
    return best


def run_full(tickers: list[str], years_train: int = 2, months_test: int = 6, name: str = "Walk-forward") -> dict:
    if _progress["running"]:
        return {"status": "already_running"}
    _progress.update(running=True, step="Φόρτωση δεδομένων", done=0, total=len(tickers))
    try:
        cur_w = {k: settings.weights.get(k, 0) for k in bt.BT_COMPONENTS}
        wsets = {**WEIGHT_SETS, "τρέχοντα": normalize_weights(cur_w)}
        p = bt.Params(min_score=0, min_rr=1.0)
        inputs = bt.load_inputs(tickers)
        _progress.update(step="Υπολογισμός υποψήφιων trades (χωρίς look-ahead)", total=len(inputs["data"]))

        def cb(n, tot, t):
            _progress.update(done=n, total=tot, step=f"Backtest {t}")

        cands = bt.run(tickers, p, inputs=inputs, progress_cb=cb, collect_all=True)
        if not cands:
            return {"status": "error", "error": "Δεν βρέθηκαν υποψήφια trades (λείπει ιστορικό;)"}
        dates = sorted(t["signal_date"] for t in cands)
        d0, d1 = pd.Timestamp(dates[0]), pd.Timestamp(dates[-1])

        # ---- Static split 60/20/20 (χρονολογικά)
        span = d1 - d0
        t_train_end = (d0 + span * 0.6).strftime("%Y-%m-%d")
        t_val_end = (d0 + span * 0.8).strftime("%Y-%m-%d")
        _progress["step"] = "Βελτιστοποίηση στο training set"
        best = grid_search(cands, None, t_train_end, wsets)
        train_tr = bt.select(cands, best["min_score"], best["min_rr"], best["weights"], None, t_train_end)
        val_tr = bt.select(cands, best["min_score"], best["min_rr"], best["weights"], t_train_end, t_val_end)
        test_tr = bt.select(cands, best["min_score"], best["min_rr"], best["weights"], t_val_end, None)
        default_test = bt.select(cands, 55, settings.min_rr, wsets["τρέχοντα"], t_val_end, None)
        static = {
            "periods": {"train": [str(d0.date()), t_train_end], "validation": [t_train_end, t_val_end],
                        "test": [t_val_end, str(d1.date())]},
            "chosen": {k: v for k, v in best.items() if k != "obj"},
            "train": bt.metrics(train_tr), "validation": bt.metrics(val_tr), "test": bt.metrics(test_tr),
            "test_current_settings": bt.metrics(default_test),
        }

        # ---- Rolling walk-forward
        _progress["step"] = "Walk-forward folds"
        folds, oos = [], []
        start = d0
        while True:
            tr_end = start + pd.DateOffset(years=years_train)
            te_end = tr_end + pd.DateOffset(months=months_test)
            if tr_end >= d1:
                break
            s0, s1, s2 = start.strftime("%Y-%m-%d"), tr_end.strftime("%Y-%m-%d"), min(te_end, d1 + pd.Timedelta(days=1)).strftime("%Y-%m-%d")
            b = grid_search(cands, s0, s1, wsets)
            if b["obj"] <= -1e9:
                folds.append({"train": [s0, s1], "test": [s1, s2], "skipped": "λίγα trades στο training"})
            else:
                te = bt.select(cands, b["min_score"], b["min_rr"], b["weights"], s1, s2)
                for t in te:
                    t["fold"] = len(folds)
                oos += te
                folds.append({"train": [s0, s1], "test": [s1, s2], "params": {k: v for k, v in b.items() if k not in ("obj", "weights")},
                              "test_metrics": bt.metrics(te)})
            start = start + pd.DateOffset(months=months_test)
        wf_metrics = bt.metrics(oos)

        # ---- Βαθμονόμηση από OOS trades
        _progress["step"] = "Βαθμονόμηση πιθανοτήτων"
        calib = calibrate(oos)
        bid = bt.save(name, p, {"walk_forward": wf_metrics, "static": static, "folds": folds, "calibration": calib,
                                "n_candidates": len(cands), "universe": len(inputs["data"]),
                                "limitations": LIMITATIONS}, oos, {"years_train": years_train, "months_test": months_test})
        suggestion = None
        if static["test"].get("n", 0) >= MIN_TRADES and static["validation"].get("n", 0) >= MIN_TRADES:
            if static["test"].get("expectancy_r", 0) > static["test_current_settings"].get("expectancy_r", 0) \
                    and static["validation"].get("expectancy_r", 0) > 0:
                suggestion = {"weights_name": best["weights_name"], "weights": best["weights"],
                              "min_score": best["min_score"], "min_rr": best["min_rr"],
                              "why": "Καλύτερο expectancy στο test set από τις τρέχουσες ρυθμίσεις, θετικό και στο validation."}
        db.kv_set("wf_suggestion", {"backtest_id": bid, "suggestion": suggestion})
        return {"status": "ok", "backtest_id": bid, "walk_forward": wf_metrics, "static": static,
                "folds": folds, "calibration": calib, "suggestion": suggestion}
    except Exception as e:  # noqa: BLE001
        log.exception("walk-forward failed")
        return {"status": "error", "error": str(e)}
    finally:
        _progress.update(running=False, step="Ολοκληρώθηκε")


LIMITATIONS = [
    "Τα ιστορικά θεμελιώδη και οι ειδήσεις δεν υπάρχουν point-in-time δωρεάν· το backtest ελέγχει "
    "τεχνικά, momentum, κλάδο και αγορά. Οι επενδυτικές (invest) ευκαιρίες δεν ελέγχονται ιστορικά.",
    "Survivorship bias: το σύμπαν είναι οι σημερινές μετοχές· εταιρείες που χρεοκόπησαν/αποσύρθηκαν λείπουν, "
    "άρα τα αποτελέσματα μπορεί να είναι υπεραισιόδοξα.",
    "Εκτέλεση σε ημερήσια bars: η σειρά stop/target μέσα στη μέρα είναι άγνωστη — θεωρείται πάντα πρώτα το stop.",
    "Slippage/κόστη είναι εκτιμήσεις· σε μετοχές χαμηλής ρευστότητας το πραγματικό κόστος είναι μεγαλύτερο.",
]


def calibrate(oos: list[dict]) -> dict:
    """Score bins -> ιστορικό ποσοστό κερδοφόρων trades (OOS). Brier σε χρονολογικό holdout."""
    out = {}
    if not oos:
        return out
    df = pd.DataFrame(oos)
    df["dscore"] = np.where(df["bias"] == "bullish", df["score"], 100 - df["score"])
    df["win"] = (df["r_multiple"] > 0).astype(int)
    edges = [0, 55, 60, 65, 70, 101]
    for hz, g in list(df.groupby("horizon")) + [("all", df)]:
        g = g.sort_values("signal_date")
        if len(g) < 60:
            out[hz] = {"n": int(len(g)), "status": "λίγα δεδομένα — δεν βαθμονομήθηκε"}
            continue
        cut = int(len(g) * 0.7)
        fit, hold = g.iloc[:cut], g.iloc[cut:]
        table = []
        for lo, hi in zip(edges[:-1], edges[1:]):
            b = fit[(fit["dscore"] >= lo) & (fit["dscore"] < hi)]
            # Laplace smoothing για μικρά δείγματα
            p_up = (b["win"].sum() + 1) / (len(b) + 2)
            table.append({"lo": lo, "hi": hi, "n": int(len(b)), "p_up": round(float(p_up), 3),
                          "avg_ret": round(float(b["r_multiple"].mean()), 3) if len(b) else None,
                          "h": round(float(b["days"].mean()), 1) if len(b) else None})
        base = fit["win"].mean()

        def pred(s):
            for b in table:
                if b["lo"] <= s < b["hi"]:
                    return b["p_up"]
            return base

        p_hold = hold["dscore"].map(pred)
        brier = float(((p_hold - hold["win"]) ** 2).mean())
        brier_base = float(((base - hold["win"]) ** 2).mean())
        out[hz] = {"n": int(len(g)), "table": table, "brier": round(brier, 4), "brier_baseline": round(brier_base, 4),
                   "skill": round(1 - brier / brier_base, 4) if brier_base else None, "base_rate": round(float(base), 3)}
        skill = out[hz]["skill"]
        out[hz]["n_holdout"] = int(len(hold))
        if hz in ("short", "swing") and (skill is None or skill < 0.02 or len(hold) < 100):
            # το score δεν απέδειξε προβλεπτική αξία σε επαρκές δείγμα: ΔΕΝ εμφανίζουμε «πιθανότητα»
            db.execute("DELETE FROM calibration WHERE horizon=?", (hz,))
            out[hz]["status"] = ("Μικρό δείγμα ελέγχου (<100)" if len(hold) < 100 else "Χωρίς ουσιαστική προβλεπτική αξία") \
                + " — δεν εμφανίζεται πιθανότητα"
        elif hz in ("short", "swing"):
            db.execute("INSERT INTO calibration(horizon,created_at,table_json,n_samples,brier) VALUES(?,?,?,?,?) "
                       "ON CONFLICT(horizon) DO UPDATE SET created_at=excluded.created_at, table_json=excluded.table_json,"
                       " n_samples=excluded.n_samples, brier=excluded.brier",
                       (hz, db.now_iso(), json.dumps(table), int(len(g)), brier))
    return out


# ------------------------------------------------------------------ prediction log evaluation
def resolve_predictions() -> dict:
    """Συγκρίνει τις παλιές προβλέψεις (score τη μέρα t) με την πραγματική απόδοση."""
    today = pd.Timestamp.today().strftime("%Y-%m-%d")
    pend = db.q("SELECT * FROM predictions WHERE resolved=0 AND target_date<=?", (today,))
    n = 0
    for p in pend:
        df = db.load_prices(p["ticker"], start=p["made_at"][:10])
        if len(df) <= p["horizon_days"]:
            continue
        p0 = float(df["close"].iloc[0])
        p1 = float(df["close"].iloc[p["horizon_days"]])
        ret = (p1 / p0 - 1) * 100
        bull = p["score"] >= 50
        hit = int((ret > 0) == bull)
        db.execute("UPDATE predictions SET resolved=1, realized_return=?, hit=? WHERE id=?", (ret, hit, p["id"]))
        n += 1
    return {"resolved": n}


def prediction_report() -> dict:
    rows = db.q("SELECT horizon_days, score, realized_return, hit FROM predictions WHERE resolved=1")
    if not rows:
        return {"n": 0}
    df = pd.DataFrame(rows)
    df["bucket"] = pd.cut(df["score"], [0, 40, 45, 55, 60, 65, 101], right=False,
                          labels=["<40", "40-45", "45-55", "55-60", "60-65", "65+"])
    out = {"n": int(len(df)), "by_horizon": {}}
    for h, g in df.groupby("horizon_days"):
        b = g.groupby("bucket", observed=True).agg(n=("hit", "size"), avg_ret=("realized_return", "mean"),
                                                   up_rate=("realized_return", lambda s: (s > 0).mean() * 100))
        corr = g[["score", "realized_return"]].corr(method="spearman").iloc[0, 1] if len(g) > 10 else None
        out["by_horizon"][int(h)] = {
            "n": int(len(g)), "hit_rate": round(float(g["hit"].mean() * 100), 1),
            "rank_ic": None if corr is None or pd.isna(corr) else round(float(corr), 3),
            "buckets": [{"bucket": str(k), "n": int(v["n"]), "avg_ret": round(float(v["avg_ret"]), 2),
                         "up_rate": round(float(v["up_rate"]), 1)} for k, v in b.iterrows()],
        }
    return out
