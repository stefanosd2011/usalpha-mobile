"""Backtesting engine χωρίς look-ahead:
- Τα signals υπολογίζονται στο κλείσιμο της ημέρας t με δεδομένα έως t.
- Η είσοδος γίνεται στο άνοιγμα της t+1 (με slippage). Αν η τιμή έχει «φύγει», δεν μπαίνουμε.
- Αν σε μία ημέρα αγγίζονται και stop και target, θεωρούμε ότι χτυπήθηκε πρώτα το stop (συντηρητικά).
- Έξοδος σε 3 κομμάτια (TP1/TP2/TP3), trailing stop όπως στο live σύστημα.
Περιορισμός (δηλώνεται ρητά): ιστορικά point-in-time θεμελιώδη και ειδήσεις δεν υπάρχουν δωρεάν,
οπότε το backtest αξιολογεί τα τεχνικά/momentum/κλάδο/αγορά. Οι κατηγορίες 'invest' δεν ελέγχονται."""
from __future__ import annotations

import json
import logging
import math
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from .. import db
from ..analysis import indicators as ind
from ..analysis import technical
from ..config import settings
from ..data.universe import SECTOR_ETF
from ..engine import scoring, strategies

log = logging.getLogger("usalpha.backtest")

BT_COMPONENTS = ("technical", "momentum_volume", "sector", "market")


@dataclass
class Params:
    horizons: tuple = ("short", "swing")
    min_score: float = 55.0
    min_rr: float = 1.8
    slippage_bps: float = 10.0
    commission_bps: float = 0.0
    risk_pct: float = 1.0
    max_chase_atr: float = 0.25
    allow_short: bool = True
    weights: dict = field(default_factory=lambda: dict(settings.weights))

    def to_dict(self):
        return {k: (list(v) if isinstance(v, tuple) else v) for k, v in self.__dict__.items()}


# ------------------------------------------------------------------ context series (χωρίς look-ahead)
def market_score_series(spy: pd.DataFrame, vix: pd.DataFrame) -> pd.Series:
    x = ind.add_all(spy)
    pts = np.where(x["close"] > x["sma200"], 2, -2) + np.where(x["close"] > x["sma50"], 1, -1)
    s = pd.Series(pts, index=x.index, dtype=float)
    if not vix.empty:
        v = vix["close"].reindex(x.index).ffill()
        s += np.select([v < 16, v > 30, v > 22], [1, -2.5, -1], 0)
    s = (50 + s * 8).clip(0, 100)
    s[x["sma200"].isna()] = np.nan
    return s


def sector_score_series(etf: pd.DataFrame, spy: pd.DataFrame) -> pd.Series:
    j = etf[["close"]].join(spy[["close"]].rename(columns={"close": "b"}), how="inner")
    r21 = j["close"].pct_change(21) - j["b"].pct_change(21)
    r63 = j["close"].pct_change(63) - j["b"].pct_change(63)
    rel = (r21 * 0.6 + r63 * 0.4) * 100
    trend = np.where(j["close"] > j["close"].rolling(50).mean(), 1, -1)
    return (50 + np.tanh(rel / 6) * 30 + trend * 8).clip(0, 100)


# ------------------------------------------------------------------ trade simulation
def simulate_trade(x: pd.DataFrame, i: int, setup, lv: dict, p: Params) -> dict | None:
    """Είσοδος στο open της i+1. Επιστρέφει trade dict ή None αν δεν γέμισε."""
    if i + 1 >= len(x):
        return None
    long = setup.bias == "bullish"
    sgn = 1 if long else -1
    a = float(x["atr"].iloc[i])
    nxt = x.iloc[i + 1]
    o = float(nxt["open"])
    # δεν κυνηγάμε: αν το άνοιγμα είναι πολύ μακριά από τη ζώνη, χάνεται το trade
    if long and o > lv["entry_high"] + p.max_chase_atr * a:
        return None
    if not long and o < lv["entry_low"] - p.max_chase_atr * a:
        return None
    slip = p.slippage_bps / 10000
    entry = o * (1 + sgn * slip)
    stop = lv["stop"]
    if (long and entry <= stop) or (not long and entry >= stop):
        return None
    R = abs(entry - stop)
    targets = [lv["tp1"], lv["tp2"], lv["tp3"]]
    remaining, realized, tp_hit = 1.0, 0.0, 0
    exit_reason, exit_idx = "time", None
    max_days = strategies.HORIZONS[setup.horizon]["max_days"]
    for k in range(i + 1, min(len(x), i + 1 + max_days)):
        bar = x.iloc[k]
        lo, hi, op = float(bar["low"]), float(bar["high"]), float(bar["open"])
        # stop πρώτα (συντηρητικά)
        stop_hit = lo <= stop if long else hi >= stop
        if stop_hit:
            fill = (min(op, stop) if long else max(op, stop)) if k > i + 1 else stop
            fill *= (1 - sgn * slip)
            realized += remaining * sgn * (fill - entry)
            remaining = 0
            exit_reason, exit_idx = ("stop" if tp_hit == 0 else f"stop μετά TP{tp_hit}"), k
            break
        while tp_hit < 3:
            t = targets[tp_hit]
            if (long and hi >= t) or (not long and lo <= t):
                part = 1 / 3 if tp_hit < 2 else remaining
                fill = t * (1 - sgn * slip)
                realized += part * sgn * (fill - entry)
                remaining -= part
                tp_hit += 1
                stop = entry if tp_hit == 1 else targets[0]
            else:
                break
        if remaining <= 1e-9:
            exit_reason, exit_idx = "tp3", k
            break
    if remaining > 1e-9:
        exit_idx = exit_idx or min(len(x) - 1, i + max_days)
        fill = float(x["close"].iloc[exit_idx]) * (1 - sgn * slip)
        realized += remaining * sgn * (fill - entry)
    realized -= 2 * p.commission_bps / 10000 * entry
    r_mult = realized / R if R else 0
    return {
        "entry_date": str(x.index[i + 1].date()), "exit_date": str(x.index[exit_idx].date()),
        "horizon": setup.horizon, "bias": setup.bias, "setup": setup.name, "entry": round(entry, 4),
        "stop": round(lv["stop"], 4), "tp1": lv["tp1"], "tp2": lv["tp2"], "tp3": lv["tp3"], "planned_rr": lv["rr"],
        "r_multiple": round(r_mult, 3), "return_pct": round(realized / entry * 100, 3),
        "exit_reason": exit_reason, "tp_hit": tp_hit, "days": int(exit_idx - i),
    }


def run_ticker(ticker: str, df: pd.DataFrame, bench: pd.DataFrame, mkt_s: pd.Series, sec_s: pd.Series | None,
               p: Params, start: str | None = None, end: str | None = None, collect_all: bool = False) -> list[dict]:
    """collect_all=True: καταγράφει ΟΛΑ τα υποψήφια trades (χωρίς όρια score/RR και χωρίς αποκλεισμό
    επικαλύψεων). Τα όρια εφαρμόζονται μετά με select() — ακριβώς ισοδύναμο, αλλά πολύ ταχύτερο
    για grid search και walk-forward."""
    if len(df) < 260:
        return []
    x = ind.add_all(df)
    trades, busy_until = [], {}
    idx = x.index
    lo_i = max(210, idx.searchsorted(pd.Timestamp(start)) if start else 210)
    hi_i = idx.searchsorted(pd.Timestamp(end)) if end else len(x) - 1
    for i in range(lo_i, min(hi_i, len(x) - 1)):
        setups = strategies.detect(x, i)
        if not setups:
            continue
        setups = [s for s in setups if s.horizon in p.horizons and (p.allow_short or s.bias == "bullish")]
        if not collect_all:
            setups = [s for s in setups if busy_until.get((s.horizon, s.bias), -1) < i]
        if not setups:
            continue
        sl = x.iloc[: i + 1]
        ta = technical.analyze(sl, bench, with_levels=True, precomputed=True)
        if not ta.get("ok"):
            continue
        d = idx[i]
        comps = {"technical": ta["technical_score"], "momentum_volume": ta["momentum_score"],
                 "market": _at(mkt_s, d), "sector": _at(sec_s, d) if sec_s is not None else None}
        w = {k: p.weights.get(k, 0) for k in BT_COMPONENTS}
        score, _ = scoring.compose(comps, w)
        for s in setups:
            sc = score if s.bias == "bullish" else 100 - score
            if not collect_all and sc < p.min_score:
                continue
            lv = strategies.levels(sl, s, ta.get("levels"))
            if not lv or (not collect_all and lv["rr"] < p.min_rr):
                continue
            tr = simulate_trade(x, i, s, lv, p)
            if not tr:
                continue
            tr.update({"ticker": ticker, "signal_date": str(d.date()), "score": score,
                       "comps": {k: (None if v is None else round(v, 2)) for k, v in comps.items()},
                       "signal_idx": i, "end_idx": i + tr["days"]})
            trades.append(tr)
            if not collect_all:
                busy_until[(s.horizon, s.bias)] = i + tr["days"]
    return trades


def rescore(tr: dict, weights: dict) -> float:
    w = {k: weights.get(k, 0) for k in BT_COMPONENTS}
    return scoring.compose(tr["comps"], w)[0]


def select(cands: list[dict], min_score: float, min_rr: float, weights: dict | None = None,
           start: str | None = None, end: str | None = None) -> list[dict]:
    """Εφαρμόζει όρια + αποκλεισμό επικαλυπτόμενων θέσεων (ίδιο ticker/ορίζοντας/κατεύθυνση),
    με χρονολογική σειρά — ακριβώς όπως θα συνέβαινε live."""
    out, busy = [], {}
    for tr in sorted(cands, key=lambda t: (t["ticker"], t["signal_idx"])):
        if start and tr["signal_date"] < start:
            continue
        if end and tr["signal_date"] >= end:
            continue
        sc = rescore(tr, weights) if weights else tr["score"]
        dsc = sc if tr["bias"] == "bullish" else 100 - sc
        if dsc < min_score or tr["planned_rr"] < min_rr:
            continue
        key = (tr["ticker"], tr["horizon"], tr["bias"])
        if busy.get(key, -1) >= tr["signal_idx"]:
            continue
        busy[key] = tr["end_idx"]
        out.append({**tr, "score": sc})
    return out


def _at(s: pd.Series | None, d) -> float | None:
    if s is None or s.empty:
        return None
    v = s.asof(d) if d >= s.index[0] else np.nan
    return None if pd.isna(v) else float(v)


# ------------------------------------------------------------------ metrics
def metrics(trades: list[dict], risk_pct: float = 1.0) -> dict:
    if not trades:
        return {"n": 0}
    t = pd.DataFrame(trades)
    r = t["r_multiple"]
    wins, losses = r[r > 0], r[r <= 0]
    pf = wins.sum() / abs(losses.sum()) if len(losses) and losses.sum() != 0 else float("inf")
    # equity: κάθε trade ρισκάρει risk_pct% του τρέχοντος κεφαλαίου, ταξινόμηση κατά ημερομηνία εξόδου
    t = t.sort_values("exit_date")
    eq = (1 + t["r_multiple"] * risk_pct / 100).cumprod()
    dd = (eq / eq.cummax() - 1).min() * 100
    daily = pd.Series(t["r_multiple"].values * risk_pct / 100, index=pd.to_datetime(t["exit_date"])).groupby(level=0).sum()
    if len(daily) > 1:
        full = daily.reindex(pd.bdate_range(daily.index.min(), daily.index.max()), fill_value=0)
        sharpe = full.mean() / full.std() * math.sqrt(252) if full.std() > 0 else 0
        neg = full[full < 0]
        sortino = full.mean() / neg.std() * math.sqrt(252) if len(neg) > 1 and neg.std() > 0 else 0
        years = max(1 / 252, len(full) / 252)
        cagr = (eq.iloc[-1] ** (1 / years) - 1) * 100
    else:
        sharpe = sortino = cagr = 0
    out = {
        "n": int(len(t)), "win_rate": round(float((r > 0).mean() * 100), 1),
        "avg_return_pct": round(float(t["return_pct"].mean()), 3), "avg_r": round(float(r.mean()), 3),
        "expectancy_r": round(float(r.mean()), 3),
        "avg_win_r": round(float(wins.mean()), 3) if len(wins) else 0,
        "avg_loss_r": round(float(losses.mean()), 3) if len(losses) else 0,
        "profit_factor": round(float(pf), 2) if pf != float("inf") else None,
        "max_drawdown_pct": round(float(dd), 2), "sharpe": round(float(sharpe), 2), "sortino": round(float(sortino), 2),
        "cagr_pct": round(float(cagr), 2), "final_equity_x": round(float(eq.iloc[-1]), 3),
        "avg_planned_rr": round(float(t["planned_rr"].mean()), 2), "avg_days": round(float(t["days"].mean()), 1),
        "by_exit": t["exit_reason"].value_counts().to_dict(),
        "by_horizon": {h: {"n": int(len(g)), "win_rate": round(float((g["r_multiple"] > 0).mean() * 100), 1),
                           "avg_r": round(float(g["r_multiple"].mean()), 3)} for h, g in t.groupby("horizon")},
        "by_setup": {h: {"n": int(len(g)), "avg_r": round(float(g["r_multiple"].mean()), 3),
                         "win_rate": round(float((g["r_multiple"] > 0).mean() * 100), 1)} for h, g in t.groupby("setup")},
    }
    return out


def equity_curve(trades: list[dict], risk_pct: float = 1.0) -> list[dict]:
    if not trades:
        return []
    t = pd.DataFrame(trades).sort_values("exit_date")
    eq = (1 + t["r_multiple"] * risk_pct / 100).cumprod()
    s = pd.Series(eq.values, index=t["exit_date"].values).groupby(level=0).last()
    return [{"time": d, "value": round(float(v) * 100, 3)} for d, v in s.items()]


# ------------------------------------------------------------------ data prep
def load_inputs(tickers: list[str]) -> dict:
    spy = db.load_prices("SPY")
    vix = db.load_prices("^VIX")
    mkt_s = market_score_series(spy, vix) if len(spy) > 210 else pd.Series(dtype=float)
    sec_cache: dict[str, pd.Series] = {}
    data = {}
    for t in tickers:
        df = db.load_prices(t)
        if len(df) < 260:
            continue
        sec = db.q1("SELECT sector FROM company WHERE ticker=?", (t,))
        etf = SECTOR_ETF.get(sec["sector"]) if sec and sec["sector"] else None
        if etf and etf not in sec_cache:
            e = db.load_prices(etf)
            sec_cache[etf] = sector_score_series(e, spy) if len(e) > 70 else None
        data[t] = (df, sec_cache.get(etf) if etf else None)
    return {"spy": spy, "mkt": mkt_s, "data": data}


def run(tickers: list[str], p: Params, start: str | None = None, end: str | None = None,
        inputs: dict | None = None, progress_cb=None, collect_all: bool = False) -> list[dict]:
    inputs = inputs or load_inputs(tickers)
    trades = []
    items = list(inputs["data"].items())
    for n, (t, (df, sec_s)) in enumerate(items):
        try:
            trades += run_ticker(t, df, inputs["spy"], inputs["mkt"], sec_s, p, start, end, collect_all)
        except Exception as e:  # noqa: BLE001
            log.warning("backtest %s: %s", t, e)
        if progress_cb:
            progress_cb(n + 1, len(items), t)
    return trades


def save(name: str, p: Params, m: dict, trades: list[dict], extra: dict | None = None) -> int:
    return db.execute(
        "INSERT INTO backtests(created_at,name,params_json,metrics_json,equity_json,trades_json) VALUES(?,?,?,?,?,?)",
        (db.now_iso(), name, json.dumps({**p.to_dict(), **(extra or {})}, default=str), json.dumps(m, default=str),
         json.dumps(equity_curve(trades, p.risk_pct)), json.dumps(trades[-2000:], default=str)))
