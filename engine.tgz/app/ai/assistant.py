"""AI βοηθός: εξηγεί μετοχές και αγορά σε ΑΠΛΑ ελληνικά, χωρίς ορολογία.
- Χωρίς AI key: απλή εξήγηση από κανόνες (λειτουργεί πάντα).
- Με AI key (π.χ. Claude): ελεύθερη συζήτηση, πάντα πάνω στα πραγματικά δεδομένα του συστήματος.
Ο βοηθός ΔΕΝ επινοεί αριθμούς: παίρνει τα στοιχεία από την ανάλυση και τα «μεταφράζει»."""
from __future__ import annotations

import json
import re

from .. import db
from ..ml.features import HORIZONS as MLH
from . import manager

HZ_SIMPLE = {"day": "day trade για αύριο", "short": "για τις επόμενες 5 μέρες", "swing": "για τις επόμενες 3-5 εβδομάδες",
             "invest": "για μήνες", "rank5": "για τις επόμενες 5 μέρες", "rank21": "για τον επόμενο μήνα"}
STOP_WORDS = {"AI", "ETF", "RSI", "MACD", "ATR", "CEO", "USA", "US", "OK", "PE", "EPS", "SEC", "FDA", "IPO", "EMA", "SMA",
              "VWAP", "ADX", "TP", "SL", "RR", "ML", "VIX", "SPY", "NYSE", "GDP", "CPI", "FED", "THE", "AND", "BUY", "SELL"}


def _pct(v, d=1):
    return "—" if v is None else f"{v:+.{d}f}%"


def _money(v):
    return "—" if v is None else (f"${v:,.2f}" if v < 1000 else f"${v:,.0f}")


# ================================================================== απλή εικόνα μετοχής (χωρίς AI)
def simple_stock(b: dict, ml_pred: dict | None, accepted: list[dict]) -> dict:
    if not b.get("ok"):
        return {"verdict": "Άγνωστη", "tone": "neutral", "headline": b.get("reason", "Δεν υπάρχουν αρκετά δεδομένα."),
                "points": [], "plan": None, "risks": []}
    t, f, sc = b["tech"], b["fund"], b["scored"]
    m, fm = t.get("metrics", {}), f.get("metrics", {})
    flags = set(t.get("flags", [])) | set(f.get("flags", []))
    name = b.get("name") or b["ticker"]
    pts: list[str] = []

    # Πορεία
    r21, r63 = m.get("ret21"), m.get("ret63")
    rs = (m.get("rs") or {})
    if "trend_up" in flags:
        pts.append(f"Ανεβαίνει σταθερά τους τελευταίους μήνες (1 μήνας {_pct(r21)}, 3 μήνες {_pct(r63)}).")
    elif "trend_down" in flags:
        pts.append(f"Πέφτει σταθερά τους τελευταίους μήνες (1 μήνας {_pct(r21)}, 3 μήνες {_pct(r63)}).")
    elif r21 is not None and abs(r21) >= 12:
        pts.append(f"{'Ανέβηκε' if r21 > 0 else 'Έπεσε'} απότομα τον τελευταίο μήνα ({_pct(r21)}), "
                   f"αλλά η μακροπρόθεσμη πορεία δεν είναι ξεκάθαρη (3 μήνες {_pct(r63)}).")
    elif r21 is not None:
        pts.append(f"Δεν έχει καθαρή κατεύθυνση — τον τελευταίο μήνα {_pct(r21)}, 3 μήνες {_pct(r63)}.")
    if rs.get("excess") is not None and abs(rs["excess"]) >= 5:
        pts.append(f"Τα πάει {'καλύτερα' if rs['excess'] > 0 else 'χειρότερα'} από τη γενική αγορά "
                   f"({_pct(rs['excess'], 0)} διαφορά σε 3 μήνες).")
    # Ταχύτητα κίνησης
    rsi = m.get("rsi")
    if rsi is not None and rsi > 75:
        pts.append("Έχει ανέβει πολύ γρήγορα. Μετά από τέτοιες κινήσεις συχνά ακολουθεί μια «ανάσα» (μικρή πτώση).")
    elif rsi is not None and rsi < 30:
        pts.append("Έχει πέσει πολύ γρήγορα. Μερικές φορές ακολουθεί αναπήδηση — αλλά όχι πάντα.")
    # Όγκος
    rv = m.get("rvol")
    if rv and rv >= 2:
        pts.append(f"Σήμερα γίνονται {rv:.1f} φορές περισσότερες αγοραπωλησίες απ' ό,τι συνήθως — κάτι συμβαίνει με τη μετοχή.")
    # Μεταβλητότητα
    atr = m.get("atr_pct")
    if atr:
        speed = "πολύ νευρική" if atr > 6 else "νευρική" if atr > 3.5 else "σχετικά ήρεμη"
        pts.append(f"Είναι {speed} μετοχή: κινείται κατά μέσο όρο περίπου ±{atr:.1f}% τη μέρα.")
    if "near_52w_high" in flags:
        pts.append("Είναι κοντά στο υψηλότερο σημείο της χρονιάς.")
    elif "near_52w_low" in flags:
        pts.append("Είναι κοντά στο χαμηλότερο σημείο της χρονιάς.")
    if "breakout_20" in flags:
        pts.append("Μόλις ξεπέρασε το υψηλό του τελευταίου μήνα με πολλές αγορές — θετικό σημάδι.")
    if "fakeout" in flags:
        pts.append("Προσπάθησε να ανέβει πάνω από πρόσφατο υψηλό αλλά δεν κράτησε — αρνητικό σημάδι.")
    # Εταιρεία
    rg = fm.get("revenue_growth")
    if rg is not None and abs(rg) >= 0.01:
        pts.append(f"Οι πωλήσεις της εταιρείας {'αυξάνονται' if rg > 0 else 'μειώνονται'} ({_pct(rg * 100, 0)} σε έναν χρόνο).")
    elif rg is not None:
        pts.append("Οι πωλήσεις της εταιρείας είναι σχεδόν σταθερές σε σχέση με πέρσι.")
    if "unprofitable" in flags:
        pts.append("Η εταιρεία ακόμα χάνει χρήματα (δεν έχει κέρδη).")
    up = fm.get("analyst_upside_pct")
    if up is not None and (fm.get("n_analysts") or 0) >= 3:
        pts.append(f"Οι αναλυστές κατά μέσο όρο βλέπουν την τιμή στα {_money(fm.get('target_mean'))} ({_pct(up, 0)} από σήμερα).")
    # Ειδήσεις
    for n in (b.get("news") or {}).get("top", [])[:2]:
        s = n.get("sentiment") or 0
        tone = "θετική" if s > 0.15 else "αρνητική" if s < -0.15 else "ουδέτερη"
        pts.append(f"Είδηση {n['published_at'][:10]} ({n.get('source')}): «{n['title'][:110]}» — {tone}.")

    # Μοντέλο πρόβλεψης
    ml_lines = []
    for hz, p in (ml_pred or {}).items():
        if not isinstance(p, dict) or p.get("p") is None or not p.get("validated"):
            continue
        er = p.get("exp_r")
        if p.get("kind") == "rank":
            rp = p.get("rank_pct") or 0
            where = (f"στο καλύτερο {max(1, round((1 - rp) * 100))}% όλης της αγοράς" if rp >= 0.5
                     else f"στο χειρότερο {max(1, round(rp * 100))}% όλης της αγοράς")
            tail = "" if er is None else (f" Ιστορικά, τέτοιες μετοχές πήγαν {abs(er)*100:.1f}% "
                                          f"{'καλύτερα' if er > 0 else 'χειρότερα'} από την αγορά σε {p.get('days')} μέρες.")
            ml_lines.append(f"Μοντέλο κατάταξης ({p.get('days')} ημ.): η μετοχή είναι {where}.{tail}")
        else:
            if er is None:
                tail = ""
            elif er > 0:
                tail = f" Σε παρόμοιες περιπτώσεις στο παρελθόν, για κάθε 100€ ρίσκου κέρδιζες κατά μέσο όρο {er*100:.0f}€."
            else:
                tail = f" Σε παρόμοιες περιπτώσεις στο παρελθόν, για κάθε 100€ ρίσκου έχανες κατά μέσο όρο {abs(er)*100:.0f}€."
            ml_lines.append(f"Μοντέλο πρόβλεψης {HZ_SIMPLE.get(hz, hz)}: {p['p']*100:.0f}% πιθανότητα να πιάσει τον στόχο "
                            f"πριν το stop.{tail}")
    if not ml_lines and ml_pred:
        ml_lines.append("Το μοντέλο πρόβλεψης δεν έχει αποδείξει ακόμα ότι προβλέπει σωστά — δεν το λαμβάνω υπόψη.")

    # Ρίσκα
    risks = []
    dte = fm.get("days_to_earnings")
    if dte is not None and 0 <= dte <= 14:
        risks.append(f"Σε {dte} μέρες ({fm.get('earnings_date')}) βγάζει αποτελέσματα — η τιμή μπορεί να πηδήξει απότομα πάνω ή κάτω.")
    if "dilution_risk" in flags:
        risks.append("Ετοιμάζεται ή έκανε έκδοση νέων μετοχών — αυτό συχνά ρίχνει την τιμή.")
    if "high_short_interest" in flags:
        risks.append("Πολλοί ποντάρουν στην πτώση της (short) — μπορεί να κάνει πολύ απότομες κινήσεις.")
    dv = m.get("dollar_vol20")
    if dv is not None and dv < 5e6:
        risks.append("Λίγες συναλλαγές τη μέρα — μπορεί να μην μπορείς να πουλήσεις εύκολα στην τιμή που θες.")
    if atr and atr > 6:
        risks.append("Πολύ μεγάλες ημερήσιες διακυμάνσεις — βάλε μικρότερη θέση.")
    for w in b.get("risk", {}).get("warnings", []):
        if "παλιά" in w["text"].lower() or "ελλιπή δεδομένα τιμής" in w["text"].lower():
            risks.append("Τα δεδομένα τιμής δεν είναι φρέσκα — έλεγξε την τρέχουσα τιμή πριν κάνεις κάτι.")

    # Συμπέρασμα
    score = sc["score"]
    ml_ok = [p for p in (ml_pred or {}).values() if isinstance(p, dict) and p.get("validated") and p.get("p") is not None]
    ml_pos = any(((p.get("exp_r") or 0) >= 0.08) if p.get("kind") != "rank" else (p.get("rank_pct") or 0) >= 0.9 for p in ml_ok)
    ml_neg = bool(ml_ok) and all(((p.get("exp_r") or 0) < 0) if p.get("kind") != "rank" else (p.get("rank_pct") or 1) < 0.3
                                 for p in ml_ok)
    if accepted:
        verdict, tone = "Ευκαιρία", "up"
        head = f"Το σύστημα βλέπει ευκαιρία στην {name} που περνά όλους τους ελέγχους."
    elif score >= 60 and not ml_neg:
        verdict, tone = "Θετική εικόνα", "up"
        head = f"Η εικόνα της {name} είναι θετική, αλλά τώρα δεν υπάρχει καθαρό σημείο εισόδου."
    elif score <= 40 or ml_neg:
        verdict, tone = "Αρνητική εικόνα", "down"
        head = f"Η εικόνα της {name} είναι αρνητική — το σύστημα δεν βλέπει λόγο για αγορά τώρα."
    else:
        verdict, tone = "Ουδέτερη / αναμονή", "neutral"
        head = f"Η {name} δεν δίνει καθαρή εικόνα — καλύτερα αναμονή μέχρι να ξεκαθαρίσει."
    if ml_pos and not accepted:
        head += " Το μοντέλο πρόβλεψης πάντως τη βλέπει θετικά."

    plan = None
    if accepted:
        best = sorted(accepted, key=lambda a: -(a.get("ml_p") or 0) - a["score"] / 100)[0]
        price = best["price"]
        loss = (best["stop"] / best["entry"] - 1) * 100
        gain1 = (best["tp1"] / best["entry"] - 1) * 100
        gain2 = (best["tp2"] / best["entry"] - 1) * 100
        pos = best.get("position") or {}
        plan = {
            "title": f"Σχέδιο {HZ_SIMPLE.get(best['horizon'], '')}",
            "lines": [
                f"Είσοδος γύρω στα {_money(best['entry_low'])} – {_money(best['entry_high'])} (τώρα {_money(price)}).",
                f"Αν πέσει στα {_money(best['stop'])} βγαίνεις (απώλεια περίπου {loss:.1f}%).",
                f"Πρώτος στόχος {_money(best['tp1'])} ({gain1:+.1f}%) — εκεί κλείνεις ένα μέρος και ανεβάζεις το stop στην τιμή εισόδου.",
                f"Δεύτερος στόχος {_money(best['tp2'])} ({gain2:+.1f}%).",
                f"Μέγεθος: περίπου {pos.get('shares', '—')} μετοχές (${pos.get('position_value', 0):,.0f}) ώστε να ρισκάρεις "
                f"~${pos.get('risk_amount', 0):,.0f} ({pos.get('risk_pct_account', 0)}% του κεφαλαίου).",
            ],
        }
    return {"verdict": verdict, "tone": tone, "headline": head, "points": pts[:9], "model": ml_lines,
            "plan": plan, "risks": risks[:4], "score": score,
            "note": "Αυτά είναι τα στοιχεία του συστήματος σε απλά λόγια — όχι εγγύηση ούτε επενδυτική συμβουλή."}


# ================================================================== απλή εικόνα αγοράς (χωρίς AI)
def simple_market() -> dict:
    ctx = db.kv_get("last_context", {}) or {}
    mk = ctx.get("market") or {}
    lines = []
    reg = mk.get("regime")
    if reg == "Risk-on":
        lines.append("Η αγορά είναι σε καλή διάθεση: οι περισσότερες μετοχές ανεβαίνουν και ο φόβος είναι χαμηλός.")
    elif reg == "Risk-off":
        lines.append("Η αγορά είναι φοβισμένη/πτωτική: προσοχή, οι αγορές σε τέτοιες μέρες αποτυγχάνουν πιο συχνά.")
    elif reg:
        lines.append("Η αγορά δεν έχει καθαρή κατεύθυνση σήμερα.")
    vix = mk.get("vix")
    if vix:
        lines.append(f"Ο «δείκτης φόβου» (VIX) είναι {vix:.0f} — " + ("χαμηλός." if vix < 16 else "αυξημένος." if vix < 25 else "υψηλός, η αγορά είναι νευρική."))
    secs = (ctx.get("sectors") or [])[:3]
    if secs:
        lines.append("Οι πιο δυνατοί κλάδοι τώρα: " + ", ".join(s["sector"].replace("Θέμα: ", "") for s in secs) + ".")
    sig = db.q("SELECT ticker, horizon FROM signals WHERE status IN ('new','active','tp1','tp2') ORDER BY id DESC LIMIT 6")
    if sig:
        lines.append("Ενεργές ευκαιρίες που πέρασαν όλους τους ελέγχους: "
                     + ", ".join(dict.fromkeys(f"{s['ticker']} ({HZ_SIMPLE.get(s['horizon'], s['horizon'])})" for s in sig)) + ".")
    else:
        lines.append("Αυτή τη στιγμή δεν υπάρχει ευκαιρία που να περνά όλους τους ελέγχους — η αναμονή είναι επίσης θέση.")
    val = {r["horizon"] for r in db.q("SELECT horizon FROM ml_models WHERE validated=1")}
    if val:
        from ..ml.features import HORIZONS as MLH
        ranks = [h for h in ("rank5", "rank21") if h in val]
        hz = ranks[0] if ranks else sorted(val)[0]
        top = db.q("SELECT ticker, p, rank_pct FROM ml_predictions WHERE horizon=? AND date=(SELECT MAX(date) FROM ml_predictions "
                   "WHERE horizon=?) ORDER BY p DESC LIMIT 5", (hz, hz))
        if top and ranks:
            lines.append(f"Το μοντέλο κατάταξης βλέπει ως πιο δυνατές για τις επόμενες {MLH[hz]['H']} ημέρες: "
                         + ", ".join(r["ticker"] for r in top) + " (σχετικά με την υπόλοιπη αγορά, όχι εγγύηση ανόδου).")
        elif top:
            lines.append("Το μοντέλο πρόβλεψης βλέπει τις μεγαλύτερες πιθανότητες στόχου σε: "
                         + ", ".join(f"{r['ticker']} ({r['p']*100:.0f}%)" for r in top) + ".")
    return {"lines": lines, "as_of": mk.get("as_of"), "universe_n": ctx.get("universe_n"), "analyzed": ctx.get("analyzed")}


# ================================================================== chat
SYSTEM = (
    "Είσαι ο προσωπικός βοηθός μετοχών του χρήστη μέσα στην εφαρμογή US Alpha Terminal. Ο χρήστης κάνει day trading "
    "σε αμερικανικές μετοχές και θέλει ΑΠΛΑ ελληνικά: μικρές προτάσεις, καθημερινές λέξεις, χωρίς ορολογία. "
    "Αν χρειαστεί όρος (π.χ. stop), εξήγησέ τον σε παρένθεση με 3-4 λέξεις. "
    "Χρησιμοποίησε ΜΟΝΟ τα δεδομένα στο CONTEXT — μην επινοείς τιμές, ειδήσεις ή πιθανότητες. Για κάθε είδηση λέγε την ημερομηνία. "
    "Δώσε συγκεκριμένα νούμερα από το context (τιμή εισόδου, stop, στόχους, πιθανότητα μοντέλου) όταν υπάρχουν. "
    "Ξεκίνα με το συμπέρασμα σε 1 πρόταση, μετά 3-6 κουκκίδες, μετά τα ρίσκα. Μέχρι ~180 λέξεις εκτός αν ζητηθεί περισσότερο. "
    "Να είσαι ειλικρινής: αν τα στοιχεία είναι αρνητικά ή ανεπαρκή, πες το καθαρά. Μην υπόσχεσαι κέρδη. "
    "Αν το μοντέλο πρόβλεψης δεν είναι επικυρωμένο, μην το χρησιμοποιείς ως επιχείρημα. "
    "Μην επαναλαμβάνεις αποποίηση ευθύνης σε κάθε μήνυμα — μια σύντομη υπενθύμιση μόνο όταν ταιριάζει."
)


def detect_ticker(text: str) -> str | None:
    cands = re.findall(r"(?<![A-Za-z])([A-Za-z]{1,5}(?:-[A-Za-z])?)(?![A-Za-z])", text or "")
    for c in cands:
        u = c.upper()
        if u in STOP_WORDS and not c.isupper():
            continue
        if u in STOP_WORDS and len(cands) > 1:
            continue
        if db.q1("SELECT 1 FROM universe WHERE ticker=?", (u,)) or db.q1("SELECT 1 FROM prices_daily WHERE ticker=? LIMIT 1", (u,)):
            return u
    return None


def _compact_stock(b: dict, simple: dict, ml_pred: dict, accepted: list[dict], rejected: list[dict]) -> dict:
    m = b["tech"].get("metrics", {})
    fm = b["fund"].get("metrics", {})
    q = b.get("quote") or {}
    return {
        "ticker": b["ticker"], "name": b.get("name"), "sector": b.get("sector"),
        "price": q.get("price") or m.get("close"), "change_today_pct": q.get("change_pct"), "data_quality": q.get("quality"),
        "simple_summary": simple,
        "score_0_100": b["scored"]["score"],
        "returns_pct": {"1w": m.get("ret5"), "1m": m.get("ret21"), "3m": m.get("ret63"), "6m": m.get("ret126")},
        "vs_sp500_3m_pct": (m.get("rs") or {}).get("excess"), "rsi": m.get("rsi"), "avg_daily_move_pct": m.get("atr_pct"),
        "volume_vs_normal": m.get("rvol"), "high_52w": m.get("hi52"), "low_52w": m.get("lo52"),
        "support_resistance": b["tech"].get("levels"),
        "company": {k: fm.get(k) for k in ("market_cap", "pe", "forward_pe", "revenue_growth", "earnings_growth",
                                           "free_cash_flow", "debt_to_equity", "short_pct_float", "target_mean",
                                           "analyst_upside_pct", "earnings_date", "days_to_earnings")},
        "news": [{"date": n["published_at"][:10], "title": n["title"], "source": n.get("source"),
                  "sentiment": n.get("sentiment"), "already_in_price": n.get("priced_in")}
                 for n in (b.get("news") or {}).get("top", [])[:6]],
        "model_predictions": {hz: {k: p.get(k) for k in ("kind", "p", "breakeven", "validated", "exp_r", "rank_pct", "days",
                                                          "target_atr", "stop_atr")} | {
            "top_drivers": [(d["label"], d["effect"]) for d in (p.get("drivers") or [])[:5]]}
            for hz, p in (ml_pred or {}).items() if isinstance(p, dict)},
        "trade_plans_that_passed_all_checks": [{k: a.get(k) for k in ("horizon", "name", "entry_low", "entry_high", "stop",
                                                                       "tp1", "tp2", "tp3", "rr", "holding", "ml_p", "confidence")}
                                               for a in accepted],
        "setups_rejected_and_why": [{"horizon": r["horizon"], "name": r["name"], "why": r["rejected_because"][:3]}
                                    for r in rejected[:4]],
        "risks": simple.get("risks"),
    }


def analyze(ticker: str) -> tuple[dict, dict, dict, list, list]:
    from ..data import service
    from ..engine import pipeline, signals
    from ..ml import model as mlmodel
    if db.last_price_date(ticker) is None:
        service.update_history([ticker])
    c = db.kv_get("last_context", {}) or {}
    ctx = pipeline.Context.build(c.get("breadth"))
    b = pipeline.analyze_ticker(ticker, ctx, fetch_company=True, live=True)
    acc, rej = signals.evaluate_setups(b) if b.get("ok") else ([], [])
    try:
        ml_pred = mlmodel.prediction_for(ticker)
    except Exception:  # noqa: BLE001
        ml_pred = {}
    simple = simple_stock(b, ml_pred, acc)
    return b, simple, ml_pred, acc, rej


def _render_simple(s: dict, ticker: str) -> str:
    out = [f"**{ticker}: {s['verdict']}**", s["headline"], ""]
    out += [f"• {p}" for p in s["points"][:7]]
    out += [f"• {p}" for p in s.get("model", [])]
    if s.get("plan"):
        out += ["", f"**{s['plan']['title']}**"] + [f"• {x}" for x in s["plan"]["lines"]]
    if s.get("risks"):
        out += ["", "**Προσοχή:**"] + [f"• {x}" for x in s["risks"]]
    return "\n".join(out)


def chat(message: str, ticker: str | None = None, history: list[dict] | None = None) -> dict:
    ticker = (ticker or "").upper().strip() or detect_ticker(message)
    context, simple = {}, None
    if ticker:
        b, simple, ml_pred, acc, rej = analyze(ticker)
        if not b.get("ok"):
            return {"reply": f"Δεν βρήκα αρκετά δεδομένα για το {ticker}. Έλεγξε ότι το σύμβολο είναι σωστό (π.χ. AEHR, NVDA).",
                    "ticker": ticker, "used_ai": False}
        context = {"stock": _compact_stock(b, simple, ml_pred, acc, rej)}
    else:
        sm = simple_market()
        from ..engine import scanner
        top = [{"ticker": r["ticker"], "score": r["score"], "ml": r.get("ml"), "p_day": None, "p_5d": r.get("ml_short"),
                "change_pct": r.get("change_pct"), "setups": r.get("setups")} for r in scanner.latest_results(limit=15)]
        context = {"market_simple": sm, "top_scored": top,
                   "active_signals": db.q("SELECT ticker,horizon,bias,price,stop,tp1,tp2,ml_p FROM signals "
                                          "WHERE status IN ('new','active','tp1','tp2') ORDER BY id DESC LIMIT 10")}
    if manager.enabled():
        msgs = []
        for h in (history or [])[-6:]:
            role = "Χρήστης" if h.get("role") == "user" else "Βοηθός"
            msgs.append(f"{role}: {str(h.get('text', ''))[:800]}")
        prompt = ("CONTEXT (πραγματικά δεδομένα του συστήματος):\n" + json.dumps(context, ensure_ascii=False, default=str)[:14000]
                  + "\n\nΠΡΟΗΓΟΥΜΕΝΗ ΣΥΖΗΤΗΣΗ:\n" + "\n".join(msgs) + f"\n\nΕΡΩΤΗΣΗ ΧΡΗΣΤΗ: {message}")
        txt = manager.complete("assistant", SYSTEM, prompt, 900)
        if txt:
            return {"reply": txt.strip(), "ticker": ticker, "used_ai": True, "simple": simple}
    # χωρίς AI: απάντηση από κανόνες
    if ticker and simple:
        reply = _render_simple(simple, ticker)
    else:
        sm = simple_market()
        reply = "**Η αγορά σήμερα με απλά λόγια**\n" + "\n".join(f"• {x}" for x in sm["lines"]) + \
                "\n\nΓράψε ένα σύμβολο μετοχής (π.χ. AEHR) για να σου την εξηγήσω."
    if not manager.enabled():
        reply += "\n\n_(Απαντώ με τους κανόνες του συστήματος. Για ελεύθερη συζήτηση πρόσθεσε AI key στις Ρυθμίσεις.)_"
    return {"reply": reply, "ticker": ticker, "used_ai": False, "simple": simple}
