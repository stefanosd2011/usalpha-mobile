"""Modular AI layer: Anthropic / OpenAI / Gemini μέσω REST (httpx). Keys μόνο από .env στον server.
Rate limiting, retries, καταγραφή tokens και κόστους, μηνιαίο όριο κόστους, fallback provider.
Αν δεν υπάρχει key, όλες οι συναρτήσεις επιστρέφουν None και η εφαρμογή συνεχίζει χωρίς AI."""
from __future__ import annotations

import json
import logging
import re
import time
from datetime import datetime, timezone

import httpx

from .. import db
from ..config import CONFIG_DIR, settings
from ..data.net import RateLimiter

log = logging.getLogger("usalpha.ai")

PROVIDERS = {
    "anthropic": {"key": "ANTHROPIC_API_KEY", "default_model": "claude-haiku-5-5"},
    "openai": {"key": "OPENAI_API_KEY", "default_model": "gpt-4.1-mini"},
    "gemini": {"key": "GEMINI_API_KEY", "default_model": "gemini-3.8-flash"},
}

# USD ανά 1M tokens (input, output). ΕΚΤΙΜΗΣΕΙΣ — ενημέρωσέ τες στο config/ai_pricing.json
# από τη σελίδα τιμών του κάθε provider. Χρησιμοποιούνται μόνο για παρακολούθηση κόστους.
DEFAULT_PRICING = {
    "claude-haiku-5-5": [1.0, 5.0], "claude-sonnet-5-5": [3.0, 15.0], "claude-opus-5-5": [5.0, 25.0],
    "gpt-4.1-mini": [0.4, 1.6], "gemini-2.5-flash": [0.3, 2.5], "_default": [3.0, 15.0],
}

_limiter = RateLimiter(rate=max(1, settings.ai_max_calls_per_min), per=60)
_status: dict[str, dict] = {}


def pricing() -> dict:
    p = dict(DEFAULT_PRICING)
    f = CONFIG_DIR / "ai_pricing.json"
    if f.exists():
        try:
            p.update(json.loads(f.read_text(encoding="utf-8")))
        except Exception:
            pass
    return p


def available() -> list[str]:
    return [p for p, c in PROVIDERS.items() if settings.has(c["key"])]


def enabled() -> bool:
    return bool(available())


def model_for(provider: str) -> str:
    if provider == settings.ai_provider and settings.ai_model:
        return settings.ai_model
    auto = db.kv_get(f"ai_model_auto:{provider}")
    return auto or PROVIDERS[provider]["default_model"]


def _version_key(name: str) -> tuple:
    nums = [int(x) for x in __import__("re").findall(r"\d+", name)]
    return tuple(nums)


def resolve_latest_model(provider: str) -> str | None:
    """Όταν ένα μοντέλο αποσύρεται (HTTP 404), βρίσκει αυτόματα το νεότερο διαθέσιμο της ίδιας κατηγορίας."""
    key = settings.secret(PROVIDERS[provider]["key"])
    try:
        if provider == "gemini":
            r = httpx.get("https://generativelanguage.googleapis.com/v1beta/models", headers={"x-goog-api-key": key},
                          params={"pageSize": 200}, timeout=20)
            r.raise_for_status()
            names = [m["name"].split("/", 1)[-1] for m in r.json().get("models", [])
                     if "generateContent" in (m.get("supportedGenerationMethods") or [])]
            names = [n for n in names if "flash" in n and not any(x in n for x in ("lite", "image", "tts", "live", "exp", "preview", "thinking"))] or \
                [n for n in names if "flash" in n]
        elif provider == "anthropic":
            r = httpx.get("https://api.anthropic.com/v1/models", timeout=20, params={"limit": 100},
                          headers={"x-api-key": key, "anthropic-version": "2023-06-01"})
            r.raise_for_status()
            names = [m["id"] for m in r.json().get("data", [])]
            names = [n for n in names if "haiku" in n] or [n for n in names if "sonnet" in n] or names
        elif provider == "openai":
            r = httpx.get("https://api.openai.com/v1/models", headers={"Authorization": f"Bearer {key}"}, timeout=20)
            r.raise_for_status()
            names = [m["id"] for m in r.json().get("data", []) if m["id"].startswith("gpt-") and "mini" in m["id"]]
        else:
            return None
    except Exception as e:  # noqa: BLE001
        log.warning("model resolve %s failed: %s", provider, e)
        return None
    if not names:
        return None
    best = sorted(names, key=_version_key)[-1]
    db.kv_set(f"ai_model_auto:{provider}", best)
    log.info("AI %s: using latest model %s", provider, best)
    return best


# ---- Gemini: όταν ένα μοντέλο δεν έχει όριο (429 «limit: 0» / ημερήσιο όριο), δοκιμάζεται αυτόματα το επόμενο ----
_gem_exhausted: dict[str, str] = {}   # μοντέλο -> ημερομηνία UTC που εξαντλήθηκε
_gem_list: list[str] | None = None
_diag = {"ok": 0, "fail": 0, "errors": {}, "models_ok": {}, "last_error": None}


def _today() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")


def _gem_models(key: str) -> list[str]:
    """Όλα τα μοντέλα «flash» του κλειδιού (νεότερα πρώτα, μετά τα «lite»)."""
    global _gem_list
    if _gem_list is not None:
        return _gem_list
    names: list[str] = []
    try:
        r = httpx.get("https://generativelanguage.googleapis.com/v1beta/models", headers={"x-goog-api-key": key},
                      params={"pageSize": 200}, timeout=20)
        r.raise_for_status()
        names = [m["name"].split("/", 1)[-1] for m in r.json().get("models", [])
                 if "generateContent" in (m.get("supportedGenerationMethods") or [])]
    except Exception as e:  # noqa: BLE001
        log.warning("gemini models list failed: %s", str(e)[:150])
    bad = ("image", "tts", "live", "audio", "embedding", "thinking", "learnlm", "robotics", "computer")
    fl = [n for n in names if "flash" in n and not any(b in n for b in bad)]
    full = sorted([n for n in fl if "lite" not in n], key=_version_key, reverse=True)
    lite = sorted([n for n in fl if "lite" in n], key=_version_key, reverse=True)
    stable = [n for n in full if not any(x in n for x in ("preview", "exp"))] + [n for n in full if any(x in n for x in ("preview", "exp"))]
    _gem_list = stable + lite + [n for n in ("gemini-flash-latest", "gemini-flash-lite-latest") if n not in names]
    return _gem_list


def _gem_candidates(key: str) -> list[str]:
    first = model_for("gemini")
    day = _today()
    try:
        for m, d in (db.kv_get("gemini_exhausted") or {}).items():
            if d == day:
                _gem_exhausted.setdefault(m, d)
    except Exception:  # noqa: BLE001
        pass
    out = [first] + [m for m in _gem_models(key) if m != first]
    return [m for m in out if _gem_exhausted.get(m) != day] or [first]


def _quota_kind(resp: httpx.Response) -> tuple[str, float]:
    """('day'|'minute'|'other', δευτερόλεπτα αναμονής) από την απάντηση 429 της Google."""
    try:
        err = resp.json().get("error", {})
    except Exception:  # noqa: BLE001
        return "other", 5.0
    msg = str(err.get("message") or "")
    wait, kind = 5.0, "other"
    for d in err.get("details") or []:
        t = str(d.get("@type") or "")
        if t.endswith("RetryInfo"):
            try:
                wait = float(str(d.get("retryDelay") or "5s").rstrip("s"))
            except ValueError:
                pass
        if t.endswith("QuotaFailure"):
            for v in d.get("violations") or []:
                qid = str(v.get("quotaId") or "")
                if "PerDay" in qid or str(v.get("quotaValue")) == "0":
                    kind = "day"
                elif "PerMinute" in qid and kind != "day":
                    kind = "minute"
    if "limit: 0" in msg:
        kind = "day"
    return kind, wait


def _note(ok: bool, model: str, err: str | None = None) -> None:
    if ok:
        _diag["ok"] += 1
        _diag["models_ok"][model] = _diag["models_ok"].get(model, 0) + 1
    else:
        _diag["fail"] += 1
        k = (err or "")[:60]
        _diag["errors"][k] = _diag["errors"].get(k, 0) + 1
        _diag["last_error"] = (err or "")[:300]


def diagnostics() -> dict:
    """Σύνοψη για την αναφορά (χωρίς κλειδιά): πόσες κλήσεις πέτυχαν, με ποιο μοντέλο, τι λάθη έγιναν."""
    return {"providers": available(), "active": settings.ai_provider, "model": model_for(settings.ai_provider) if available() else None,
            "ok": _diag["ok"], "fail": _diag["fail"], "models_ok": dict(_diag["models_ok"]),
            "errors": dict(sorted(_diag["errors"].items(), key=lambda x: -x[1])[:6]), "last_error": _diag["last_error"],
            "exhausted_today": sorted(m for m, d in _gem_exhausted.items() if d == _today())}


def _gemini_generate(key: str, body: dict, timeout: int = 60) -> tuple[dict, str]:
    """POST generateContent με αυτόματη αλλαγή μοντέλου όταν κάποιο δεν έχει διαθέσιμο όριο σήμερα."""
    last: Exception | None = None
    for model in _gem_candidates(key)[:8]:
        for attempt in range(3):
            r = httpx.post(f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
                           timeout=timeout, headers={"x-goog-api-key": key}, json=body)
            if r.status_code == 429:
                kind, wait = _quota_kind(r)
                last = httpx.HTTPStatusError(f"429 {kind}", request=r.request, response=r)
                if kind == "day":
                    _gem_exhausted[model] = _today()
                    try:
                        db.kv_set("gemini_exhausted", {m: d for m, d in _gem_exhausted.items() if d == _today()})
                    except Exception:  # noqa: BLE001
                        pass
                    log.warning("gemini %s: χωρίς διαθέσιμο όριο σήμερα, δοκιμή επόμενου μοντέλου", model)
                    break
                time.sleep(min(65.0, max(2.0, wait)) if kind == "minute" else 3 * (attempt + 1))
                continue
            if r.status_code == 404:  # το μοντέλο δεν υπάρχει πια: επόμενο
                last = httpx.HTTPStatusError("404", request=r.request, response=r)
                break
            if r.status_code >= 500:
                last = httpx.HTTPStatusError(str(r.status_code), request=r.request, response=r)
                time.sleep(2 * (attempt + 1))
                continue
            r.raise_for_status()
            if model != model_for("gemini"):
                db.kv_set("ai_model_auto:gemini", model)
                log.info("AI gemini: χρήση μοντέλου %s", model)
            return r.json(), model
    if last:
        raise last
    raise RuntimeError("gemini: κανένα μοντέλο")


def month_cost() -> float:
    start = datetime.now(timezone.utc).strftime("%Y-%m-01")
    r = db.q1("SELECT COALESCE(SUM(cost_usd),0) c FROM ai_usage WHERE at>=?", (start,))
    return float(r["c"]) if r else 0.0


def usage_summary() -> dict:
    start = datetime.now(timezone.utc).strftime("%Y-%m-01")
    rows = db.q("SELECT provider, model, purpose, COUNT(*) n, SUM(input_tokens) it, SUM(output_tokens) ot, "
                "SUM(cost_usd) c, SUM(ok) okn FROM ai_usage WHERE at>=? GROUP BY provider, model, purpose", (start,))
    return {"month_cost_usd": round(month_cost(), 4), "budget_usd": settings.ai_monthly_budget_usd,
            "rows": rows, "status": status()}


def status() -> dict:
    out = {}
    for p, c in PROVIDERS.items():
        out[p] = {"configured": settings.has(c["key"]), "model": model_for(p),
                  "active": p == settings.ai_provider, **_status.get(p, {})}
    return out


def _cost(model: str, it: int, ot: int) -> float:
    pr = pricing()
    pin, pout = pr.get(model, pr["_default"])
    return (it * pin + ot * pout) / 1e6


def _call(provider: str, system: str, prompt: str, max_tokens: int, json_mode: bool) -> tuple[str, int, int]:
    key = settings.secret(PROVIDERS[provider]["key"])
    model = model_for(provider)
    if provider == "anthropic":
        r = httpx.post("https://api.anthropic.com/v1/messages", timeout=60,
                       headers={"x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"},
                       json={"model": model, "max_tokens": max_tokens, "system": system,
                             "messages": [{"role": "user", "content": prompt}]})
        r.raise_for_status()
        d = r.json()
        text = "".join(b.get("text", "") for b in d.get("content", []) if b.get("type") == "text")
        u = d.get("usage", {})
        return text, u.get("input_tokens", 0), u.get("output_tokens", 0)
    if provider == "openai":
        body = {"model": model, "max_tokens": max_tokens,
                "messages": [{"role": "system", "content": system}, {"role": "user", "content": prompt}]}
        if json_mode:
            body["response_format"] = {"type": "json_object"}
        r = httpx.post("https://api.openai.com/v1/chat/completions", timeout=60,
                       headers={"Authorization": f"Bearer {key}"}, json=body)
        r.raise_for_status()
        d = r.json()
        u = d.get("usage", {})
        return d["choices"][0]["message"]["content"], u.get("prompt_tokens", 0), u.get("completion_tokens", 0)
    if provider == "gemini":
        body = {"systemInstruction": {"parts": [{"text": system}]},
                "contents": [{"role": "user", "parts": [{"text": prompt}]}],
                # τα νεότερα Gemini «σκέφτονται» πρώτα και η σκέψη τρώει από το όριο: περισσότερο περιθώριο,
                # αλλιώς η απάντηση κόβεται στη μέση (π.χ. μισό JSON)
                "generationConfig": {"maxOutputTokens": max(int(max_tokens) * 4, 4096),
                                     **({"responseMimeType": "application/json"} if json_mode else {})}}
        d, _m = _gemini_generate(key, body, 90)
        text = "".join(p.get("text", "") for p in d["candidates"][0]["content"].get("parts", []) if not p.get("thought"))
        u = d.get("usageMetadata", {})
        return text, u.get("promptTokenCount", 0), u.get("candidatesTokenCount", 0)
    raise ValueError(provider)


def complete(purpose: str, system: str, prompt: str, max_tokens: int = 800, json_mode: bool = False) -> str | None:
    provs = available()
    if not provs:
        return None
    if month_cost() >= settings.ai_monthly_budget_usd:
        log.warning("AI budget reached")
        _status.setdefault(settings.ai_provider, {})["last_error"] = "Έφτασε το μηνιαίο όριο κόστους"
        return None
    order = ([settings.ai_provider] if settings.ai_provider in provs else []) + [p for p in provs if p != settings.ai_provider]
    for prov in order:
        model = model_for(prov)
        for attempt in range(3):
            _limiter.wait()
            t0 = time.perf_counter()
            try:
                text, it, ot = _call(prov, system, prompt, max_tokens, json_mode)
                model = model_for(prov)
                _note(True, model)
                cost = _cost(model, it, ot)
                db.execute("INSERT INTO ai_usage(at,provider,model,purpose,input_tokens,output_tokens,cost_usd,ok,error) "
                           "VALUES(?,?,?,?,?,?,?,1,'')", (db.now_iso(), prov, model, purpose, it, ot, cost))
                _status[prov] = {"ok": True, "last_ok": db.now_iso(), "latency_ms": round((time.perf_counter() - t0) * 1000)}
                return text
            except httpx.HTTPStatusError as e:
                code = e.response.status_code
                err = f"HTTP {code}: {e.response.text[:200]}"
                _note(False, model, err)
                db.execute("INSERT INTO ai_usage(at,provider,model,purpose,input_tokens,output_tokens,cost_usd,ok,error) "
                           "VALUES(?,?,?,?,0,0,0,0,?)", (db.now_iso(), prov, model, purpose, err))
                _status[prov] = {"ok": False, "last_error": err, "at": db.now_iso()}
                if code == 404 and attempt == 0 and resolve_latest_model(prov):
                    model = model_for(prov)
                    continue  # το μοντέλο αποσύρθηκε: ξαναδοκιμή με το νεότερο
                if code in (401, 403):
                    _status[prov]["last_error"] = "Μη έγκυρο API key — κάνε ξανά επικόλληση στις Ρυθμίσεις. " + err[:120]
                if code in (400, 401, 403, 404) or (code == 429 and prov == "gemini"):
                    break  # λάθος key/μοντέλο ή κανένα μοντέλο Gemini με όριο σήμερα: πάμε στον επόμενο provider
                time.sleep(2 ** attempt * (3 if code == 429 else 1))
            except Exception as e:  # noqa: BLE001
                _status[prov] = {"ok": False, "last_error": repr(e)[:200], "at": db.now_iso()}
                _note(False, model, repr(e)[:200])
                time.sleep(2 ** attempt)
    return None


def vision(system: str, prompt: str, b64: str, mime: str = "image/jpeg", max_tokens: int = 3000) -> str | None:
    """Ανάγνωση εικόνας (π.χ. screenshot χαρτοφυλακίου) με όποιο AI έχει κλειδί στο .env. Η εικόνα δεν αποθηκεύεται."""
    for prov in [p for p in ([settings.ai_provider] + list(PROVIDERS)) if p in available() and p in ("gemini", "anthropic")]:
        key, model = settings.secret(PROVIDERS[prov]["key"]), model_for(prov)
        try:
            _limiter.wait()
            if prov == "gemini":
                d, _m = _gemini_generate(key, {"systemInstruction": {"parts": [{"text": system}]},
                                               "contents": [{"role": "user", "parts": [{"text": prompt}, {"inline_data": {"mime_type": mime, "data": b64}}]}],
                                               "generationConfig": {"temperature": 0, "maxOutputTokens": max(int(max_tokens) * 3, 8192), "responseMimeType": "application/json"}}, 120)
                return "".join(p.get("text", "") for p in d["candidates"][0]["content"].get("parts", []) if not p.get("thought"))
            r = httpx.post("https://api.anthropic.com/v1/messages", timeout=90,
                           headers={"x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"},
                           json={"model": model, "max_tokens": max_tokens, "system": system,
                                 "messages": [{"role": "user", "content": [{"type": "image", "source": {"type": "base64", "media_type": mime, "data": b64}},
                                                                           {"type": "text", "text": prompt}]}]})
            r.raise_for_status()
            return "".join(b.get("text", "") for b in r.json().get("content", []) if b.get("type") == "text")
        except Exception as e:  # noqa: BLE001
            log.warning("vision %s failed: %s", prov, str(e)[:200])
            continue
    return None


def complete_json(purpose: str, system: str, prompt: str, max_tokens: int = 1200):
    txt = complete(purpose, system + "\nΑπάντησε ΜΟΝΟ με έγκυρο JSON.", prompt, max_tokens, json_mode=True)
    if not txt:
        return None
    m = re.search(r"(\{.*\}|\[.*\])", txt, re.S)
    try:
        return json.loads(m.group(1) if m else txt)
    except Exception:
        log.warning("AI JSON parse failed")
        return None


def test_connection(provider: str) -> dict:
    if not settings.has(PROVIDERS[provider]["key"]):
        return {"ok": False, "error": "Δεν έχει οριστεί API key"}
    try:
        text, it, ot = _call(provider, "Reply with OK.", "ping", 5, False)
        _status[provider] = {"ok": True, "last_ok": db.now_iso()}
        return {"ok": True, "reply": text[:20], "model": model_for(provider)}
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404 and resolve_latest_model(provider):
            return test_connection(provider)
        if e.response.status_code in (401, 403):
            return {"ok": False, "error": "Μη έγκυρο API key — έλεγξε ότι το αντέγραψες ολόκληρο."}
        return {"ok": False, "error": f"HTTP {e.response.status_code}: {e.response.text[:200]}"}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": repr(e)[:200]}
