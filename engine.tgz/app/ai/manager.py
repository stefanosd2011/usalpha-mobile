"""Modular AI layer: Anthropic / OpenAI / Gemini μέσω REST (httpx). Keys μόνο από .env στον server.
Rate limiting, retries, καταγραφή tokens και κόστους, μηνιαίο όριο κόστους, fallback provider.
Αν δεν υπάρχει key, όλες οι συναρτήσεις επιστρέφουν None και η εφαρμογή συνεχίζει χωρίς AI."""
from __future__ import annotations

import json
import logging
import re
import time
from datetime import datetime, timezone

import httpx

from .. import db
from ..config import CONFIG_DIR, settings
from ..data.net import RateLimiter

log = logging.getLogger("usalpha.ai")

PROVIDERS = {
    "anthropic": {"key": "ANTHROPIC_API_KEY", "default_model": "claude-haiku-5-5"},
    "openai": {"key": "OPENAI_API_KEY", "default_model": "gpt-4.1-mini"},
    "gemini": {"key": "GEMINI_API_KEY", "default_model": "gemini-3.8-flash"},
}

# USD ανά 1M tokens (input, output). ΕΚΤΙΜΗΣΕΙΣ — ενημέρωσέ τες στο config/ai_pricing.json
# από τη σελίδα τιμών του κάθε provider. Χρησιμοποιούνται μόνο για παρακολούθηση κόστους.
DEFAULT_PRICING = {
    "claude-haiku-5-5": [1.0, 5.0], "claude-sonnet-5-5": [3.0, 15.0], "claude-opus-5-5": [5.0, 25.0],
    "gpt-4.1-mini": [0.4, 1.6], "gemini-2.5-flash": [0.3, 2.5], "_default": [3.0, 15.0],
}

_limiter = RateLimiter(rate=max(1, settings.ai_max_calls_per_min), per=60)
_status: dict[str, dict] = {}


def pricing() -> dict:
    p = dict(DEFAULT_PRICING)
    f = CONFIG_DIR / "ai_pricing.json"
    if f.exists():
        try:
            p.update(json.loads(f.read_text(encoding="utf-8")))
        except Exception:
            pass
    return p


def available() -> list[str]:
    return [p for p, c in PROVIDERS.items() if settings.has(c["key"])]


def enabled() -> bool:
    return bool(available())


def model_for(provider: str) -> str:
    if provider == settings.ai_provider and settings.ai_model:
        return settings.ai_model
    auto = db.kv_get(f"ai_model_auto:{provider}")
    return auto or PROVIDERS[provider]["default_model"]


def _version_key(name: str) -> tuple:
    nums = [int(x) for x in __import__("re").findall(r"\d+", name)]
    return tuple(nums)


def resolve_latest_model(provider: str) -> str | None:
    """Όταν ένα μοντέλο αποσύρεται (HTTP 404), βρίσκει αυτόματα το νεότερο διαθέσιμο της ίδιας κατηγορίας."""
    key = settings.secret(PROVIDERS[provider]["key"])
    try:
        if provider == "gemini":
            r = httpx.get("https://generativelanguage.googleapis.com/v1beta/models", headers={"x-goog-api-key": key},
                          params={"pageSize": 200}, timeout=20)
            r.raise_for_status()
            names = [m["name"].split("/", 1)[-1] for m in r.json().get("models", [])
                     if "generateContent" in (m.get("supportedGenerationMethods") or [])]
            names = [n for n in names if "flash" in n and not any(x in n for x in ("lite", "image", "tts", "live", "exp", "preview", "thinking"))] or \
                [n for n in names if "flash" in n]
        elif provider == "anthropic":
            r = httpx.get("https://api.anthropic.com/v1/models", timeout=20, params={"limit": 100},
                          headers={"x-api-key": key, "anthropic-version": "2023-06-01"})
            r.raise_for_status()
            names = [m["id"] for m in r.json().get("data", [])]
            names = [n for n in names if "haiku" in n] or [n for n in names if "sonnet" in n] or names
        elif provider == "openai":
            r = httpx.get("https://api.openai.com/v1/models", headers={"Authorization": f"Bearer {key}"}, timeout=20)
            r.raise_for_status()
            names = [m["id"] for m in r.json().get("data", []) if m["id"].startswith("gpt-") and "mini" in m["id"]]
        else:
            return None
    except Exception as e:  # noqa: BLE001
        log.warning("model resolve %s failed: %s", provider, e)
        return None
    if not names:
        return None
    best = sorted(names, key=_version_key)[-1]
    db.kv_set(f"ai_model_auto:{provider}", best)
    log.info("AI %s: using latest model %s", provider, best)
    return best


def month_cost() -> float:
    start = datetime.now(timezone.utc).strftime("%Y-%m-01")
    r = db.q1("SELECT COALESCE(SUM(cost_usd),0) c FROM ai_usage WHERE at>=?", (start,))
    return float(r["c"]) if r else 0.0


def usage_summary() -> dict:
    start = datetime.now(timezone.utc).strftime("%Y-%m-01")
    rows = db.q("SELECT provider, model, purpose, COUNT(*) n, SUM(input_tokens) it, SUM(output_tokens) ot, "
                "SUM(cost_usd) c, SUM(ok) okn FROM ai_usage WHERE at>=? GROUP BY provider, model, purpose", (start,))
    return {"month_cost_usd": round(month_cost(), 4), "budget_usd": settings.ai_monthly_budget_usd,
            "rows": rows, "status": status()}


def status() -> dict:
    out = {}
    for p, c in PROVIDERS.items():
        out[p] = {"configured": settings.has(c["key"]), "model": model_for(p),
                  "active": p == settings.ai_provider, **_status.get(p, {})}
    return out


def _cost(model: str, it: int, ot: int) -> float:
    pr = pricing()
    pin, pout = pr.get(model, pr["_default"])
    return (it * pin + ot * pout) / 1e6


def _call(provider: str, system: str, prompt: str, max_tokens: int, json_mode: bool) -> tuple[str, int, int]:
    key = settings.secret(PROVIDERS[provider]["key"])
    model = model_for(provider)
    if provider == "anthropic":
        r = httpx.post("https://api.anthropic.com/v1/messages", timeout=60,
                       headers={"x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"},
                       json={"model": model, "max_tokens": max_tokens, "system": system,
                             "messages": [{"role": "user", "content": prompt}]})
        r.raise_for_status()
        d = r.json()
        text = "".join(b.get("text", "") for b in d.get("content", []) if b.get("type") == "text")
        u = d.get("usage", {})
        return text, u.get("input_tokens", 0), u.get("output_tokens", 0)
    if provider == "openai":
        body = {"model": model, "max_tokens": max_tokens,
                "messages": [{"role": "system", "content": system}, {"role": "user", "content": prompt}]}
        if json_mode:
            body["response_format"] = {"type": "json_object"}
        r = httpx.post("https://api.openai.com/v1/chat/completions", timeout=60,
                       headers={"Authorization": f"Bearer {key}"}, json=body)
        r.raise_for_status()
        d = r.json()
        u = d.get("usage", {})
        return d["choices"][0]["message"]["content"], u.get("prompt_tokens", 0), u.get("completion_tokens", 0)
    if provider == "gemini":
        body = {"systemInstruction": {"parts": [{"text": system}]},
                "contents": [{"role": "user", "parts": [{"text": prompt}]}],
                "generationConfig": {"maxOutputTokens": max_tokens,
                                     **({"responseMimeType": "application/json"} if json_mode else {})}}
        r = httpx.post(f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
                       timeout=60, headers={"x-goog-api-key": key}, json=body)
        r.raise_for_status()
        d = r.json()
        text = "".join(p.get("text", "") for p in d["candidates"][0]["content"]["parts"])
        u = d.get("usageMetadata", {})
        return text, u.get("promptTokenCount", 0), u.get("candidatesTokenCount", 0)
    raise ValueError(provider)


def complete(purpose: str, system: str, prompt: str, max_tokens: int = 800, json_mode: bool = False) -> str | None:
    provs = available()
    if not provs:
        return None
    if month_cost() >= settings.ai_monthly_budget_usd:
        log.warning("AI budget reached")
        _status.setdefault(settings.ai_provider, {})["last_error"] = "Έφτασε το μηνιαίο όριο κόστους"
        return None
    order = ([settings.ai_provider] if settings.ai_provider in provs else []) + [p for p in provs if p != settings.ai_provider]
    for prov in order:
        model = model_for(prov)
        for attempt in range(3):
            _limiter.wait()
            t0 = time.perf_counter()
            try:
                text, it, ot = _call(prov, system, prompt, max_tokens, json_mode)
                cost = _cost(model, it, ot)
                db.execute("INSERT INTO ai_usage(at,provider,model,purpose,input_tokens,output_tokens,cost_usd,ok,error) "
                           "VALUES(?,?,?,?,?,?,?,1,'')", (db.now_iso(), prov, model, purpose, it, ot, cost))
                _status[prov] = {"ok": True, "last_ok": db.now_iso(), "latency_ms": round((time.perf_counter() - t0) * 1000)}
                return text
            except httpx.HTTPStatusError as e:
                code = e.response.status_code
                err = f"HTTP {code}: {e.response.text[:200]}"
                db.execute("INSERT INTO ai_usage(at,provider,model,purpose,input_tokens,output_tokens,cost_usd,ok,error) "
                           "VALUES(?,?,?,?,0,0,0,0,?)", (db.now_iso(), prov, model, purpose, err))
                _status[prov] = {"ok": False, "last_error": err, "at": db.now_iso()}
                if code == 404 and attempt == 0 and resolve_latest_model(prov):
                    model = model_for(prov)
                    continue  # το μοντέλο αποσύρθηκε: ξαναδοκιμή με το νεότερο
                if code in (401, 403):
                    _status[prov]["last_error"] = "Μη έγκυρο API key — κάνε ξανά επικόλληση στις Ρυθμίσεις. " + err[:120]
                if code in (400, 401, 403, 404):
                    break  # λάθος key/μοντέλο: δεν έχει νόημα retry, πάμε στον επόμενο provider
                time.sleep(2 ** attempt * (3 if code == 429 else 1))
            except Exception as e:  # noqa: BLE001
                _status[prov] = {"ok": False, "last_error": repr(e)[:200], "at": db.now_iso()}
                time.sleep(2 ** attempt)
    return None


def vision(system: str, prompt: str, b64: str, mime: str = "image/jpeg", max_tokens: int = 3000) -> str | None:
    """Ανάγνωση εικόνας (π.χ. screenshot χαρτοφυλακίου) με όποιο AI έχει κλειδί στο .env. Η εικόνα δεν αποθηκεύεται."""
    for prov in [p for p in ([settings.ai_provider] + list(PROVIDERS)) if p in available() and p in ("gemini", "anthropic")]:
        key, model = settings.secret(PROVIDERS[prov]["key"]), model_for(prov)
        try:
            _limiter.wait()
            if prov == "gemini":
                r = httpx.post(f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent", timeout=90,
                               headers={"x-goog-api-key": key},
                               json={"systemInstruction": {"parts": [{"text": system}]},
                                     "contents": [{"role": "user", "parts": [{"text": prompt}, {"inline_data": {"mime_type": mime, "data": b64}}]}],
                                     "generationConfig": {"temperature": 0, "maxOutputTokens": max_tokens, "responseMimeType": "application/json"}})
                r.raise_for_status()
                return "".join(p.get("text", "") for p in r.json()["candidates"][0]["content"]["parts"])
            r = httpx.post("https://api.anthropic.com/v1/messages", timeout=90,
                           headers={"x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"},
                           json={"model": model, "max_tokens": max_tokens, "system": system,
                                 "messages": [{"role": "user", "content": [{"type": "image", "source": {"type": "base64", "media_type": mime, "data": b64}},
                                                                           {"type": "text", "text": prompt}]}]})
            r.raise_for_status()
            return "".join(b.get("text", "") for b in r.json().get("content", []) if b.get("type") == "text")
        except Exception as e:  # noqa: BLE001
            log.warning("vision %s failed: %s", prov, str(e)[:200])
            continue
    return None


def complete_json(purpose: str, system: str, prompt: str, max_tokens: int = 1200):
    txt = complete(purpose, system + "\nΑπάντησε ΜΟΝΟ με έγκυρο JSON.", prompt, max_tokens, json_mode=True)
    if not txt:
        return None
    m = re.search(r"(\{.*\}|\[.*\])", txt, re.S)
    try:
        return json.loads(m.group(1) if m else txt)
    except Exception:
        log.warning("AI JSON parse failed")
        return None


def test_connection(provider: str) -> dict:
    if not settings.has(PROVIDERS[provider]["key"]):
        return {"ok": False, "error": "Δεν έχει οριστεί API key"}
    try:
        text, it, ot = _call(provider, "Reply with OK.", "ping", 5, False)
        _status[provider] = {"ok": True, "last_ok": db.now_iso()}
        return {"ok": True, "reply": text[:20], "model": model_for(provider)}
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404 and resolve_latest_model(provider):
            return test_connection(provider)
        if e.response.status_code in (401, 403):
            return {"ok": False, "error": "Μη έγκυρο API key — έλεγξε ότι το αντέγραψες ολόκληρο."}
        return {"ok": False, "error": f"HTTP {e.response.status_code}: {e.response.text[:200]}"}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": repr(e)[:200]}
