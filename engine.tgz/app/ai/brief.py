"""Ενημερώσεις AI τρεις φορές τη μέρα (ώρα Ελλάδας): πρωί, πριν ανοίξει η Wall Street, μετά το κλείσιμο
(+ η βραδινή πλήρης ανάλυση). Κάθε ενημέρωση έχει:
- παγκόσμιες αγορές τώρα (συμβόλαια ΗΠΑ, Ευρώπη, Ασία, επιτόκια, δολάριο, πετρέλαιο, χρυσός, bitcoin)
- φρέσκες ειδήσεις από πολλές πηγές (χωρίς κλειδιά)
- τι κάνουν πριν το άνοιγμα / στο κλείσιμο οι μετοχές που προτείνει το σύστημα
- σύνοψη, βασικά σημεία, τι να προσέξεις, κίνδυνο και σημείωση ανά μετοχή, γραμμένα από AI

ΟΛΟΙ οι αριθμοί υπολογίζονται από τον κώδικα· το AI μόνο τους εξηγεί (δεν επινοεί τιμές ή ειδήσεις).
Το κλειδί AI δεν γράφεται ποτέ σε αρχείο (GitHub secret ή .env). Χωρίς κλειδί δεν γράφεται κείμενο AI,
αλλά οι αριθμοί (αγορές, ειδήσεις, κινήσεις) δημοσιεύονται κανονικά."""
from __future__ import annotations

import json
import logging
import math
import re
import time
from datetime import datetime, timedelta, timezone

from . import manager

log = logging.getLogger("usalpha.ai.brief")

# (σύμβολο, όνομα, ομάδα, μονάδα μεταβολής)
GLOBAL = [
    ("ES=F", "S&P 500 (συμβόλαια)", "ΗΠΑ", "%"), ("NQ=F", "Nasdaq 100 (συμβόλαια)", "ΗΠΑ", "%"),
    ("YM=F", "Dow Jones (συμβόλαια)", "ΗΠΑ", "%"), ("RTY=F", "Russell 2000 (συμβόλαια)", "ΗΠΑ", "%"),
    ("^VIX", "VIX (φόβος)", "Κίνδυνος", "%"), ("^TNX", "Απόδοση 10ετούς ΗΠΑ", "Επιτόκια", "bp"),
    ("DX-Y.NYB", "Δολάριο (DXY)", "Νομίσματα", "%"), ("EURUSD=X", "Ευρώ / Δολάριο", "Νομίσματα", "%"),
    ("CL=F", "Πετρέλαιο WTI", "Εμπορεύματα", "%"), ("GC=F", "Χρυσός", "Εμπορεύματα", "%"),
    ("BTC-USD", "Bitcoin", "Κρυπτο", "%"),
    ("^STOXX50E", "Euro Stoxx 50", "Ευρώπη", "%"), ("^GDAXI", "DAX Γερμανία", "Ευρώπη", "%"),
    ("^FTSE", "FTSE 100 Λονδίνο", "Ευρώπη", "%"),
    ("^N225", "Nikkei Ιαπωνία", "Ασία", "%"), ("^HSI", "Hang Seng Χονγκ Κονγκ", "Ασία", "%"),
]

SLOTS = {
    "morning": {"label": "Πρωινή ενημέρωση", "short": "Πρωί",
                "task": ("Είναι πρωί στην Ελλάδα· η Wall Street ανοίγει στις {open_gr} ώρα Ελλάδας. Γράψε την πρωινή "
                         "ενημέρωση: τι έγινε από το χθεσινό κλείσιμο (Ασία, Ευρώπη που μόλις άνοιξε, συμβόλαια ΗΠΑ, "
                         "επιτόκια, δολάριο, πετρέλαιο, χρυσός, bitcoin), οι ειδήσεις που μετράνε και τι σημαίνουν όλα αυτά "
                         "για τη σημερινή μέρα στις ΗΠΑ και για τις μετοχές του συστήματος.")},
    "premarket": {"label": "Πριν το άνοιγμα", "short": "Μεσημέρι",
                  "task": ("Λίγο πριν ανοίξει η Wall Street ({open_gr} ώρα Ελλάδας). Γράψε τι πρέπει να ξέρει τώρα κάποιος "
                           "που κάνει trading: πού δείχνουν τα συμβόλαια, ποιες μετοχές του συστήματος ανοίγουν με κενό "
                           "(gap) πάνω/κάτω πριν το άνοιγμα και τι σημαίνει αυτό για το πλάνο εισόδου (π.χ. αν η τιμή "
                           "ήδη ξεπέρασε τη ζώνη εισόδου, να μην την κυνηγήσει), οι φρέσκες ειδήσεις και τι να προσέξει "
                           "στα πρώτα 30 λεπτά.")},
    "evening": {"label": "Κλείσιμο Wall Street", "short": "Βράδυ",
                "task": ("Η Wall Street μόλις έκλεισε. Γράψε πώς έκλεισε η μέρα: δείκτες, κλάδοι, οι μεγαλύτερες κινήσεις "
                         "με τον λόγο τους αν υπάρχει είδηση, πώς πήγαν οι μετοχές που πρότεινε το σύστημα σήμερα "
                         "(με βάση τα δεδομένα), και τι να προσέξει αύριο.")},
    "night": {"label": "Βραδινή ανάλυση", "short": "Βράδυ",
              "task": ("Η πλήρης βραδινή ανάλυση όλης της αγοράς τελείωσε. Γράψε τι βλέπει το σύστημα για αύριο: διάθεση "
                       "αγοράς, κλάδοι, οι υποψήφιες για day trade και οι ευκαιρίες, και τι να προσέξει αύριο.")},
}

SYS = ("Είσαι έμπειρος, έντιμος αναλυτής αγορών και γράφεις για απλό Έλληνα επενδυτή που κάνει και trading. "
       "Ελληνικά, απλά και συγκεκριμένα, χωρίς γενικολογίες. Χρησιμοποιείς ΜΟΝΟ τα δεδομένα που σου δίνονται: "
       "δεν επινοείς αριθμούς, ειδήσεις, γεγονότα ή ώρες ανακοινώσεων. Κάθε αριθμός που γράφεις πρέπει να υπάρχει "
       "στα δεδομένα. Αν κάτι δεν φαίνεται στα δεδομένα, δεν το λες. Ξεχωρίζεις γεγονός από εκτίμηση. "
       "Αναφέρεις πάντα κινδύνους. Δεν λες «σίγουρα», δεν δίνεις εγγυήσεις. Δεν είναι επενδυτική συμβουλή.")

NY_TZ = "America/New_York"


def _num(x):
    try:
        v = float(x)
        return v if math.isfinite(v) else None
    except (TypeError, ValueError):
        return None


def _r(x, n=2):
    v = _num(x)
    return None if v is None else round(v, n)


# ---------------------------------------------------------------------------------------------- χρόνος / slot
def now_ny() -> datetime:
    from zoneinfo import ZoneInfo
    return datetime.now(ZoneInfo(NY_TZ))


def open_time_gr(d: datetime | None = None) -> str:
    """Ώρα ανοίγματος της Wall Street σε ώρα Ελλάδας (συνήθως 16:30, για λίγες εβδομάδες 15:30)."""
    from zoneinfo import ZoneInfo
    d = d or now_ny()
    op = d.replace(hour=9, minute=30, second=0, microsecond=0)
    return op.astimezone(ZoneInfo("Europe/Athens")).strftime("%H:%M")


def auto_slot(d: datetime | None = None) -> str | None:
    """Ποια ενημέρωση ταιριάζει τώρα (ώρα Ν. Υόρκης). None = καμία (π.χ. Σαββατοκύριακο ή εκτός ωρών)."""
    from ..data.session import is_trading_day
    d = d or now_ny()
    if not is_trading_day(d.date()):
        return None
    hm = d.hour * 60 + d.minute
    from zoneinfo import ZoneInfo
    gr = d.astimezone(ZoneInfo("Europe/Athens"))
    if hm < 8 * 60:
        # πρωί για τον χρήστη (Ελλάδα): από τις 09:00 και μετά, όποια κι αν είναι η θερινή/χειμερινή ώρα
        return "morning" if 9 <= gr.hour < 13 else None
    if 8 * 60 <= hm < 9 * 60 + 30:
        return "premarket"
    if 16 * 60 <= hm < 21 * 60:
        return "evening"
    return None


# ---------------------------------------------------------------------------------------------- δεδομένα
def _download(syms: list[str], **kw):
    import yfinance as yf
    for attempt in range(3):
        try:
            return yf.download(syms, group_by="ticker", auto_adjust=False, threads=True, progress=False,
                               multi_level_index=True, **kw)
        except Exception as e:  # noqa: BLE001
            log.warning("download retry %s: %s", attempt, e)
            time.sleep(4 * (attempt + 1))
    return None


def _sub(df, sym):
    try:
        if df is None or sym not in set(df.columns.get_level_values(0)):
            return None
        s = df[sym].dropna(subset=["Close"])
        return s if len(s) else None
    except Exception:  # noqa: BLE001
        return None


def global_moves() -> list[dict]:
    """Παγκόσμιες αγορές: τελευταία τιμή και μεταβολή από το προηγούμενο κλείσιμο."""
    syms = [g[0] for g in GLOBAL]
    df = _download(syms, period="7d", interval="1d")
    out = []
    for sym, name, grp, unit in GLOBAL:
        s = _sub(df, sym)
        if s is None or len(s) < 2:
            continue
        p, prev = _num(s["Close"].iloc[-1]), _num(s["Close"].iloc[-2])
        if p is None or not prev:
            continue
        ch = (p - prev) * 100 if unit == "bp" else (p / prev - 1) * 100
        out.append({"sym": sym, "name": name, "grp": grp, "p": round(p, 4 if p < 10 else 2),
                    "ch": round(ch, 1 if unit == "bp" else 2), "unit": unit, "d": s.index[-1].strftime("%Y-%m-%d")})
    return out


def premarket_moves(tickers: list[str], prev_close: dict[str, float]) -> list[dict]:
    """Τιμή πριν το άνοιγμα (pre-market, Yahoo, πιθανή καθυστέρηση) σε σχέση με το χθεσινό κλείσιμο."""
    tickers = [t for t in dict.fromkeys(tickers) if t and not t.startswith("^")][:80]
    if not tickers:
        return []
    df = _download(tickers, period="1d", interval="5m", prepost=True)
    out = []
    for t in tickers:
        s = _sub(df, t)
        pc = _num(prev_close.get(t))
        if s is None or not pc:
            continue
        p = _num(s["Close"].iloc[-1])
        if p is None:
            continue
        vol = _num(s["Volume"].sum()) if "Volume" in s else None
        out.append({"t": t, "p": round(p, 2), "gap": round((p / pc - 1) * 100, 2), "prev": round(pc, 2),
                    "vol": int(vol) if vol else None, "at": s.index[-1].isoformat()})
    return out


def day_moves(tickers: list[str], quotes: dict | None = None) -> dict[str, list]:
    """Μεταβολή ημέρας: από το quotes.json της εφαρμογής (αν υπάρχει) αλλιώς από ημερήσιες τιμές."""
    q = {}
    for t in tickers:
        v = (quotes or {}).get(t)
        if v and _num(v[0]) and _num(v[1]) is not None:
            q[t] = [round(float(v[0]), 2), round(float(v[1]), 2)]
    missing = [t for t in tickers if t not in q]
    if missing:
        df = _download(missing[:150], period="5d", interval="1d")
        for t in missing[:150]:
            s = _sub(df, t)
            if s is None or len(s) < 2:
                continue
            p, prev = _num(s["Close"].iloc[-1]), _num(s["Close"].iloc[-2])
            if p and prev:
                q[t] = [round(p, 2), round((p / prev - 1) * 100, 2)]
    return q


def _norm_title(t: str) -> str:
    return re.sub(r"[^a-z0-9 ]", "", (t or "").lower())[:90]


def fresh_news(tickers: list[str], hours: float = 18, per_ticker: int = 25) -> list[dict]:
    """Φρέσκες ειδήσεις χωρίς κλειδιά: Google News (αγορά), Yahoo (SPY/QQQ) και Yahoo RSS ανά μετοχή."""
    from ..data import rss, yahoo
    items: list[dict] = []
    try:
        items += rss.market_news(1)
    except Exception:  # noqa: BLE001
        log.exception("market news")
    for t in ("SPY", "QQQ"):
        try:
            for it in yahoo.news(t):
                it["ticker"] = None
                items.append(it)
        except Exception:  # noqa: BLE001
            pass
    for t in [x for x in tickers if x and not x.startswith("^")][:per_ticker]:
        try:
            items += rss.yahoo_rss(t, max_age_days=2)
        except Exception:  # noqa: BLE001
            pass
    cutoff = datetime.now(timezone.utc) - timedelta(hours=hours)
    seen, out = set(), []
    for it in items:
        try:
            at = datetime.fromisoformat(str(it.get("published_at")).replace("Z", "+00:00"))
            if at.tzinfo is None:
                at = at.replace(tzinfo=timezone.utc)
        except (TypeError, ValueError):
            continue
        k = _norm_title(it.get("title"))
        if at < cutoff or not k or k in seen:
            continue
        seen.add(k)
        out.append({"t": it.get("ticker"), "title": (it.get("title") or "")[:300], "source": it.get("source"),
                    "at": at.astimezone(timezone.utc).isoformat(timespec="minutes"), "url": it.get("url"),
                    "sum": re.sub(r"\s+", " ", it.get("summary") or "")[:280]})
    out.sort(key=lambda x: x["at"], reverse=True)
    return out[:60]


# ---------------------------------------------------------------------------------------------- εστίαση
def focus(snap: dict, limit: int = 30) -> list[dict]:
    """Οι μετοχές που βλέπει πρώτα ο χρήστης: day trade, ευκαιρίες, κορυφαίες προβλέψεις."""
    rows = {r.get("t"): r for r in snap.get("rows") or []}
    out, seen = [], set()

    def add(t, why, extra=None):
        if t and t not in seen and len(out) < limit:
            seen.add(t)
            r = rows.get(t) or {}
            out.append({"t": t, "name": r.get("n"), "sector": r.get("sec"), "close": r.get("p"), "why": why,
                        "rank5": r.get("q5") if r.get("q5") is not None else r.get("r5"),
                        "rank21": r.get("q21") if r.get("q21") is not None else r.get("r21"), **(extra or {})})
    day = snap.get("day") or {}
    for side, lbl in (("long", "Day trade (αγορά)"), ("short", "Day trade (short)")):
        for c in day.get(side) or []:
            add(c.get("ticker"), lbl, {"entry": [c.get("entryLow"), c.get("entryHigh")], "stop": c.get("stop"),
                                       "targets": [c.get("tp1"), c.get("tp2")]})
    for s in snap.get("signals") or []:
        add(s.get("ticker"), f"Ευκαιρία {s.get('horizon') or ''}".strip(),
            {"entry": [s.get("entryLow"), s.get("entryHigh")], "stop": s.get("stop"), "targets": [s.get("tp1"), s.get("tp2")]})
    ranked = [r for r in rows.values() if (r.get("q21") if r.get("q21") is not None else r.get("r21")) is not None]
    ranked.sort(key=lambda r: -(r.get("q21") if r.get("q21") is not None else r.get("r21")))
    for r in ranked[:10]:
        add(r.get("t"), "Ψηλά στην κατάταξη 1 μήνα")
    return out


def broad_movers(snap: dict, quotes: dict | None, n: int = 8) -> dict:
    """Μεγαλύτερες κινήσεις της ημέρας ανάμεσα σε ρευστές μετοχές + μέση κίνηση ανά κλάδο (από quotes.json)."""
    if not quotes:
        return {}
    rows = [r for r in snap.get("rows") or [] if (r.get("dv") or 0) >= 2e7 and r.get("t") in quotes]
    mv = [{"t": r["t"], "name": r.get("n"), "sector": r.get("sec"), "p": quotes[r["t"]][0], "ch": quotes[r["t"]][1]} for r in rows
          if _num(quotes[r["t"]][1]) is not None]
    mv.sort(key=lambda x: x["ch"])
    sec: dict[str, list] = {}
    for x in mv:
        if x.get("sector"):
            sec.setdefault(x["sector"], []).append(x["ch"])
    sectors = sorted(({"sector": k, "avg": round(sum(v) / len(v), 2), "n": len(v)} for k, v in sec.items() if len(v) >= 5),
                     key=lambda x: -x["avg"])
    adv = sum(1 for x in mv if x["ch"] > 0)
    return {"up": mv[::-1][:n], "down": mv[:n], "sectors": sectors, "breadth": {"up": adv, "down": len(mv) - adv, "n": len(mv)}}


# ---------------------------------------------------------------------------------------------- AI
def _clean_list(v, k=6, ln=260):
    return [str(x).strip()[:ln] for x in (v or []) if isinstance(x, (str, int, float)) and str(x).strip()][:k]


def write(slot: str, snap: dict, data: dict) -> dict | None:
    """Ένα κάλεσμα AI → {"headline","summary","points","watch","risk","tone","stocks"}."""
    if not manager.enabled():
        return None
    meta = SLOTS[slot]
    fx = {f["t"] for f in data.get("focus") or []}
    prompt = (meta["task"].format(open_gr=data.get("open_gr", "16:30")) + "\n\n"
              "Κανόνες: γράψε σαν άνθρωπος που ξέρει, συγκεκριμένα (ποιος δείκτης, πόσο %), όχι γενικολογίες. "
              "Ώρες γράφε σε ώρα Ελλάδας. Μην αλλάξεις ζώνες εισόδου/stop/στόχους και μην βάλεις νέους. "
              "rank* = θέση στην κατάταξη του μοντέλου (1.0 = κορυφή), όχι πιθανότητα. "
              "gap = % διαφορά τιμής πριν το άνοιγμα από το χθεσινό κλείσιμο. "
              "Αν μια ζώνη εισόδου έχει ήδη ξεπεραστεί από το gap, πες το καθαρά. "
              "Στο stocks γράψε μόνο για μετοχές της λίστας focus που έχουν κάτι αξιοσημείωτο (κίνηση, gap ή είδηση), έως 10.\n"
              'Μορφή JSON: {"headline":"μία πρόταση έως 100 χαρακτήρες","summary":"3-5 προτάσεις",'
              '"points":["3-6 βασικά σημεία, το καθένα με αριθμό από τα δεδομένα"],'
              '"watch":["2-5 πράγματα να προσέξει σήμερα/αύριο"],"risk":"ο μεγαλύτερος κίνδυνος τώρα, 1-2 προτάσεις",'
              '"tone":"θετικό|ουδέτερο|αρνητικό","stocks":[{"ticker":"...","text":"1-2 προτάσεις"}]}\n\n'
              "ΔΕΔΟΜΕΝΑ:\n" + json.dumps(data, ensure_ascii=False, default=str))
    res = manager.complete_json(f"brief_{slot}", SYS, prompt, 6000)
    if not isinstance(res, dict) or not str(res.get("summary") or "").strip():
        return None
    stocks = {}
    for it in res.get("stocks") or []:
        if isinstance(it, dict):
            t, txt = str(it.get("ticker") or "").upper().strip(), str(it.get("text") or "").strip()
            if t in fx and txt:
                stocks[t] = txt[:600]
    tone = str(res.get("tone") or "").strip()
    return {"headline": str(res.get("headline") or "").strip()[:160], "summary": str(res.get("summary") or "").strip()[:1600],
            "points": _clean_list(res.get("points")), "watch": _clean_list(res.get("watch"), 5),
            "risk": str(res.get("risk") or "").strip()[:500], "tone": tone if tone in ("θετικό", "ουδέτερο", "αρνητικό") else None,
            "stocks": stocks}


def build(slot: str, snap: dict, quotes: dict | None = None, news_hours: float | None = None) -> dict:
    """Συλλέγει τα δεδομένα της ενημέρωσης και (αν υπάρχει κλειδί) γράφει το κείμενο AI."""
    d = now_ny()
    fc = focus(snap)
    tick = [f["t"] for f in fc]
    rows = {r.get("t"): r for r in snap.get("rows") or []}
    moves = []
    try:
        moves = global_moves()
    except Exception:  # noqa: BLE001
        log.exception("global moves")
    gaps, day, movers = [], {}, {}
    if slot in ("morning", "premarket"):
        try:
            gaps = premarket_moves(tick + ["SPY", "QQQ"], {t: (rows.get(t) or {}).get("p") for t in tick} |
                                   {k: (v or {}).get("p") for k, v in (snap.get("idx") or {}).items()})
        except Exception:  # noqa: BLE001
            log.exception("premarket")
    if slot == "evening":
        try:
            day = day_moves(tick + ["SPY", "QQQ", "DIA", "IWM", "^VIX"], quotes)
            movers = broad_movers(snap, quotes)
        except Exception:  # noqa: BLE001
            log.exception("day moves")
    hours = news_hours or {"morning": 16, "premarket": 10, "evening": 9, "night": 14}[slot]
    news = []
    try:
        news = fresh_news(tick, hours)
    except Exception:  # noqa: BLE001
        log.exception("news")
    mk = snap.get("market") or {}
    gmap = {g["t"]: g for g in gaps}
    focus_ai = []
    for f in fc:
        x = dict(f)
        if f["t"] in gmap:
            x["premarket"] = {k: gmap[f["t"]][k] for k in ("p", "gap", "vol")}
        if f["t"] in day:
            x["today"] = {"price": day[f["t"]][0], "change_pct": day[f["t"]][1]}
        x["news"] = [n["title"] for n in news if n.get("t") == f["t"]][:3]
        focus_ai.append({k: v for k, v in x.items() if v not in (None, [], {}, [None, None])})
    data = {"now_athens": d.astimezone(__import__("zoneinfo").ZoneInfo("Europe/Athens")).strftime("%A %d/%m %H:%M"),
            "now_new_york": d.strftime("%A %d/%m %H:%M"), "open_gr": open_time_gr(d),
            "last_full_analysis_close": snap.get("asOf"),
            "system_market_view": {k: mk.get(k) for k in ("score", "label", "simple", "regime") if k in mk},
            "indices_last_close": {k: {"price": v.get("p"), "change_pct": v.get("ch")} for k, v in (snap.get("idx") or {}).items()},
            "global_markets_now": [{k: m[k] for k in ("name", "p", "ch", "unit", "d")} for m in moves],
            "sectors_1m_vs_sp500": [{"sector": s.get("sector"), "rel_1m_pct": s.get("rel21")} for s in (snap.get("sectors") or [])[:11]],
            "focus": focus_ai,
            "fresh_news": [{"time_utc": n["at"][11:16], "date": n["at"][:10], "ticker": n.get("t"), "title": n["title"],
                            "source": n.get("source"), "summary": n.get("sum")} for n in news[:35]]}
    if slot == "evening":
        data["today_close"] = {"indices": {t: {"price": v[0], "change_pct": v[1]} for t, v in day.items() if t in ("SPY", "QQQ", "DIA", "IWM", "^VIX")},
                               "biggest_movers": {k: movers.get(k) for k in ("up", "down")}, "sectors_today": movers.get("sectors"),
                               "breadth": movers.get("breadth")}
    if slot in ("morning", "premarket"):
        data["premarket_index_etfs"] = [g for g in gaps if g["t"] in ("SPY", "QQQ")]
    text = None
    try:
        text = write(slot, snap, data)
    except Exception:  # noqa: BLE001
        log.exception("brief AI")
    meta = SLOTS[slot]
    out = {"slot": slot, "label": meta["label"], "short": meta["short"], "at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
           "nyDate": d.strftime("%Y-%m-%d"), "openGr": data["open_gr"], "ai": bool(text),
           "model": manager.model_for(manager.available()[0]) if text and manager.available() else None,
           "moves": moves, "gaps": sorted(gaps, key=lambda g: -abs(g["gap"]))[:20],
           "day": {t: v for t, v in day.items()}, "movers": movers,
           "news": [{k: n.get(k) for k in ("t", "title", "source", "at", "url")} for n in news[:30]]}
    if text:
        out.update(text)
    return out


def merge(prev: dict | None, brief: dict) -> dict:
    """Βάζει τη νέα ενημέρωση στο ai.json χωρίς να χαθούν οι βραδινές σημειώσεις ανά μετοχή και το ιστορικό."""
    out = dict(prev or {})
    hist = list(out.get("history") or [])
    old = out.get("brief")
    if old and old.get("summary"):
        hist.insert(0, {k: old.get(k) for k in ("slot", "label", "short", "at", "nyDate", "headline", "summary", "tone")})
    seen, h2 = set(), []
    for h in hist:
        k = (h.get("slot"), h.get("nyDate"))
        if k in seen or (h.get("slot") == brief["slot"] and h.get("nyDate") == brief["nyDate"]):
            continue
        seen.add(k)
        h2.append(h)
    out["brief"] = brief
    out["history"] = h2[:10]
    out.setdefault("stocks", {})
    return out


def already_done(prev: dict | None, slot: str, ny_date: str) -> bool:
    b = (prev or {}).get("brief") or {}
    return b.get("slot") == slot and b.get("nyDate") == ny_date and bool(b.get("ai"))
