"""Έτοιμες σημειώσεις AI για την εφαρμογή (κινητό και υπολογιστής): σύνοψη αγοράς και 2-3 προτάσεις για τις
μετοχές που βλέπει πρώτα ο χρήστης (day trade, ευκαιρίες, κορυφαίες προβλέψεις).

Το κλειδί του AI ΔΕΝ μπαίνει ποτέ σε αρχείο: στο cloud έρχεται από κρυφό GitHub secret (GEMINI_API_KEY) και στον
υπολογιστή από το .env. Αν δεν υπάρχει κλειδί, δεν γίνεται τίποτα και η εφαρμογή δουλεύει όπως πριν.
Το AI παίρνει ΜΟΝΟ τα δεδομένα του συστήματος· οι αριθμοί έρχονται από τον κώδικα, όχι από το AI."""
from __future__ import annotations

import json
import logging

from .. import db
from . import manager

log = logging.getLogger("usalpha.ai.notes")

SYS = ("Είσαι έμπειρος, έντιμος αναλυτής αμερικανικών μετοχών και γράφεις για απλό επενδυτή στα ελληνικά. "
       "Απλά λόγια, χωρίς ορολογία όπου γίνεται. Χρησιμοποιείς ΜΟΝΟ τα δεδομένα που σου δίνονται· δεν επινοείς "
       "αριθμούς, ειδήσεις ή γεγονότα. Αναφέρεις πάντα έναν κίνδυνο. Δεν δίνεις εγγυήσεις και δεν λες «σίγουρα». "
       "Δεν είναι επενδυτική συμβουλή.")


def _stock_ctx(t: str, snap: dict, why: str, extra: dict | None = None) -> dict:
    row = next((x for x in snap.get("rows") or [] if x.get("t") == t), {}) or {}
    news = [{"date": (n.get("at") or "")[:10], "title": n.get("title"), "source": n.get("source")}
            for n in snap.get("news") or [] if n.get("t") == t][:3]
    return {"ticker": t, "name": row.get("n"), "sector": row.get("sec"), "price": row.get("p"), "change_pct": row.get("ch"),
            "score_0_100": row.get("s"), "bias": row.get("b"), "ret_1m_pct": row.get("m1"), "ret_3m_pct": row.get("m3"),
            "rsi": row.get("rsi"), "rank_5d_pct": row.get("q5") if row.get("q5") is not None else row.get("r5"),
            "rank_21d_pct": row.get("q21") if row.get("q21") is not None else row.get("r21"), "why_listed": why,
            "news": news, **(extra or {})}


def _picks(snap: dict, limit: int) -> list[dict]:
    out, seen = [], set()

    def add(t, why, extra=None):
        if t and t not in seen and len(out) < limit:
            seen.add(t)
            out.append(_stock_ctx(t, snap, why, extra))
    day = snap.get("day") or {}
    for side, lbl in (("long", "Day trade για αγορά"), ("short", "Day trade για short")):
        for c in day.get(side) or []:
            add(c.get("ticker"), lbl, {"entry_zone": [c.get("entryLow"), c.get("entryHigh")], "stop": c.get("stop"),
                                       "targets": [c.get("tp1"), c.get("tp2")], "reasons": (c.get("reasons") or [])[:5]})
    for s in snap.get("signals") or []:
        add(s.get("ticker"), f"Ευκαιρία ({s.get('horizon')}, {s.get('setup') or ''})",
            {"entry_zone": [s.get("entryLow"), s.get("entryHigh")], "stop": s.get("stop"), "targets": [s.get("tp1"), s.get("tp2")],
             "conflicts": (s.get("conflicts") or [])[:3], "risks": (s.get("risks") or [])[:3]})
    rows = [x for x in snap.get("rows") or [] if (x.get("q21") or x.get("r21")) is not None]
    rows.sort(key=lambda x: -(x.get("q21") if x.get("q21") is not None else x.get("r21") or 0))
    for x in rows[:15]:
        add(x.get("t"), "Από τις ψηλότερες στην κατάταξη 1 μήνα του μοντέλου")
    return out


def build(snap: dict, limit: int = 45, prev: dict | None = None) -> dict | None:
    """Επιστρέφει {"at", "model", "market", "stocks": {ticker: κείμενο}} ή None αν δεν υπάρχει AI.
    Κρατά τις ενημερώσεις της ημέρας (brief/history) από το προηγούμενο ai.json (prev) ή από τη βάση."""
    if not manager.enabled():
        return None
    prov = manager.available()[0]
    out = {"at": db.now_iso(), "model": manager.model_for(prov), "market": None, "stocks": {}}
    mk = snap.get("market") or {}
    idx = snap.get("idx") or {}
    market_data = {"date": snap.get("asOf"), "market": {k: mk.get(k) for k in ("score", "label", "simple") if k in mk},
                   "indices": {k: {"price": v.get("p"), "change_pct": v.get("ch")} for k, v in idx.items()},
                   "sectors_1m_vs_sp500": [{"sector": s.get("sector"), "rel_1m_pct": s.get("rel21"), "day_pct": s.get("ret1")}
                                           for s in (snap.get("sectors") or [])[:11]],
                   "news": [{"date": (n.get("at") or "")[:10], "ticker": n.get("t"), "title": n.get("title"), "source": n.get("source")}
                            for n in (snap.get("news") or [])[:12]],
                   "day_trade_count": len((snap.get("day") or {}).get("long") or []) + len((snap.get("day") or {}).get("short") or []),
                   "opportunities": len(snap.get("signals") or [])}
    try:
        out["market"] = manager.complete(
            "app_market", SYS,
            "Γράψε σύνοψη της αμερικανικής αγοράς σε 4-6 σύντομες προτάσεις: πώς έκλεισε, ποιοι κλάδοι ξεχώρισαν, "
            "οι πιο σημαντικές ειδήσεις (με την ημερομηνία τους) και τι να προσέξει αύριο κάποιος που κάνει trading. "
            "Μόνο από τα δεδομένα.\n\nΔΕΔΟΜΕΝΑ:\n" + json.dumps(market_data, ensure_ascii=False, default=str), 600)
    except Exception:  # noqa: BLE001
        log.exception("AI market note")
    picks = _picks(snap, limit)
    for i in range(0, len(picks), 8):
        batch = picks[i:i + 8]
        prompt = ("Για κάθε μετοχή γράψε 2-3 σύντομες προτάσεις στα ελληνικά: γιατί είναι στη λίστα, τι δείχνουν τα "
                  "στοιχεία και έναν κίνδυνο που πρέπει να προσέξει. Αν υπάρχουν είσοδος/stop/στόχοι, μην τους αλλάξεις "
                  "και μην προσθέσεις νέους αριθμούς. rank_*_pct = θέση στην κατάταξη του μοντέλου (1.0 = κορυφή), όχι πιθανότητα.\n"
                  'Μορφή: {"items":[{"ticker":"...","text":"..."}]}\n\nΔΕΔΟΜΕΝΑ:\n' + json.dumps(batch, ensure_ascii=False, default=str))
        try:
            res = manager.complete_json("app_stocks", SYS, prompt, 1800)
        except Exception:  # noqa: BLE001
            log.exception("AI stock notes")
            res = None
        for it in (res or {}).get("items", []) if isinstance(res, dict) else []:
            t, txt = str(it.get("ticker") or "").upper(), str(it.get("text") or "").strip()
            if t and txt and any(p["ticker"] == t for p in batch):
                out["stocks"][t] = txt[:900]
    if not out["market"] and not out["stocks"]:
        return None
    if prev is None:
        prev = db.kv_get("ai_notes") or {}
    for k in ("brief", "history"):
        if (prev or {}).get(k):
            out[k] = prev[k]
    db.kv_set("ai_notes", out)
    return out
