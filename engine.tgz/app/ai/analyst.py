"""Χρήσεις του AI. Κανόνας: το AI παίρνει ΜΟΝΟ τα δεδομένα που του δίνουμε και του
απαγορεύεται να επινοεί αριθμούς. Οι αριθμοί/βαθμολογίες έρχονται πάντα από τον κώδικα."""
from __future__ import annotations

import json

from .. import db
from . import manager

SYS_ANALYST = (
    "Είσαι αυστηρός, έντιμος χρηματοοικονομικός αναλυτής για αμερικανικές μετοχές. Γράφεις στα ελληνικά, "
    "απλά και καθαρά. Χρησιμοποιείς ΜΟΝΟ τα δεδομένα που σου δίνονται· ΔΕΝ επινοείς αριθμούς, τιμές, "
    "ειδήσεις ή πιθανότητες. Αν τα δεδομένα δεν αρκούν, το λες. Αναφέρεις πάντα και τα στοιχεία που "
    "αντιτίθενται στο συμπέρασμα. Δεν δίνεις εγγυήσεις και δεν παρουσιάζεις βαθμολογίες ως πιθανότητες."
)


def enrich_news(limit: int = 30) -> int:
    if not manager.enabled():
        return 0
    rows = db.q("SELECT id, ticker, title, summary, source, published_at FROM news WHERE ai_json IS NULL "
                "AND is_primary=1 ORDER BY published_at DESC LIMIT ?", (limit,))
    if not rows:
        return 0
    done = 0
    for i in range(0, len(rows), 10):
        batch = rows[i:i + 10]
        items = [{"id": r["id"], "ticker": r["ticker"], "title": r["title"], "summary": (r["summary"] or "")[:400],
                  "source": r["source"], "date": r["published_at"][:10]} for r in batch]
        prompt = ("Αξιολόγησε κάθε είδηση για την επίδρασή της στη μετοχή (ή στην αγορά αν ticker=null).\n"
                  "Για κάθε id δώσε: sentiment (-1 έως 1), importance (0 έως 1), horizon ('ημέρες'|'εβδομάδες'|'μήνες'), "
                  "category, summary_el (1 πρόταση στα ελληνικά), why (σύντομη αιτιολόγηση).\n"
                  'Μορφή: {"items":[{"id":...,"sentiment":...,"importance":...,"horizon":...,"category":...,'
                  '"summary_el":...,"why":...}]}\n\n' + json.dumps(items, ensure_ascii=False))
        res = manager.complete_json("news", SYS_ANALYST, prompt, 1800)
        for it in (res or {}).get("items", []) if isinstance(res, dict) else []:
            try:
                s = max(-1.0, min(1.0, float(it.get("sentiment", 0))))
                imp = max(0.0, min(1.0, float(it.get("importance", 0.5))))
            except (TypeError, ValueError):
                continue
            it["sentiment"], it["importance"] = s, imp
            db.execute("UPDATE news SET ai_json=? WHERE id=?", (json.dumps(it, ensure_ascii=False), it.get("id")))
            done += 1
    return done


def explain_stock(bundle: dict) -> str | None:
    if not manager.enabled() or not bundle.get("ok"):
        return None
    sc = bundle["scored"]
    data = {
        "ticker": bundle["ticker"], "name": bundle.get("name"), "sector": bundle.get("sector"),
        "quote": {k: (bundle.get("quote") or {}).get(k) for k in ("price", "change_pct", "quality")},
        "score": sc["score"], "components": sc["components"], "bias": sc["bias"],
        "confirmation": {k: sc["confirmation"][k] for k in ("supporting", "opposing", "conflicts")},
        "technical": {"flags": bundle["tech"].get("flags"), "metrics": {k: v for k, v in bundle["tech"].get("metrics", {}).items() if k != "rs"}},
        "fundamentals": bundle["fund"].get("metrics"), "risk_warnings": bundle["risk"]["warnings"],
        "news": [{"date": n["published_at"][:10], "title": n["title"], "source": n["source"], "sentiment": n["sentiment"],
                  "priced_in": n.get("priced_in")} for n in bundle["news"].get("top", [])[:6]],
        "setups": bundle.get("setups"),
        "calibrated_probability": sc.get("probability"),
    }
    prompt = ("Γράψε ανάλυση 180-260 λέξεων για αυτή τη μετοχή με ενότητες: «Εικόνα», «Γιατί», «Τι αντιτίθεται», "
              "«Κίνδυνοι», «Τι θα άλλαζε την εικόνα». Αν calibrated_probability είναι null, γράψε ρητά ότι δεν υπάρχει "
              "βαθμονομημένη πιθανότητα.\n\nΔΕΔΟΜΕΝΑ:\n" + json.dumps(data, ensure_ascii=False, default=str))
    return manager.complete("explain", SYS_ANALYST, prompt, 900)


def market_summary(ctx: dict, movers: dict, news: list[dict], changes: dict | None = None) -> str | None:
    if not manager.enabled():
        return None
    prompt = ("Γράψε σύνοψη αγοράς ΗΠΑ 150-220 λέξεων στα ελληνικά: γενική εικόνα, κλάδοι, ξεχωριστές κινήσεις, "
              "βασικές ειδήσεις (με ημερομηνία), τι να προσέξει ο trader. Μόνο από τα δεδομένα.\n\n"
              + json.dumps({"market": ctx, "movers": movers, "news": news[:12], "changes_vs_yesterday": changes},
                           ensure_ascii=False, default=str))
    return manager.complete("market_summary", SYS_ANALYST, prompt, 700)
