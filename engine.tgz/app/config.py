"""Κεντρικές ρυθμίσεις. Όλα τα μυστικά (API keys) διαβάζονται ΜΟΝΟ από το .env
στον server και δεν στέλνονται ποτέ στον browser."""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
ENV_PATH = ROOT / ".env"
CONFIG_DIR = ROOT / "config"
DATA_DIR = ROOT / "data"
DATA_DIR.mkdir(exist_ok=True)

load_dotenv(ENV_PATH, override=True)


def _f(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, default))
    except ValueError:
        return default


def _i(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, default))
    except ValueError:
        return default


# Το "ml" (μοντέλο πρόβλεψης) μετράει ΜΟΝΟ όταν έχει επικυρωθεί out-of-sample· αλλιώς εξαιρείται
# αυτόματα και τα υπόλοιπα βάρη επανακανονικοποιούνται.
DEFAULT_WEIGHTS = {
    "ml": 0.30,
    "technical": 0.15,
    "fundamentals": 0.12,
    "news": 0.13,
    "momentum_volume": 0.10,
    "sector": 0.07,
    "market": 0.05,
    "risk": 0.08,
}

SECRET_KEYS = [
    "ANTHROPIC_API_KEY",
    "OPENAI_API_KEY",
    "GEMINI_API_KEY",
    "FINNHUB_API_KEY",
    "POLYGON_API_KEY",
]


@dataclass
class Settings:
    db_path: Path = Path(os.getenv("USALPHA_DB", str(DATA_DIR / "usalpha.db")))
    host: str = os.getenv("HOST", "127.0.0.1")
    port: int = _i("PORT", 8800)

    # Δεδομένα
    sec_user_agent: str = os.getenv("SEC_USER_AGENT", "USAlpha research contact@example.com")
    quote_refresh_sec: int = _i("QUOTE_REFRESH_SEC", 60)
    news_refresh_min: int = _i("NEWS_REFRESH_MIN", 10)
    history_years: int = _i("HISTORY_YEARS", 10)
    stale_quote_min: int = _i("STALE_QUOTE_MIN", 20)

    # Σύμπαν: ΟΛΕΣ οι μετοχές NASDAQ/NYSE/AMEX που περνούν το φίλτρο ρευστότητας
    min_price: float = _f("MIN_PRICE", 1.0)
    universe_min_dollar_vol: float = _f("UNIVERSE_MIN_DOLLAR_VOL", 1_000_000)
    max_universe: int = _i("MAX_UNIVERSE", 5000)
    universe_refresh_days: int = _i("UNIVERSE_REFRESH_DAYS", 7)
    deep_n: int = _i("DEEP_N", 200)            # πόσες κορυφαίες παίρνουν πλήρη εταιρική ανάλυση
    bt_max_tickers: int = _i("BT_MAX_TICKERS", 300)

    # Μοντέλο πρόβλεψης (ML)
    ml_max_tickers: int = _i("ML_MAX_TICKERS", 3000)
    ml_retrain_days: int = _i("ML_RETRAIN_DAYS", 7)
    max_active_per_horizon: int = _i("MAX_ACTIVE_PER_HORIZON", 10)  # μόνο οι καλύτερες ευκαιρίες, όχι εκατοντάδες
    # ελάχιστο ιστορικό (out-of-sample) αναμενόμενο κέρδος σε μονάδες ρίσκου για να προταθεί είσοδος (0.08 = +8% του ρίσκου)
    ml_min_exp_r: float = _f("ML_MIN_EXP_R", 0.08)

    # Risk
    account_size: float = _f("ACCOUNT_SIZE", 10000)
    risk_per_trade_pct: float = _f("RISK_PER_TRADE_PCT", 1.0)
    max_position_pct: float = _f("MAX_POSITION_PCT", 20)
    max_sector_pct: float = _f("MAX_SECTOR_PCT", 40)
    min_rr: float = _f("MIN_RR", 1.8)
    min_dollar_volume: float = _f("MIN_DOLLAR_VOLUME", 5_000_000)
    max_spread_pct: float = _f("MAX_SPREAD_PCT", 0.6)

    # Backtest κόστη
    commission_per_trade: float = _f("COMMISSION_PER_TRADE", 0.0)
    slippage_bps: float = _f("SLIPPAGE_BPS", 10)

    # AI
    ai_provider: str = os.getenv("AI_PROVIDER", "anthropic")
    ai_model: str = os.getenv("AI_MODEL", "")
    ai_monthly_budget_usd: float = _f("AI_MONTHLY_BUDGET_USD", 10)
    ai_max_calls_per_min: int = _i("AI_MAX_CALLS_PER_MIN", 20)

    weights: dict = field(default_factory=dict)

    def secret(self, name: str) -> str:
        return os.getenv(name, "").strip()

    def has(self, name: str) -> bool:
        return bool(self.secret(name))


WEIGHTS_PATH = CONFIG_DIR / "weights.json"


def load_weights() -> dict:
    if WEIGHTS_PATH.exists():
        try:
            w = json.loads(WEIGHTS_PATH.read_text(encoding="utf-8"))
            merged = {**DEFAULT_WEIGHTS, **{k: float(v) for k, v in w.items() if k in DEFAULT_WEIGHTS}}
            return normalize_weights(merged)
        except Exception:
            pass
    return dict(DEFAULT_WEIGHTS)


def normalize_weights(w: dict) -> dict:
    s = sum(max(0.0, v) for v in w.values()) or 1.0
    return {k: round(max(0.0, v) / s, 4) for k, v in w.items()}


def save_weights(w: dict) -> dict:
    w = normalize_weights({k: float(w.get(k, 0)) for k in DEFAULT_WEIGHTS})
    CONFIG_DIR.mkdir(exist_ok=True)
    WEIGHTS_PATH.write_text(json.dumps(w, indent=2), encoding="utf-8")
    settings.weights = w
    return w


def set_env_value(key: str, value: str) -> None:
    """Γράφει/ενημερώνει μια τιμή στο τοπικό .env (μόνο server-side)."""
    lines = ENV_PATH.read_text(encoding="utf-8").splitlines() if ENV_PATH.exists() else []
    out, found = [], False
    for ln in lines:
        if ln.split("=", 1)[0].strip() == key:
            out.append(f"{key}={value}")
            found = True
        else:
            out.append(ln)
    if not found:
        out.append(f"{key}={value}")
    ENV_PATH.write_text("\n".join(out) + "\n", encoding="utf-8")
    os.environ[key] = value


def mask(v: str) -> str:
    if not v:
        return ""
    return v[:4] + "…" + v[-3:] if len(v) > 10 else "••••"


settings = Settings()
settings._no_scheduler = os.getenv("USALPHA_NO_SCHEDULER") == "1"
settings.weights = load_weights()
