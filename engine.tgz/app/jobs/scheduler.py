"""Background jobs (APScheduler, ώρα Νέας Υόρκης):
- quotes: κάθε QUOTE_REFRESH_SEC όσο η αγορά είναι ανοιχτή (pre/regular/post)
- news: κάθε NEWS_REFRESH_MIN
- επανέλεγχοι signals (3 χρονικοί έλεγχοι): 10:15, 12:45, 15:30 ET
- πλήρες scan + ημερήσιο report: 16:40 ET (και 08:30 ET premarket ενημέρωση)
Κάθε job έχει κλείδωμα ώστε να μην τρέχει δύο φορές ταυτόχρονα."""
from __future__ import annotations

import logging
import threading
import time
from datetime import datetime, timezone

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from apscheduler.triggers.interval import IntervalTrigger

from .. import db
from ..ai import analyst
from ..analysis import news as newsmod
from ..config import settings
from ..data import finnhub, service, yahoo
from ..data.session import NY, session
from ..data.universe import MARKET_SYMBOLS
from ..engine import alerts, pipeline, scanner, signals
from ..paper import service as paper
from ..report import daily

log = logging.getLogger("usalpha.jobs")
_sched: BackgroundScheduler | None = None
_locks: dict[str, threading.Lock] = {}
job_status: dict[str, dict] = {}


def _guard(name: str):
    def deco(fn):
        def wrap(*a, **kw):
            lk = _locks.setdefault(name, threading.Lock())
            if not lk.acquire(blocking=False):
                return None
            t0 = time.time()
            try:
                r = fn(*a, **kw)
                job_status[name] = {"last_ok": db.now_iso(), "seconds": round(time.time() - t0, 1), "error": None}
                return r
            except Exception as e:  # noqa: BLE001
                log.exception("job %s failed", name)
                job_status[name] = {"last_error_at": db.now_iso(), "error": repr(e)[:300]}
            finally:
                lk.release()
        wrap.__name__ = fn.__name__
        return wrap
    return deco


def live_tickers() -> list[str]:
    s = set(service.watchlist())
    s |= {r["ticker"] for r in db.q("SELECT DISTINCT ticker FROM signals WHERE status IN ('new','active','tp1','tp2')")}
    s |= {r["ticker"] for r in db.q("SELECT DISTINCT ticker FROM paper_trades WHERE status='open'")}
    s |= {r["ticker"] for r in scanner.latest_results()[:40]}
    s |= {"SPY", "QQQ", "DIA", "IWM", "^VIX"}
    return sorted(s)


@_guard("quotes")
def job_quotes(force: bool = False) -> dict:
    sess = session()
    if sess == "closed" and not force:
        return {"skipped": "market closed"}
    tick = live_tickers()
    n = service.refresh_quotes(tick)
    quotes = service.all_quotes()
    signals.update_lifecycle(quotes)
    paper.check_stops(quotes)
    wl = set(service.watchlist()) | {r["ticker"] for r in db.q("SELECT ticker FROM signals WHERE status IN ('new','active','tp1','tp2')")}
    day = datetime.now(NY).date().isoformat()
    for t in wl:
        q = quotes.get(t)
        if q and q.get("change_pct") is not None and abs(q["change_pct"]) >= 5:
            bucket = int(abs(q["change_pct"]) // 5) * 5
            alerts.add("move", f"{t}: μεταβολή {q['change_pct']:+.1f}% ({q['quality']})", t,
                       "high" if bucket >= 10 else "medium", f"move:{t}:{day}:{bucket}:{q['change_pct'] > 0}")
    alerts.broadcast("quotes", {"updated_at": db.now_iso(), "n": n, "session": sess})
    return {"updated": n}


@_guard("news")
def job_news() -> dict:
    from ..data import rss
    tick = live_tickers()
    tick = [t for t in tick if not t.startswith("^")][:60]
    priority = set(service.watchlist()) | {r["ticker"] for r in db.q(
        "SELECT DISTINCT ticker FROM signals WHERE status IN ('new','active','tp1','tp2')")}
    items, counts = [], {"yahoo": 0, "yahoo_rss": 0, "google_news": 0, "finnhub": 0}

    def add(src, lst):
        items.extend(lst)
        counts[src] += len(lst)

    for i, t in enumerate(tick):
        try:
            add("yahoo", yahoo.news(t))
        except Exception:  # noqa: BLE001
            pass
        add("yahoo_rss", rss.yahoo_rss(t))
        if t in priority or i < 25:
            name = (db.q1("SELECT name FROM universe WHERE ticker=?", (t,)) or {}).get("name")
            add("google_news", rss.google_news(t, name))
        if finnhub.enabled():
            try:
                add("finnhub", finnhub.company_news(t, days=3))
            except Exception:  # noqa: BLE001
                pass
    if finnhub.enabled():
        try:
            add("finnhub", finnhub.market_news())
        except Exception:  # noqa: BLE001
            pass
    for t in ("SPY", "QQQ"):
        for it in yahoo.news(t):
            it["ticker"] = None  # ειδήσεις αγοράς
            items.append(it)
    add("google_news", rss.market_news())
    db.kv_set("news_sources", {**counts, "at": db.now_iso()})
    added = newsmod.ingest(items)
    enriched = analyst.enrich_news(40)
    # breaking news για watchlist / ενεργά signals
    since = datetime.now(timezone.utc).timestamp() - 3 * 3600
    wl = set(service.watchlist()) | {r["ticker"] for r in db.q("SELECT ticker FROM signals WHERE status IN ('new','active','tp1','tp2')")}
    for n in db.q("SELECT * FROM news WHERE is_primary=1 AND ABS(impact)>=0.35 ORDER BY published_at DESC LIMIT 50"):
        if n["ticker"] in wl and datetime.fromisoformat(n["published_at"]).timestamp() >= since:
            alerts.add("news", f"{n['ticker']}: {n['title'][:140]} ({n['source']}, {n['published_at'][:16]})",
                       n["ticker"], "high" if abs(n["impact"]) >= 0.5 else "medium", f"news:{n['cluster_id']}")
    alerts.broadcast("news", {"added": added})
    return {"added": added, "ai_enriched": enriched}


@_guard("recheck")
def job_recheck() -> dict:
    active = db.q("SELECT DISTINCT ticker FROM signals WHERE status IN ('new','active','tp1','tp2')")
    if not active:
        return {"n": 0}
    service.refresh_quotes([r["ticker"] for r in active])
    ctx_d = db.kv_get("last_context", {}) or {}
    ctx = pipeline.Context.build(ctx_d.get("breadth"))
    bundles = {r["ticker"]: pipeline.analyze_ticker(r["ticker"], ctx, live=True) for r in active}
    signals.recheck(bundles)
    return {"n": len(bundles)}


@_guard("scan")
def job_scan_and_report() -> dict:
    from ..ml import model as mlmodel
    r = scanner.run_scan(update_data=True, fetch_companies=True)
    age = mlmodel.model_age_days()
    trained = None
    from ..ml import features as MLF
    stale_features = bool(db.q1("SELECT 1 FROM ml_models")) and any(mlmodel.load(h) is None for h in MLF.HORIZONS)
    if r.get("status") == "ok" and (age is None or age >= settings.ml_retrain_days or stale_features):
        # επίσημα δεδομένα SEC (κλάδοι, ημερομηνίες αποτελεσμάτων, οικονομικά) πριν την εκπαίδευση
        try:
            from ..data import secdata
            from ..data.listings import universe_tickers
            secdata.sync_all(universe_tickers(settings.ml_max_tickers))
        except Exception:  # noqa: BLE001
            log.exception("SEC sync failed")
        # (επαν)εκπαίδευση του μοντέλου πρόβλεψης με τα νέα δεδομένα και νέο scoring με αυτό
        trained = mlmodel.train_all()
        if trained.get("status") == "ok":
            scanner.run_scan(update_data=False, fetch_companies=False)
            ok_h = [h for h, v in trained["results"].items() if v["validated"]]
            alerts.add("ml", "Το μοντέλο πρόβλεψης εκπαιδεύτηκε. Επικυρωμένοι ορίζοντες: "
                       + (", ".join(ok_h) if ok_h else "κανένας (δεν αποδείχθηκε πλεονέκτημα — δεν χρησιμοποιείται)"),
                       None, "info", f"ml:{db.now_iso()[:13]}")
    rep = daily.build()
    alerts.add("report", f"Νέο Market Intelligence Report {rep['date']}", None, "info", f"report:{rep['date']}")
    return {"scan": r.get("status"), "report": rep["date"], "ml": (trained or {}).get("status")}


@_guard("ml_train")
def job_ml_train() -> dict:
    """SEC δεδομένα → πλήρες ιστορικό (backfill έως HISTORY_YEARS) → εκπαίδευση → νέο scoring."""
    from ..data.listings import universe_tickers
    from ..ml import model as mlmodel
    tickers = universe_tickers(settings.ml_max_tickers)
    try:
        from ..data import secdata
        secdata.sync_all(tickers)
    except Exception:  # noqa: BLE001
        log.exception("SEC sync failed")
    try:
        from ..data.universe import etf_universe
        mlmodel._progress.update(running=True, step=f"Ιστορικό {settings.history_years} ετών για όλη την αγορά", pct=0,
                                 started_at=db.now_iso(), error=None)

        def cb(i, n):
            mlmodel._progress.update(step=f"Ιστορικό {settings.history_years} ετών: {i}/{n} μετοχές", pct=round(i / max(n, 1) * 100, 1))
        h = service.update_history(list(dict.fromkeys(tickers + etf_universe() + list(MARKET_SYMBOLS))), progress_cb=cb)
        log.info("history before training: %s", {k: (len(v) if isinstance(v, list) else v) for k, v in h.items()})
    except Exception:  # noqa: BLE001
        log.exception("history backfill before training failed")
    finally:
        mlmodel._progress.update(running=False)
    r = mlmodel.train_all()
    if r.get("status") == "ok":
        scanner.run_scan(update_data=False, fetch_companies=False)
        ok_h = [k for k, v in r["results"].items() if v["validated"]]
        alerts.add("ml", "Το μοντέλο πρόβλεψης εκπαιδεύτηκε. Επικυρωμένοι ορίζοντες: "
                   + (", ".join(ok_h) if ok_h else "κανένας (δεν αποδείχθηκε πλεονέκτημα — δεν χρησιμοποιείται)"),
                   None, "info", f"ml:{db.now_iso()[:13]}")
    return r


@_guard("premarket")
def job_premarket() -> dict:
    service.update_history(list(MARKET_SYMBOLS))
    return job_quotes(force=True) or {}


def start() -> None:
    global _sched
    if _sched:
        return
    _sched = BackgroundScheduler(timezone=NY, job_defaults={"coalesce": True, "max_instances": 1, "misfire_grace_time": 300})
    _sched.add_job(job_quotes, IntervalTrigger(seconds=max(30, settings.quote_refresh_sec), timezone=NY), id="quotes")
    _sched.add_job(job_news, IntervalTrigger(minutes=max(5, settings.news_refresh_min), timezone=NY), id="news")
    for h, m in ((10, 15), (12, 45), (15, 30)):
        _sched.add_job(job_recheck, CronTrigger(day_of_week="mon-fri", hour=h, minute=m, timezone=NY), id=f"recheck_{h}{m}")
    _sched.add_job(job_scan_and_report, CronTrigger(day_of_week="mon-fri", hour=16, minute=40, timezone=NY), id="scan")
    _sched.add_job(job_premarket, CronTrigger(day_of_week="mon-fri", hour=8, minute=30, timezone=NY), id="premarket")
    _sched.start()
    try:
        signals.trim_active()  # κρατά μόνο τα καλύτερα ενεργά signals ανά κατηγορία
    except Exception:  # noqa: BLE001
        log.exception("trim at start")
    # πρώτη εκκίνηση: αν η βάση είναι άδεια, ξεκινά αμέσως πλήρες scan στο παρασκήνιο
    from ..ml import features as MLF
    from ..ml import model as mlmodel
    has_models = bool(db.q1("SELECT 1 FROM ml_models"))
    stale = has_models and any(mlmodel.load(h) is None for h in MLF.HORIZONS)
    if db.kv_get("last_run_id") and db.kv_get("universe_built_at") and stale:
        # αναβάθμιση μοντέλου (νέα χαρακτηριστικά): SEC δεδομένα + εκπαίδευση v3 στο παρασκήνιο
        threading.Thread(target=job_ml_train, daemon=True).start()
    elif not db.kv_get("last_run_id") or not db.kv_get("universe_built_at"):
        # πρώτη εκκίνηση (ή αναβάθμιση): πλήρες scan όλης της αγοράς + εκπαίδευση μοντέλου τώρα
        threading.Thread(target=job_scan_and_report, daemon=True).start()
    else:
        threading.Thread(target=job_news, daemon=True).start()


def stop() -> None:
    if _sched:
        _sched.shutdown(wait=False)


def jobs_info() -> list[dict]:
    if not _sched:
        return []
    out = []
    for j in _sched.get_jobs():
        name = j.id.split("_")[0]
        out.append({"id": j.id, "next_run": j.next_run_time.isoformat() if j.next_run_time else None,
                    **job_status.get(name, {})})
    return out
